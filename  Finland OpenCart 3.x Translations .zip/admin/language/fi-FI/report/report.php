<?php
// Heading
$_['heading_title'] = 'Raportit';

// Text
$_['text_success']  = 'Menestys: olet muokannut raportteja!';
$_['text_list']     = 'Raportti luettelo';
$_['text_type']     = 'Valitse raportin tyyppi';
$_['text_filter']   = 'Suodatin';