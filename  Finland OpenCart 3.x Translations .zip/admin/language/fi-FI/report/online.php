<?php
// Heading
$_['heading_title']     = 'Online-raportti';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_success']      = 'Menestys: olet muokannut asiakkaita online raportti!';
$_['text_list']         = 'Online-luettelo';
$_['text_filter']       = 'Suodatin';
$_['text_guest']        = 'Guest';

// Column
$_['column_ip']         = 'Ip';
$_['column_customer']   = 'Asiakas';
$_['column_url']        = 'Viimeinen sivu vieraili';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Viimeinen napsautus';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_ip']          = 'Ip';
$_['entry_customer']    = 'Asiakas';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata asiakkaita online-raportti!';