<?php
// Heading
$_['heading_title']         = 'Tilastot';

// Text
$_['text_success']          = 'Menestys: olet muokannut tilastoja!';
$_['text_list']             = 'Tilasto luettelo';
$_['text_order_sale']       = 'Tilaus myynti';
$_['text_order_processing'] = 'Tilausten käsittely';
$_['text_order_complete']   = 'Tila ukset valmiit';
$_['text_order_other']      = 'Tila ukset muut';
$_['text_returns']          = 'Palauttaa';
$_['text_customer']         = 'Hyväksyntää odottavat asiakkaat';
$_['text_affiliate']        = 'Hyväksyntää odottavat kumppanit';
$_['text_product']          = 'Loppu tuotteista';
$_['text_review']           = 'Odottavat arviot';

// Column
$_['column_name']           = 'Tilaston nimi';
$_['column_value']	        = 'Arvo';
$_['column_action']         = 'Toiminta';

// Error
$_['error_permission']      = 'Varoitus: sinulla ei ole oikeutta muokata tilastoja!';