<?php
// Heading
$_['heading_title']         = 'Asiakkaan hyväksynnät';

// Text
$_['text_success']          = 'Menestys: olet muokannut asiakkaan hyväksynnät!';
$_['text_list']             = 'Asiakkaan hyväksymis luettelo';
$_['text_default']          = 'Oletus';
$_['text_customer']         = 'Asiakas';
$_['text_affiliate']        = 'Affiliate';

// Column
$_['column_name']           = 'Asiakkaan nimi';
$_['column_email']          = 'Sähköposti';
$_['column_customer_group'] = 'Asiakas ryhmä';
$_['column_type']           = 'Tyyppi';
$_['column_date_added']     = 'Päivä määrä lisätty';
$_['column_action']         = 'Toiminta';

// Entry
$_['entry_name']            = 'Asiakkaan nimi';
$_['entry_email']           = 'Sähköposti';
$_['entry_customer_group']  = 'Asiakas ryhmä';
$_['entry_type']            = 'Tyyppi';
$_['entry_date_added']      = 'Päivä määrä lisätty';

// Error
$_['error_permission']      = 'Varoitus: sinulla ei ole oikeuksia muokata asiakkaan hyväksyntöjä!';