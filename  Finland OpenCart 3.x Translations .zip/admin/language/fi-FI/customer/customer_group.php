<?php
// Heading
$_['heading_title']     = 'Asiakas ryhmät';

// Text
$_['text_success']      = 'Onnistui: olet muokannut asiakas ryhmiä!';
$_['text_list']         = 'Asiakas ryhmä-luettelo';
$_['text_add']          = 'Lisää asiakas ryhmä';
$_['text_edit']         = 'Muokkaa asiakas ryhmää';

// Column
$_['column_name']       = 'Asiakas ryhmän nimi';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Asiakas ryhmän nimi';
$_['entry_description'] = 'Kuvaus';
$_['entry_approval']    = 'Hyväksy uusia asiakkaita';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Help
$_['help_approval']     = 'Järjestelmänvalvojan on hyväksyttävä Asiakkaat, ennen kuin he voivat kirja utua sisään.';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata asiakas ryhmiä!';
$_['error_name']        = 'Asiakas ryhmän nimen on oltava välillä 3-32 merkkiä!';
$_['error_default']     = 'Varoitus: tätä asiakas ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty myymälän oletus asiakas ryhmäksi.';
$_['error_store']       = 'Varoitus: tätä asiakas ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_customer']    = 'Varoitus: tätä asiakas ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty %s Asiakkaat!';