<?php
// Heading
$_['heading_title']             = 'Asiakkaat';

// Text
$_['text_success']              = 'Menestys: olet muokannut asiakkaita!';
$_['text_list']                 = 'Asiakas luettelo';
$_['text_add']                  = 'Lisää asiakas';
$_['text_edit']                 = 'Muokkaa asiakasta';
$_['text_default']              = 'Oletus';
$_['text_account']              = 'Asiakkaan tiedot';
$_['text_password']             = 'Salasana';
$_['text_other']                = 'Muut';
$_['text_affiliate']            = 'Affiliate tiedot';
$_['text_payment']              = 'Maksu tiedot';
$_['text_balance']              = 'Tasapaino';
$_['text_cheque']               = 'Sekin';
$_['text_paypal']               = 'Paypal';
$_['text_bank']                 = 'Pankkisiirto';
$_['text_history']              = 'Historia';
$_['text_history_add']          = 'Lisää historiaa';
$_['text_transaction']          = 'Tapahtumat';
$_['text_transaction_add']      = 'Lisää tapahtuma';
$_['text_reward']               = 'Palkintopisteitä';
$_['text_reward_add']           = 'Lisää palkinto pisteitä';
$_['text_ip']                   = 'Ip';
$_['text_option']               = 'Vaihtoehtoja';
$_['text_login']                = 'Kirjaudu varastoon';
$_['text_unlock']               = 'Avaa tili';

// Column
$_['column_name']               = 'Asiakkaan nimi';
$_['column_email']              = 'Sähköposti';
$_['column_customer_group']     = 'Asiakas ryhmä';
$_['column_status']             = 'Tila';
$_['column_date_added']         = 'Päivä määrä lisätty';
$_['column_comment']            = 'Kommentti';
$_['column_description']        = 'Kuvaus';
$_['column_amount']             = 'Summa';
$_['column_points']             = 'Pistettä';
$_['column_ip']                 = 'Ip';
$_['column_total']              = 'Tilejä yhteensä';
$_['column_action']             = 'Toiminta';

// Entry
$_['entry_customer_group']      = 'Asiakas ryhmä';
$_['entry_firstname']           = 'Etunimi';
$_['entry_lastname']            = 'Suku nimi';
$_['entry_email']               = 'Sähköposti';
$_['entry_telephone']           = 'Puhelin';
$_['entry_newsletter']          = 'Uutiskirje';
$_['entry_status']              = 'Tila';
$_['entry_approved']            = 'Hyväksytty';
$_['entry_safe']                = 'Tallelokero';
$_['entry_password']            = 'Salasana';
$_['entry_confirm']             = 'Vahvista';
$_['entry_company']             = 'Yritys';
$_['entry_address_1']           = 'Osoite 1';
$_['entry_address_2']           = 'Osoite 2';
$_['entry_city']                = 'City';
$_['entry_postcode']            = 'Postinumero';
$_['entry_country']             = 'Maa';
$_['entry_zone']                = 'Alue/osavaltio';
$_['entry_default']             = 'Oletus osoite';
$_['entry_affiliate']           = 'Affiliate';
$_['entry_tracking']            = 'Seurantakoodin';
$_['entry_website']             = 'Web-sivusto';
$_['entry_commission']          = 'Komissio (%)';
$_['entry_tax']                 = 'Vero tunnus';
$_['entry_payment']             = 'Maksutapa';
$_['entry_cheque']              = 'Sekin maksun saajan nimi';
$_['entry_paypal']              = 'PayPal Sähkö posti tili';
$_['entry_bank_name']           = 'Pankin nimi';
$_['entry_bank_branch_number']  = 'ABA/BSB-numero (konttorin numero)';
$_['entry_bank_swift_code']     = 'SWIFT-koodi';
$_['entry_bank_account_name']   = 'Tilin nimi';
$_['entry_bank_account_number'] = 'Tili numero';
$_['entry_comment']             = 'Kommentti';
$_['entry_description']         = 'Kuvaus';
$_['entry_amount']              = 'Summa';
$_['entry_points']              = 'Pistettä';
$_['entry_name']                = 'Asiakkaan nimi';
$_['entry_ip']                  = 'Ip';
$_['entry_date_added']          = 'Päivä määrä lisätty';

// Help
$_['help_safe']                 = 'Aseta True, jotta tämä asiakas ei kuulu petosten vastaisen järjestelmän';
$_['help_affiliate']            = 'Ota käyttöön/Poista käytöstä asiakkaat voivat käyttää affiliate järjestelmä.';
$_['help_tracking']             = 'Seuranta koodi, jota käytetään viittausten seurantaan.';
$_['help_commission']           = 'Kunkin tila uksen kumppaniksi saama prosentti osuus.';
$_['help_points']               = 'Käytä miinus poistaa pisteitä';

// Error
$_['error_warning']             = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']          = 'Varoitus: sinulla ei ole oikeutta muokata asiakkaita!';
$_['error_exists']              = 'Varoitus: Sähkö posti osoite on jo rekisteröity!';
$_['error_firstname']           = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']            = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']               = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']           = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_password']            = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']             = 'Sala sana ja sala sana vahvistus eivät täsmää!';
$_['error_address_1']           = 'Osoitteen 1 on oltava välillä 3 ja 128 merkkiä!';
$_['error_city']                = 'Kaupungin on oltava välillä 2 ja 128 merkkiä!';
$_['error_postcode']            = 'Posti numeron on oltava 2-10 merkkiä tässä maassa!';
$_['error_country']             = 'Ole hyvä ja valitse maa!';
$_['error_zone']                = 'Valitse alue/osavaltio!';
$_['error_custom_field']        = '%s Tarvitaan!';
$_['error_tracking']            = 'Seuranta koodi vaaditaan!';
$_['error_tracking_exists']     = 'Seuranta koodi on käytössä toinen affiliate!';
$_['error_cheque']              = 'Sekillä maksun saajan nimi vaaditaan!';
$_['error_paypal']              = 'PayPal Sähkö posti osoite ei näytä olevan voimassa!';
$_['error_bank_account_name']   = 'Tilin nimi vaaditaan!';
$_['error_bank_account_number'] = 'Tili numero vaaditaan!';
