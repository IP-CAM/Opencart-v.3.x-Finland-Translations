<?php
// Heading
$_['heading_title']        = 'Mukautetut kentät';

// Text
$_['text_success']         = 'Onnistui: olet muokannut mukautettuja kenttiä!';
$_['text_list']            = 'Mukautettujen kenttien luettelo';
$_['text_add']             = 'Lisää mukautettu kenttä';
$_['text_edit']            = 'Muokkaa mukautettua kenttää';
$_['text_choose']          = 'Valita';
$_['text_select']          = 'Valitse';
$_['text_radio']           = 'Radio';
$_['text_checkbox']        = 'Valintaruutu';
$_['text_input']           = 'Syöttää';
$_['text_text']            = 'Teksti';
$_['text_textarea']        = 'Textarea';
$_['text_file']            = 'Tiedosto';
$_['text_date']            = 'Päivämäärä';
$_['text_datetime']        = 'Päivämäärä &amp; Aika';
$_['text_time']            = 'Aika';
$_['text_account']         = 'Tili';
$_['text_address']         = 'Osoite';
$_['text_affiliate']       = 'Affiliate';
$_['text_regex']           = 'Regex';
$_['text_custom_field']    = 'Mukautettu kenttä';
$_['text_value']           = 'Mukautettujen kenttien arvot';

// Column
$_['column_name']          = 'Mukautetun kentän nimi';
$_['column_location']      = 'Sijainti';
$_['column_type']          = 'Tyyppi';
$_['column_sort_order']    = 'Lajittelujärjestyksen';
$_['column_action']        = 'Toiminta';

// Entry
$_['entry_name']           = 'Mukautetun kentän nimi';
$_['entry_location']       = 'Sijainti';
$_['entry_type']           = 'Tyyppi';
$_['entry_value']          = 'Arvo';
$_['entry_validation']     = 'Validation';
$_['entry_custom_value']   = 'Mukautetun kentän arvon nimi';
$_['entry_customer_group'] = 'Asiakas ryhmä';
$_['entry_required']       = 'Tarvitaan';
$_['entry_status']         = 'Tila';
$_['entry_sort_order']     = 'Lajittelujärjestyksen';

// Help
$_['help_regex']           = 'Käytä regex. Esim:/[a-zA-Z0-9_-]/';
$_['help_sort_order']      = 'Laske joukon viimeisestä kentästä taaksepäin käyttämällä miinus merkkiä.';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole oikeuksia muokata mukautettuja kenttiä!';
$_['error_name']           = 'Mukautetun kentän nimen on oltava väliltä 1-128 merkkiä!';
$_['error_type']           = 'Varoitus: mukautettujen kenttien arvot vaaditaan!';
$_['error_custom_value']   = 'Mukautetun arvon nimen on oltava väliltä 1-128 merkkiä!';