<?php
// Heading
$_['heading_title']        = 'Api';

// Text
$_['text_success']         = 'Menestys: olet muokannut API!';
$_['text_list']            = 'API-luettelo';
$_['text_add']             = 'Lisää API';
$_['text_edit']            = 'Muokkaa API';
$_['text_ip']              = 'Alla voit luoda luettelon IP n saa käyttää API. Nykyinen IP on %s';

// Column
$_['column_username']      = 'API-käyttäjä nimi';
$_['column_status']        = 'Tila';
$_['column_token']         = 'Tunnussanoma';
$_['column_ip']            = 'Ip';
$_['column_date_added']    = 'Päivä määrä lisätty';
$_['column_date_modified'] = 'Muokkaus päivämäärä';

$_['column_action']        = 'Toiminta';

// Entry
$_['entry_username']       = 'API-käyttäjä nimi';
$_['entry_key']            = 'API-avain';
$_['entry_status']         = 'Tila';
$_['entry_ip']             = 'Ip';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole oikeuksia muokata API!';
$_['error_username']       = 'API käyttäjä tunnuksen on oltava välillä 3 ja 20 merkkiä!';
$_['error_key']            = 'API-avaimen on oltava välillä 64 ja 256 merkkiä!';
$_['error_ip']             = 'Sinun täytyy olla atleast yksi IP lisätty sallittujen luetteloon!';