<?php
// Heading
$_['heading_title']         = 'Käyttäjät';

// Text
$_['text_success']          = 'Menestys: olet muokannut käyttäjiä!';
$_['text_list']             = 'Käyttäjä luettelo';
$_['text_add']              = 'Lisää käyttäjä';
$_['text_edit']             = 'Muokkaa käyttäjää';

// Column
$_['column_username']       = 'Käyttäjätunnus';
$_['column_status']         = 'Tila';
$_['column_date_added']     = 'Päivä määrä lisätty';
$_['column_action']         = 'Toiminta';

// Entry
$_['entry_username']        = 'Käyttäjätunnus';
$_['entry_user_group']      = 'Käyttäjä ryhmälle';
$_['entry_password']        = 'Salasana';
$_['entry_confirm']         = 'Vahvista';
$_['entry_firstname']       = 'Etunimi';
$_['entry_lastname']        = 'Suku nimi';
$_['entry_email']           = 'Sähköposti';
$_['entry_image']           = 'Kuva';
$_['entry_status']          = 'Tila';

// Error
$_['error_permission']      = 'Varoitus: sinulla ei ole oikeuksia muokata käyttäjiä!';
$_['error_account']         = 'Varoitus: et voi poistaa oman tilin!';
$_['error_exists_username'] = 'Varoitus: käyttäjä nimi on jo käytössä!';
$_['error_username']        = 'Käyttäjä tunnuksen on oltava 3-20 merkkiä pitkä!';
$_['error_password']        = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']         = 'Sala sana ja sala sana vahvistus eivät täsmää!';
$_['error_firstname']       = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']        = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']           = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_exists_email']    = 'Varoitus: Sähkö posti osoite on jo rekisteröity!';