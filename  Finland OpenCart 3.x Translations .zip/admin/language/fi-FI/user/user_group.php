<?php
// Heading
$_['heading_title']    = 'Käyttäjä ryhmät';

// Text
$_['text_success']     = 'Menestys: olet muokannut käyttäjä ryhmiä!';
$_['text_list']        = 'Käyttäjä ryhmälle';
$_['text_add']         = 'Lisää käyttäjä ryhmä';
$_['text_edit']        = 'Muokkaa käyttäjä ryhmää';

// Column
$_['column_name']      = 'Käyttäjä ryhmän nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Käyttäjä ryhmän nimi';
$_['entry_access']     = 'Käyttö oikeus';
$_['entry_modify']     = 'Muokkaa käyttö oikeutta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata käyttäjä ryhmiä!';
$_['error_name']       = 'Käyttäjä ryhmän nimen on oltava välillä 3-64 merkkiä!';
$_['error_user']       = 'Varoitus: tätä käyttäjä ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty %s Käyttäjät!';