<?php
// Heading
$_['heading_title']    = 'Pilibaba Checkout-painike';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut pilibaba kassalle painiketta moduuli!';
$_['text_edit']        = 'Edit pilibaba kassalle painiketta moduuli';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata pilibaba kassalle painiketta moduuli!';