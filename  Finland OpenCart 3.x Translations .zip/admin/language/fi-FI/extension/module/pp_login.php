<?php
// Heading
$_['heading_title']        = 'Kirjaudu sisään PayPalilla';

// Text
$_['text_extension']       = 'Tiedostopääte';
$_['text_success']         = 'Menestys: olet muuttanut Kirjaudu sisään PayPal-moduuli!';
$_['text_edit']            = 'Muokkaa Kirjaudu sisään PayPal-moduulilla';
$_['text_button_grey']     = 'Harmaa';
$_['text_button_blue']     = 'Sininen (suositus)';

// Entry
$_['entry_client_id']      = 'Asiakas tunnus';
$_['entry_secret']         = 'Salainen';
$_['entry_sandbox']        = 'Eristetty tila';
$_['entry_debug']          = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_customer_group'] = 'Asiakas ryhmä';
$_['entry_button']         = 'Painikkeen väri';
$_['entry_seamless']       = 'Salli saumaton Checkout';
$_['entry_locale']         = 'Locale';
$_['entry_return_url']     = 'Palautuksen URL-osoite';
$_['entry_status']         = 'Tila';

// Help
$_['help_sandbox']         = 'Käytä Sandbox (testaus) ympäristö?';
$_['help_customer_group']  = 'Uusille asiakkaille, minkä asiakas ryhmän pitäisi saada luotu?';
$_['help_debug_logging']   = 'Tämän salliminen mahdollistaa tietojen lisäämisen virhe lokiin mahdollisten ongelmien vian jäljitykseen.';
$_['help_seamless']        = 'Mahdollistaa auto-login, kun asiakkaat valitsevat PayPal Express Checkout. Voit käyttää tätä, vaihto ehto on käytössä Kirjaudu sisään PayPal-tili. Sinun on myös käytettävä samaa tiliä kuin Express Checkout-tilissä.';
$_['help_locale']          = 'Tämä on PayPal locale asetukset oman kaupan kieliä';
$_['help_return_url']      = 'Tämä on lisättävä PayPal-sovelluksen asetuksiin sovelluksen uudelleenohjauksen URL-osoitteissa.';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole lupaa muokata Kirjaudu sisään PayPal-moduulin!';
$_['error_client_id']      = 'Tarvittava asiakas tunnus!';
$_['error_secret']         = 'Salaisuus vaaditaan!';