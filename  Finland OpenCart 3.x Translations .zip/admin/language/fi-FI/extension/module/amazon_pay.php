<?php
// Heading
$_['heading_title']         = 'Maksa Amazon';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_success']          = 'Menestys: olet muokannut moduuli maksaa Amazon!';
$_['text_content_top']      = 'Sisältö ylhäällä';
$_['text_content_bottom']   = 'Sisällön pohja';
$_['text_column_left']      = 'Sarake vasemmalle';
$_['text_column_right']     = 'Sarake oikealle';
$_['text_pwa_button']       = 'Maksa Amazon';
$_['text_pay_button']       = 'Maksaa';
$_['text_a_button']         = 'A';
$_['text_gold_button']      = 'Kulta';
$_['text_darkgray_button']  = 'Tummanharmaa';
$_['text_lightgray_button'] = 'Vaaleanharmaa';
$_['text_small_button']     = 'Pieni';
$_['text_medium_button']    = 'Keskipitkällä';
$_['text_large_button']     = 'Suuri';
$_['text_x_large_button']   = 'X-Large';

//Entry
$_['entry_button_type']     = 'Painikkeen tyyppi';
$_['entry_button_colour']   = 'Painikkeen väri';
$_['entry_button_size']     = 'Painikkeen koko';
$_['entry_layout']          = 'Asettelu';
$_['entry_position']        = 'Kanta';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

//Error
$_['error_permission']      = 'Varoitus: sinulla ei ole lupaa muokata moduulin maksaa Amazon!';