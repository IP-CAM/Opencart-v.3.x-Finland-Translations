<?php
// Heading
$_['heading_title']     = 'eBay listaus';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_success']      = 'Menestys: olet muokannut moduuli eBay esillä!';
$_['text_edit']        	= 'Muokkaa eBay moduuli';
$_['text_list']         = 'Asettelu luettelo';
$_['text_register']     = 'Sinun täytyy rekisteröityä ja mahdollistaa openbay Pro eBay!';
$_['text_about'] 		= 'EBay Display-moduulin avulla voit näyttää tuotteita eBay-tililtäsi suoraan sivustossasi.';
$_['text_latest']       = 'Viimeisin';
$_['text_random']       = 'Satunnainen';

// Entry
$_['entry_name']        = 'Moduulin nimi';
$_['entry_username']    = 'eBay käyttäjä tunnus';
$_['entry_keywords']    = 'Haku sanat';
$_['entry_description'] = 'Sisällytä kuvaus haku';
$_['entry_limit']       = 'Raja';
$_['entry_length']      = 'Pituus';
$_['entry_width']       = 'Leveys';
$_['entry_height']      = 'Korkeus';
$_['entry_site']   		= 'eBay sivusto';
$_['entry_sort']   		= 'Lajittele';
$_['entry_status']   	= 'Tila';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata moduulin eBay!';
$_['error_name']        = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']       = 'Leveys tarvitaan!';
$_['error_height']      = 'Korkeus vaaditaan!';