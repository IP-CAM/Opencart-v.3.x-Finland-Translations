<?php
// Heading
$_['heading_title']    = 'Banneri';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Banner Module!';
$_['text_edit']        = 'Muokkaa Banner moduuli';

// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_banner']     = 'Banneri';
$_['entry_dimension']  = 'Ulottuvuus (l x k) ja koon muuttamisen tyyppi';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Banner Module!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';