<?php
// Heading
$_['heading_title']    = 'Sazepay suora kortin hallinta';

$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut sazepay Direct kortin hallinta moduuli!';
$_['text_edit']        = 'Edit sazepay suora kortin hallinta moduuli';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata sazepay Direct kortin hallinta moduuli!';