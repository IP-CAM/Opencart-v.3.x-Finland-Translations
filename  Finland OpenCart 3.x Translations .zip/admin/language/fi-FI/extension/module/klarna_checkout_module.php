<?php
// Heading
$_['heading_title']	   = 'Klarna kassalle';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']	   = 'Menestys: olet muokannut moduuli Klarna kassalle!';

//Entry
$_['entry_status']	   = 'Tila';

//Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Klarna Checkout-moduulia!';