<?php
// Heading
$_['heading_title']    = 'Store';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Store Module!';
$_['text_edit']        = 'Muokkaa säilö moduulia';

// Entry
$_['entry_admin']      = 'Vain järjestelmänvalvoja-käyttäjät';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Store-moduulin!';