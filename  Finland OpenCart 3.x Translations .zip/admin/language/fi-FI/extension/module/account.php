<?php
// Heading
$_['heading_title']    = 'Tili';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut tili moduuli!';
$_['text_edit']        = 'Muokkaa tili moduulia';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata tili moduulia!';