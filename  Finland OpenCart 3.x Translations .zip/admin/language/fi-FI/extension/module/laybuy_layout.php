<?php
// Heading
$_['heading_title']    = 'Lay-Osta layout';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut myy-Osta layout moduuli!';
$_['text_edit']        = 'Muokkaa myy-Osta layout moduuli';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata myy-Osta layout moduuli!';