<?php
// Heading
$_['heading_title']    = 'Suodatin';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut suodatin moduuli!';
$_['text_edit']        = 'Muokkaa suodatin moduulia';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata suodatin moduulia!';