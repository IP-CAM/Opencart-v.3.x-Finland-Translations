<?php
// Heading
$_['heading_title']    = 'Odotettu toimitus päivä';

// Text
$_['text_module']     = 'Moduulit';
$_['text_lead_time']  = 'Toimitusaika';
$_['text_shipping_time'] = 'Toimitus aika';
$_['text_in_stock']   = 'Varastossa tuotteet';
$_['text_out_stock']  = 'Varasto tilojen loppu';
$_['text_success']    = 'Menestys: olet tallentanut asetukset!';

$_['text_module'] = 'Moduulin asetukset';
$_['entry_status'] = 'Tila:';

// Columns
$_['column_min']   	  = 'Min (arkisin)';
$_['column_max']   	  = 'Max (arkisin)';

// Entry
$_['entry_in_stock']  = 'Varastossa (määrä > 0)';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata odotettua toimitus päivää!';
?>