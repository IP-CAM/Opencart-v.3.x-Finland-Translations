<?php
// Heading
$_['heading_title']    = 'Power Upsellin: lisätty ostos koriin';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Power Upsellin: lisätty koriin moduuli!';
$_['text_edit']        = 'Muokkaa Power Upsellin: lisätty ostos koriin moduuli';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa valtaa Upsellin: lisätty koriin moduuli!';