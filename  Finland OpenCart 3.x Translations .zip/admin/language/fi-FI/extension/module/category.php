<?php
// Heading
$_['heading_title']    = 'Luokka';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut luokka moduuli!';
$_['text_edit']        = 'Muokkaa luokka moduulia';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata luokka moduulia!';