<?php
// Heading
$_['heading_title']    = 'Power Upsellin: usein ostettu';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Power Upsellin: usein ostettu moduuli!';
$_['text_edit']        = 'Muokkaa Power Upsellin: usein ostettu moduulin';

// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_limit']      = 'Raja';
$_['entry_image']      = 'Kuva (l x k) ja koon muuttamisen tyyppi';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa valtaa Upsellin: usein ostettu moduuli!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';