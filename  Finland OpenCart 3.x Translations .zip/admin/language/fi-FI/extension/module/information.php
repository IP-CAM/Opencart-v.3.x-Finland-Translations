<?php
// Heading
$_['heading_title']    = 'Huoneesta';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: olet muokannut tieto moduulia!';
$_['text_edit']        = 'Muokkaa tieto moduulia';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata tieto moduulia!';