<?php
// Heading
$_['heading_title']    = 'Power Suositeltavat';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut teho varustellun moduuli!';
$_['text_edit']        = 'Muokkaa virran käyttö ohjelmaan moduulia';

// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_product']    = 'Tuotteet';
$_['entry_limit']      = 'Raja';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';
$_['entry_context'] = 'Tilannekohtainen';

// Help
$_['help_product']     = 'AUtomaattinen täydennys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Power varustellun moduuli!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';