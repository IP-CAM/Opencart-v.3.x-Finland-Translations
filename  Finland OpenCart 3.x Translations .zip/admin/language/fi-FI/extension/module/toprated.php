<?php
// Heading
$_['heading_title']    = 'Power Arvostelut-Suosituimmat';
// Text
$_['text_module']      = 'Moduulit';
$_['text_success']     = 'Menestys: olet muokannut Power Arvostelut-Suosituimmat moduuli!';
$_['text_edit']        = 'Muokkaa Power Arvostelut-Suosituimmat moduuli';
// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_limit']      = 'Raja';
$_['entry_image']      = 'Kuva (l x k) ja koon muuttamisen tyyppi';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';
// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Power Arvostelut-Suosituimmat moduuli!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';