<?php
// Heading
$_['heading_title']    = 'Tarjoukset';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut moduulin tarjouksesta!';
$_['text_edit']        = 'Muokkaa tarjoukset-moduulia';

// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_limit']      = 'Raja';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata tarjouksesta moduuli!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';