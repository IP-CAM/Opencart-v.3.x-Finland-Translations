<?php
// Heading
$_['heading_title']    = 'Divido tuote sivu Laskin';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut divido tuote sivu Laskin!';
$_['text_edit']        = 'Muokkaa divido tuote sivu Laskin';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata moduulia divido tuote sivu Laskin!';