<?php
// Heading
$_['heading_title']    = 'Google Hangouts';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Google Hangouts moduuli!';
$_['text_edit']        = 'Muokkaa Google Hangouts-moduulia';

// Entry
$_['entry_code']       = 'Google Talk-koodi';
$_['entry_status']     = 'Tila';

// Help
$_['help_code']        = 'Goto <a href="https://developers.google.com/+/hangouts/button" target="_blank">Luo Google Hangout Chatback-merkki</a> ja jäljentää &amp; Liitä luotu koodi teksti kehykseen.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Google Hangouts-moduulia!';
$_['error_code']       = 'Koodi vaaditaan';