<?php
// Heading
$_['heading_title']    = 'PayPal Express Checkout-painike';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut PayPal Express Checkout-painiketta moduuli!';
$_['text_edit']        = 'Muokkaa PayPal Express Checkout-painiketta moduuli';
$_['text_info']        = 'Painike on <u>Ei</u> näkyvät tietyin edellytyksin:';
$_['text_info_li1']    = 'Ostos kori on tyhjä, eikä tositteita ole sovellettu';
$_['text_info_li2']    = 'Ostos korissa on latauksia tai toistuvia maksuja, eikä käyttäjä ole kirjautunut sisään';
$_['text_info_li3']    = 'Varasto nimikkeen uloskuittaus ei ole käytössä, ja ostos korissa on loppu tuotteen';
$_['text_layouts']     = 'Kun olet lisännyt moduulin, voit lisätä sen säilön alue isiin käyttämällä asettelun hallinta-painiketta.';
$_['text_layout_link'] = 'Napsauttamalla tätä voit käyttää taittoja-Sivua';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata PayPal Express Checkout-painiketta moduuli!';