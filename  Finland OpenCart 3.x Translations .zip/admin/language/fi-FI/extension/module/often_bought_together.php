<?php
// Heading
$_['heading_title']    = 'Power Upsellin: usein ostettu yhdessä';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Power Upsellin: usein ostanut yhdessä moduuli!';
$_['text_edit']        = 'Muokkaa Power Upsellin: usein ostanut yhdessä moduuli';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa valtaa Upsellin: usein ostanut yhdessä moduuli!';