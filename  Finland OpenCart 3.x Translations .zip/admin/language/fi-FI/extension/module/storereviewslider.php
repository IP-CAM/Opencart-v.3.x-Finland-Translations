<?php

// Heading

$_['heading_title']    = 'Power Arvostelut-Store Review Slider';

// Text

$_['text_module']      = 'Moduulit';

$_['text_success']     = 'Menestys: olet muokannut Power Arvostelut-Store Review Slider Module!';

$_['text_edit']        = 'Muokkaa Power Arvostelut-Store Review Slider moduuli';

$_['text_product'] = 'Tuote kuva ja linkki';

$_['text_customer'] = 'Asiakkaan valo kuva ja nimi';

// Entry

$_['entry_name']       = 'Moduulin nimi';

$_['entry_limit']      = 'Raja';

$_['entry_image']      = 'Kuva (l x k) ja koon muuttamisen tyyppi';

$_['entry_width']      = 'Leveys';

$_['entry_height']     = 'Korkeus';

$_['entry_status']     = 'Tila';

$_['entry_show'] = 'Näytä';

$_['entry_text_length'] = 'Tekstin pituus';
$_['entry_author_photo_width'] = 'Tekijä kuvan leveys';
$_['entry_author_photo_height'] = 'Tekijä kuvan korkeus';

// Error

$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Power Arvostelut-Store arvostelut Slider moduuli moduuli!';

$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';

$_['error_width']      = 'Leveys tarvitaan!';

$_['error_height']     = 'Korkeus vaaditaan!';

$_['error_limit']       = 'Limit tarvitaan!';
$_['error_author_width'] = 'Tekijä leveys tarvitaan!';
$_['error_author_height'] = 'Tekijä korkeus tarvitaan!';
