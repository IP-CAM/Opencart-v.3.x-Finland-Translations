<?php
// Heading
$_['heading_title']    = 'Sazepay palvelimen kortin hallinta';

$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut sazepay palvelimen kortin hallinta moduuli!';
$_['text_edit']        = 'Muokkaa sazepay-palvelin kortin hallinta moduulia';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa sazepay palvelimen kortin hallinta moduuli!';