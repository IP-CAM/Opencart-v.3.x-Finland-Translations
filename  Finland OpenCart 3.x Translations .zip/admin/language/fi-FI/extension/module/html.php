<?php
// Heading
$_['heading_title']     = 'HTML-sisältö';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_success']      = 'Menestys: olet muokannut HTML sisältö moduuli!';
$_['text_edit']         = 'Muokkaa HTML-sisältö moduulia';

// Entry
$_['entry_name']        = 'Moduulin nimi';
$_['entry_title']       = 'Otsikon otsikko';
$_['entry_description'] = 'Kuvaus';
$_['entry_status']      = 'Tila';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata HTML-sisältö moduulia!';
$_['error_name']        = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';