<?php
// Heading
$_['heading_title']    = 'Suositeltavat';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut varustellun moduuli!';
$_['text_edit']        = 'Muokkaa esiteltävät moduulit';

// Entry
$_['entry_name']       = 'Moduulin nimi';
$_['entry_product']    = 'Tuotteet';
$_['entry_limit']      = 'Raja';
$_['entry_width']      = 'Leveys';
$_['entry_height']     = 'Korkeus';
$_['entry_status']     = 'Tila';

// Help
$_['help_product']     = 'AUtomaattinen täydennys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata varustellun moduuli!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_width']      = 'Leveys tarvitaan!';
$_['error_height']     = 'Korkeus vaaditaan!';