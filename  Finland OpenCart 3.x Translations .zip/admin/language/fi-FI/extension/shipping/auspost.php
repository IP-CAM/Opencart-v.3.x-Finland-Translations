<?php
// Heading
$_['heading_title']      = 'Australia post';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muuttanut Australia post Shipping!';
$_['text_edit']          = 'Muokkaa Australia post Shipping';

// Entry
$_['entry_api']          = 'API-avain';
$_['entry_postcode']     = 'Posti numero';
$_['entry_weight_class'] = 'Paino luokka';
$_['entry_tax_class']    = 'Vero luokka';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Help
$_['help_weight_class']  = 'Asetettu kiloa.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole lupaa muuttaa Australian post Shipping!';
$_['error_postcode']     = 'Posti numero on 4 numeroa!';