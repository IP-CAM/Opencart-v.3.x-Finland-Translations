<?php
// Heading
$_['heading_title']                            = 'EY-aluksen';

// Text
$_['text_extension']                           = 'Tiedostopääte';
$_['text_success']                             = 'Menestys: olet muuttanut EY-laiva Shipping!';
$_['text_edit']                                = 'Muokkaa EY-aluksen toimitus';
$_['text_air_registered_mail']                 = 'Air kirjattuna kirjenä';
$_['text_air_parcel']                          = 'Air paketti (Paketti maxicolumn paino 20kg)';
$_['text_e_express_service_to_us']             = 'e-Express-palvelu meille (Paketti maxicolumn paino 2kg)';
$_['text_e_express_service_to_canada']         = 'e-Express-palvelu Kanadaan (Paketti maxicolumn paino 2kg)';
$_['text_e_express_service_to_united_kingdom'] = 'e-Express-palvelu Yhdistyneeseen kuningas kuntaan (Paketti maxicolumn paino 2kg)';
$_['text_e_express_service_to_russia']         = 'e-Express-palvelu Venäjälle (Paketti maxicolumn paino 2kg)';
$_['text_e_express_service_one']               = 'e-Express Service (mukaan lukien Saksa, Ranska ja Norja) (Paketti maxicolumn paino 2kg)';
$_['text_e_express_service_two']               = 'e-Express Service (mukaan lukien Australia, Uusi-Seelanti, Korea, Singapore ja Vietnam) (Paketti maxicolumn paino 2kg)';
$_['text_speed_post']                          = 'Speedpost (vakio palvelu) (Paketti maxicolumn paino 30kg)';
$_['text_smart_post']                          = 'Smart post (Paketti maxicolumn paino 2kg)';
$_['text_local_courier_post']                  = 'Paikallinen Courier post (laskuri kokoelma) (Paketti maxicolumn paino 2kg)';
$_['text_local_parcel']                        = 'Paikallispaketti (Paketti maxicolumn paino 20kg)';

// Entry
$_['entry_api_key']                            = 'API-avain';
$_['entry_username']                           = 'Integraattorin käyttäjä nimi';
$_['entry_api_username']                       = 'API-käyttäjä nimi';
$_['entry_test']                               = 'Testi tilassa';
$_['entry_service']                            = 'Palvelut';
$_['entry_weight_class']                       = 'Paino luokka';
$_['entry_tax_class']                          = 'Vero luokka';
$_['entry_geo_zone']                           = 'Geo Zone';
$_['entry_status']                             = 'Tila';
$_['entry_sort_order']                         = 'Lajittelujärjestyksen';

// Help
$_['help_api_key']                             = 'Anna EY-aluksen sinulle määrittämä API-avain.';
$_['help_username']                            = 'Anna EY-alus tilin integraattori käyttäjä nimi.';
$_['help_api_username']                        = 'Anna EY-alus tilin API-käyttäjä nimi.';
$_['help_test']                                = 'Käytä tätä moduulia testissä (Kyllä) tai tuotanto tilassa (ei)?';
$_['help_service']                             = 'Valitse tarjottavat EC-Ship-Palvelut.';
$_['help_weight_class']                        = 'Asetettu vain kilo grammoina.';

// Error
$_['error_permission']                         = 'Varoitus: sinulla ei ole lupaa muuttaa EY-aluksen toimitus!';
$_['error_api_key']                            = 'Access API avain tarvitaan!';
$_['error_username']                           = 'Käyttäjä tunnus vaaditaan!';
$_['error_api_username']                       = 'API-käyttäjä nimi vaaditaan!';
