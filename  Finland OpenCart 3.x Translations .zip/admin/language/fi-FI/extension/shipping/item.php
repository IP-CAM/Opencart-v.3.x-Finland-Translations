<?php
// Heading
$_['heading_title']    = 'Nimikettä kohti';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: olet muokannut toimitusta per nimike hinnat!';
$_['text_edit']        = 'Muokkaa nimikkeen toimitusta kohden';

// Entry
$_['entry_cost']       = 'Kustannukset';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata toimitusta per nimike hinnat!';