<?php
// Heading
$_['heading_title']                            = 'Fedex';

// Text
$_['text_shipping']                            = 'Toimitus';
$_['text_success']                             = 'Menestys: olet muuttanut FedEx Shipping!';
$_['text_edit']                                = 'Muokkaa FedEx Shipping';
$_['text_europe_first_international_priority'] = 'Euroopan ensimmäinen kansainvälinen prioriteetti';
$_['text_fedex_1_day_freight']                 = 'FedEx 1 päivä rahti';
$_['text_fedex_2_day']                         = 'FedEx 2 päivää';
$_['text_fedex_2_day_am']                      = 'FedEx 2 päivää am';
$_['text_fedex_2_day_freight']                 = 'FedEx 2 päivän rahti';
$_['text_fedex_3_day_freight']                 = 'FedEx 3 päivän rahti';
$_['text_fedex_express_saver']                 = 'FedEx Express Saver';
$_['text_fedex_first_freight']                 = 'FedExin ensimmäinen rahti';
$_['text_fedex_freight_economy']               = 'FedEx Freight Economy';
$_['text_fedex_freight_priority']              = 'FedEx Freight-prioriteetti';
$_['text_fedex_ground']                        = 'FedEx Ground';
$_['text_first_overnight']                     = 'Ensimmäinen yön yli';
$_['text_ground_home_delivery']                = 'Ground kotiinkuljetus';
$_['text_international_economy']               = 'Kansainvälinen talous';
$_['text_international_economy_freight']       = 'Kansainvälinen talous rahti';
$_['text_international_first']                 = 'International First';
$_['text_international_priority']              = 'Kansainvälinen paino piste';
$_['text_international_priority_freight']      = 'Kansainvälinen paino piste rahti';
$_['text_priority_overnight']                  = 'Prioriteetti yössä';
$_['text_smart_post']                          = 'Smart post';
$_['text_standard_overnight']                  = 'Standard yön yli';
$_['text_regular_pickup']                      = 'Säännöllinen nouto';
$_['text_request_courier']                     = 'Pyydä kuriiri';
$_['text_drop_box']                            = 'Pudotus laatikko';
$_['text_business_service_center']             = 'Yritys palvelu keskus';
$_['text_station']                             = 'Station';
$_['text_fedex_envelope']                      = 'FedEx-kirje kuori';
$_['text_fedex_pak']                           = 'FedEx Pak';
$_['text_fedex_box']                           = 'FedEx-laatikko';
$_['text_fedex_tube']                          = 'FedEx Tube';
$_['text_fedex_10kg_box']                      = 'FedEx 10kg Box';
$_['text_fedex_25kg_box']                      = 'FedEx 25kg Box';
$_['text_your_packaging']                      = 'Sinun pakkaus';
$_['text_list_rate']                           = 'Luettelo Rate';
$_['text_account_rate']                        = 'Tilin hinta';

// Entry
$_['entry_key']                                = 'Avain';
$_['entry_password']                           = 'Salasana';
$_['entry_account']                            = 'Tili numero';
$_['entry_meter']                              = 'Mittarin numero';
$_['entry_postcode']                           = 'Posti numero';
$_['entry_test']                               = 'Testi tilassa';
$_['entry_service']                            = 'Palvelut';
$_['entry_dimension']                          = 'Laatikon mitat (p x l x k)';
$_['entry_length_class']                       = 'Pituus luokka';
$_['entry_length']                             = 'Pituus';
$_['entry_width']                              = 'Leveys';
$_['entry_height']                             = 'Korkeus';
$_['entry_dropoff_type']                       = 'Pudota pois-tyyppi';
$_['entry_packaging_type']                     = 'Pakkaus tyyppi';
$_['entry_rate_type']                          = 'Hinta tyyppi';
$_['entry_display_time']                       = 'Näytä toimitus aika';
$_['entry_display_weight']                     = 'Näytä Toimituksen paino';
$_['entry_weight_class']                       = 'Paino luokka';
$_['entry_tax_class']                          = 'Vero luokka';
$_['entry_geo_zone']                           = 'Geo Zone';
$_['entry_status']                             = 'Tila';
$_['entry_sort_order']                         = 'Lajittelujärjestyksen';

// Help
$_['help_length_class']                        = 'Aseta tuumina tai sentti metreinä.';
$_['help_display_time']                        = 'Haluatko näyttää toimitus ajan? (esim. alukset 3 – 5 päivän sisällä)';
$_['help_display_weight']                      = 'Haluatko näyttää lähetyksen painon? (esim. Toimituksen paino: 2,7674 kg)';
$_['help_weight_class']                        = 'Asetettu kiloa tai kiloa.';

// Error
$_['error_permission']                         = 'Varoitus: sinulla ei ole lupaa muokata FedEx Shipping!';
$_['error_key']                                = 'Avain tarvitaan!';
$_['error_password']                           = 'Sala sana vaaditaan!';
$_['error_account']                            = 'Huomioon tarvitaan!';
$_['error_meter']                              = 'Mittari tarvitaan!';
$_['error_postcode']                           = 'Posti numero tarvitaan!';
$_['error_dimension']                          = 'Leveys &amp; Korkeus vaaditaan!';