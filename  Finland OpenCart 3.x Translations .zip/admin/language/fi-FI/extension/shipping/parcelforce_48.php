<?php
// Heading
$_['heading_title']           = 'Parcelforce 48';

// Text
$_['text_extension']          = 'Tiedostopääte';
$_['text_success']            = 'Menestys: olet muokannut Parcelforce 48 Shipping!';
$_['text_edit']               = 'Muokkaa Parcelforce 48 Shipping';

// Entry
$_['entry_rate']              = 'Parcelforce 48 hinnat';
$_['entry_insurance']         = 'Parcelforce48 korvaus asteet';
$_['entry_display_weight']    = 'Näytä Toimituksen paino';
$_['entry_display_insurance'] = 'Näytä Vakuutukset';
$_['entry_display_time']      = 'Näytä toimitus aika';
$_['entry_tax_class']         = 'Vero luokka';
$_['entry_geo_zone']          = 'Geo Zone';
$_['entry_status']            = 'Tila';
$_['entry_sort_order']        = 'Lajittelujärjestyksen';

// Help
$_['help_rate']               = 'Anna arvot enintään 5, 2 Desi maalia. (12345,67) esimerkki: .1:1,. 25:1h-enintään 0,1 kg, maksaisi 1,00, paino on pienempi tai yhtä suuri kuin 0,25 g, mutta yli 0,1 kg maksaa 1,27. Älä anna kg tai symboleja.';
$_['help_insurance']          = 'Anna arvot enintään 5, 2 Desi maalia. (12345,67) esimerkki: 34:0100:1250:2,25-vakuutus turvan ostos koriin arvot upto 34 maksaisi 0,00 ylimääräistä, nämä arvot yli 100 ja upto 250 maksaa 2,25 extra. Älä kirjoita valuutta symboleita.';
$_['help_display_weight']     = 'Haluatko näyttää lähetyksen painon? (esim. Toimituksen paino: 2,7674 kg)';
$_['help_display_insurance']  = 'Haluatko näyttää lähetys vakuutuksen? (esim. vakuutettu jopa 500)';
$_['help_display_time']       = 'Haluatko näyttää toimitus ajan? (esim. alukset 3 – 5 päivän sisällä)';

// Error
$_['error_permission']        = 'Varoitus: sinulla ei ole lupaa muokata Parcelforce 48 Shipping!';