<?php
// Heading
$_['heading_title']                    = 'Royal Mail';

// Text
$_['text_extension']                   = 'Tiedostopääte';
$_['text_success']                     = 'Menestys: olet muokannut Royal Mail Shipping!';
$_['text_edit']                        = 'Muokkaa Royal Mail Shipping';

// Entry
$_['entry_rate']                       = 'Hinnat';
$_['entry_rate_eu']                    = 'Eurooppa hinnat';
$_['entry_rate_non_eu']                = 'Muut kuin Eurooppa-hinnat';
$_['entry_rate_zone_1']                = 'World Zone 1 hinnat';
$_['entry_rate_zone_2']                = 'World Zone 2 hinnat';
$_['entry_insurance']                  = 'Korvaus asteet';
$_['entry_display_weight']             = 'Näytä Toimituksen paino';
$_['entry_display_insurance']          = 'Näytä Vakuutukset';
$_['entry_weight_class']               = 'Paino luokka';
$_['entry_tax_class']                  = 'Vero luokka';
$_['entry_geo_zone']                   = 'Geo Zone';
$_['entry_status']                     = 'Tila';
$_['entry_sort_order']                 = 'Lajittelujärjestyksen';

// Help
$_['help_rate']                        = 'Esimerkki: 5:10.00, 7:12.00 paino: kustannukset, paino: kustannukset jne.';
$_['help_insurance']                   = 'Anna arvot enintään 5, 2 Desi maalia. (12345,67) esimerkki: 34:0100:1250:2,25-vakuutus turvan ostos koriin arvot upto 34 maksaisi 0,00 ylimääräistä, nämä arvot yli 100 ja upto 250 maksaa 2,25 extra. Älä kirjoita valuutta symboleita.';
$_['help_display_weight']              = 'Haluatko näyttää lähetyksen painon? (esim. Toimituksen paino: 2,7674 kg)';
$_['help_display_insurance']           = 'Haluatko näyttää lähetys vakuutuksen? (esim. vakuutettu jopa &pound;500)';
$_['help_international']               = '<p>Lähetys palvelut ja hinnat opas on saatavilla tässä:</p><p><a href="http://www.royalmail.com/international-zones" target="_blank">http://www.RoyalMail.com/International-Zones</a></p><p><a href="http://www.royalmail.com/sites/default/files/RM_OurPrices_Mar2014a.pdf" target="_blank">http://www.RoyalMail.com/sites/default/files/RM_OurPrices_Mar2014a.PDF</a></p><p><a href="http://www.royalmail.com/sites/default/files/RoyalMail_International_TrackedCoverage_Jan2014.pdf" target="_blank">http://www.RoyalMail.com/sites/default/files/RoyalMail_International_TrackedCoverage_Jan2014.PDF</a></p>';

// Tab
$_['tab_special_delivery_500']         = 'Special toimitus seuraavana päivänä (&pound;500)';
$_['tab_special_delivery_1000']        = 'Special toimitus seuraavana päivänä (&pound;1000)';
$_['tab_special_delivery_2500']        = 'Special toimitus seuraavana päivänä (&pound;2500)';
$_['tab_1st_class_signed']             = '1. luokka allekirjoitettu';
$_['tab_2nd_class_signed']             = '2. luokka allekirjoitettu';
$_['tab_1st_class_standard']           = '1. luokan standardi';
$_['tab_2nd_class_standard']           = '2. luokan standardi';
$_['tab_international_standard']       = 'Kansainvälinen standardi';
$_['tab_international_tracked_signed'] = 'Kansainvälinen seurataan & allekirjoitettu';
$_['tab_international_tracked']        = 'Kansainväliset seuratut';
$_['tab_international_signed']         = 'Kansainvälinen allekirjoitettu';
$_['tab_international_economy']        = 'Kansainvälinen talous';

// Error
$_['error_permission']                 = 'Varoitus: sinulla ei ole lupaa muokata Royal Mail Shipping!';