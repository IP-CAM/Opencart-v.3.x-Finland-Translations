<?php
// Heading
$_['heading_title']    = 'Kiinteämääräinen';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: olet muokannut kiinteämääräinen toimitus!';
$_['text_edit']        = 'Muokkaa kiinteämääräinen toimitus';

// Entry
$_['entry_cost']       = 'Kustannukset';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata kiinteää meren kulkua!';