<?php
// Heading
$_['heading_title']    = 'Citylink';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Citylink Shipping!';
$_['text_edit']        = 'Muokkaa Citylink Shipping';

// Entry
$_['entry_rate']       = 'Citylink hinnat';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Help
$_['help_rate']        = 'Anna arvot enintään 5, 2 Desi maalia. (12345,67) esimerkki: .1:1,. 25:1,5 kg painavat tai yhtä suuret painot maksavat &pound;1,00, painot pienempi tai yhtä suuri kuin 0,25 g, mutta yli 0,1 kg maksaa 1,27. Älä anna kg tai symboleja.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Citylink Shipping!';