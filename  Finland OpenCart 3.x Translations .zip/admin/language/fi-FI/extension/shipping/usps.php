<?php
// Heading
$_['heading_title']         = 'Yhdysvaltain posti laitos';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_success']          = 'Menestys: olet muuttanut Yhdysvallat Postal Service!';
$_['text_edit']             = 'Muokkaa Yhdysvallat posti palvelu Shipping';
$_['text_domestic_00']      = 'Ensimmäisen luokan Mail paketti';
$_['text_domestic_01']      = 'Ensimmäisen luokan posti kirje kuori';
$_['text_domestic_02']      = 'Ensimmäisen luokan posti kirje';
$_['text_domestic_03']      = 'Ensimmäisen luokan posti kortit';
$_['text_domestic_1']       = 'Priority Mail';
$_['text_domestic_2']       = 'Express Mail pidä noudettavaksi';
$_['text_domestic_3']       = 'Express Mail';
$_['text_domestic_4']       = 'Paketti post';
$_['text_domestic_5']       = 'Sidottu painettu aine';
$_['text_domestic_6']       = 'Media Mail';
$_['text_domestic_7']       = 'Kirjasto';
$_['text_domestic_12']      = 'Ensimmäisen luokan posti kortti leimattu';
$_['text_domestic_13']      = 'Pikapostikirje kuori';
$_['text_domestic_16']      = 'Ensisijaisen postin kiinteämääräinen kirje kuori';
$_['text_domestic_17']      = 'Priority Mail säännöllinen kiinteämääräinen laatikko';
$_['text_domestic_18']      = 'Priority Mail avaimet ja tunnukset';
$_['text_domestic_19']      = 'Ensimmäisen luokan näppäimet ja tunnukset';
$_['text_domestic_22']      = 'Priority Mail kiinteämääräinen suuri laatikko';
$_['text_domestic_23']      = 'Express Mail sunnuntai/loma';
$_['text_domestic_25']      = 'Pikapostiviesti kiinteämääräinen kirje kuori sunnuntai/loma';
$_['text_domestic_27']      = 'Express Mail kiinteä kirje kuori pitää pickup';
$_['text_domestic_28']      = 'Priority Mail pieni kiinteämääräinen laatikko';
$_['text_international_1']  = 'Express Mail International';
$_['text_international_2']  = 'Priority Mail International';
$_['text_international_4']  = 'Taattu Global Express-takuu (asia kirja ja muu kuin asia kirja)';
$_['text_international_5']  = 'Käytetty Global Express taattu asia kirja';
$_['text_international_6']  = 'Globaali Esiintuoda taata ei--dokumentoida suorakulmainen hahmottua';
$_['text_international_7']  = 'Global Express taattu ei-asia kirja ei-suorakulmainen';
$_['text_international_8']  = 'Ensisijaisen postin kiinteämääräinen kirje kuori';
$_['text_international_9']  = 'Priority Mail kiinteä laatikko';
$_['text_international_10'] = 'Express Mail International kiinteämääräinen kirje kuori';
$_['text_international_11'] = 'Priority Mail kiinteämääräinen suuri laatikko';
$_['text_international_12'] = 'Globaali Express-takuu kirje kuori';
$_['text_international_13'] = 'Ensimmäisen luokan Mail International kirjeet';
$_['text_international_14'] = 'Ensimmäisen luokan Mail International Flats';
$_['text_international_15'] = 'Ensimmäisen luokan Mail International lohkot';
$_['text_international_16'] = 'Priority Mail kiinteä pieni laatikko';
$_['text_international_21'] = 'Postikortteja';
$_['text_regular']          = 'Säännöllisesti';
$_['text_large']            = 'Suuri';
$_['text_rectangular']      = 'Suorakulmainen';
$_['text_non_rectangular']  = 'Ei suorakulmainen';
$_['text_variable']         = 'Muuttujan';

// Entry
$_['entry_user_id']         = 'Käyttäjätunnus';
$_['entry_postcode']        = 'Postinumero';
$_['entry_domestic']        = 'Koti maan palvelut';
$_['entry_international']   = 'Kansainväliset palvelut';
$_['entry_size']            = 'Koko';
$_['entry_container']       = 'Säiliö';
$_['entry_machinable']      = 'Machinable';
$_['entry_dimension']       = 'Mitat (p x l x k)';
$_['entry_length']          = 'Pituus';
$_['entry_height']          = 'Korkeus';
$_['entry_width']           = 'Leveys';
$_['entry_display_time']    = 'Näytä toimitus aika';
$_['entry_display_weight']  = 'Näytä Toimituksen paino';
$_['entry_weight_class']    = 'Paino luokka';
$_['entry_tax']             = 'Vero luokka';
$_['entry_geo_zone']        = 'Geo Zone';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';
$_['entry_debug']           = 'Debug mode';

// Help
$_['help_dimension']        = 'Lähetys pakkauksen keskimääräinen pakkaus koko. Tuote dimensioita ei käytetä tällä hetkellä toimitus kuluja varten.';
$_['help_display_time']     = 'Haluatko näyttää toimitus ajan? (esim. alukset 3 – 5 päivän sisällä)';
$_['help_display_weight']   = 'Haluatko näyttää lähetyksen painon? (esim. Toimituksen paino: 2,7674 kg)';
$_['help_weight_class']     = 'On asetettava Pound.';
$_['help_debug']            = 'Tallentaa lähetys-ja uudelleentietotiedot järjestelmä lokiin';

// Error
$_['error_permission']      = 'Varoitus: sinulla ei ole lupaa muokata United States Postal Service!';
$_['error_user_id']         = 'Käyttäjä tunnus vaaditaan!';
$_['error_postcode']        = 'Posti numero tarvitaan!';
$_['error_width']           = 'Leveys tarvitaan!';
$_['error_length']          = 'Pituus tarvitaan!';
$_['error_height']          = 'Korkeus vaaditaan!';
$_['error_girth']           = 'Ympärys mitta tarvitaan!';