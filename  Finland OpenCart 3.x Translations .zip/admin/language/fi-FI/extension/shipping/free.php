<?php
// Heading
$_['heading_title']    = 'Ilmainen toimitus';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut ilmainen postitus!';
$_['text_edit']        = 'Muokkaa ilmainen postitus';

// Entry
$_['entry_total']      = 'Yhteensä';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Help
$_['help_total']       = 'Väli summa, joka tarvitaan, ennen kuin ilmainen toimitus-moduuli tulee saataville.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata maksuttoman kuljetuksen!';