<?php
// Heading
$_['heading_title']    = 'Paino perustuu Shipping';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut paino perustuu Shipping!';
$_['text_edit']        = 'Muokkaa painoon perustuvaa toimitusta';

// Entry
$_['entry_rate']       = 'Hinnat';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Help
$_['help_rate']        = 'Esimerkki: 5:10.00, 7:12.00 paino: kustannukset, paino: kustannukset jne.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata paino perustuu meren kulku!';