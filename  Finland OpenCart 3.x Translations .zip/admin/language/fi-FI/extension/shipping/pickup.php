<?php
// Heading
$_['heading_title']    = 'Nouto myymälästä';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut pickup kaupasta!';
$_['text_edit']        = 'Muokkaa noutoa myymälän toimituksesta';

// Entry
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata noutoa kaupasta!';