<?php
// Heading
$_['heading_title']    = 'Power Facebook-kuvasto';

// Text   
$_['text_feed']        = 'Tuote syötteet';
$_['text_success']     = 'Menestys: olet muokannut valtaa Facebook Facebook Feed!';
$_['text_installed_feeds'] = 'Asennetut tuote syötteet';
$_['text_use']             = 'Käyttää';
$_['text_all']             = 'Kaikki tuotteet';
$_['text_none']            = 'Yksikään tuote';
$_['text_custom']          = 'Räätälöidyt tuotteet';
$_['text_min_shipping']    = 'Pienin toimitus kulut:';
$_['text_show_datafeed']   = 'Näytä tieto syöte';

$_['text_no_feeds']        = 'Ei asennettuja tuote syötteitä';

// Entry
$_['entry_data_feed']  = 'Tietojen syötön URL-osoite:';
$_['entry_status']         = 'Tila:';
$_['entry_installed_feeds'] = 'Asennetut tuote syötteet:';
$_['entry_product']        = 'Tuotteet:<br /><span class="help">AUtomaattinen täydennys</span>';

// Tab
$_['tab_power_facebook_catalog']    = 'Power Facebook-kuvasto';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa valtaa Facebook luetteloomme rehu!';
$_['error_min_shipping']   = 'Varoitus: toimitus kulujen minimi arvo %s tuotteet rehu ei kelpaa! Se on numero!';
