<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Google Sitemap Feed!';
$_['text_edit']        = 'Muokkaa Google Sitemap';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_data_feed']  = 'Tietojen syötön URL-osoite';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Google Sitemap Feed!';