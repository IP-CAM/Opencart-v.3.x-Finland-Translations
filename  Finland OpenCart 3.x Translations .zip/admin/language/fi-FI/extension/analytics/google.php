<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']	   = 'Menestys: olet muuttanut Google Analytics!';
$_['text_edit']        = 'Muokkaa Google Analyticsia';
$_['text_signup']      = 'Johdon mukaisuus jotta sinun <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> tili ja kun olet luonut sivuston profiili kopioi ja liitä Analytics-koodi tähän kenttään.';
$_['text_default']     = 'Oletus';

// Entry
$_['entry_code']       = 'Google Analytics-koodi';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Google Analyticsia!';
$_['error_code']	   = 'Koodi tarvitaan!';
