<?php
// Heading
$_['heading_title']    = 'Basic captcha';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Basic captcha!';
$_['text_edit']        = 'Muokkaa Basic captcha';

// Entry
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Basic captcha!';