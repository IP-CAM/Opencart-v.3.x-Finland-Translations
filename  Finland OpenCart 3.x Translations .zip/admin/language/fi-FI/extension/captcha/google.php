<?php
// Heading
$_['heading_title']    = 'Google reCAPTCHA';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Google reCAPTCHA!';
$_['text_edit']        = 'Muokkaa Google reCAPTCHA';
$_['text_signup']      = 'Mennä <a href="https://www.google.com/recaptcha/intro/index.html" target="_blank"><u>Google reCAPTCHA sivu</u></a> ja rekisteröi sivustosi.';

// Entry
$_['entry_key']        = 'Sivuston avain';
$_['entry_secret']     = 'Salainen avain';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Google reCAPTCHA!';
$_['error_key']        = 'Avain tarvitaan!';
$_['error_secret']     = 'Salaisuus vaaditaan!';