<?php
// Heading
$_['heading_title']    = 'Teemoja';

// Text
$_['text_success']     = 'Menestys: olet muokannut teemoja!';
$_['text_list']        = 'Teema lista';

// Column
$_['column_name']      = 'Teeman nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata teemoja!';