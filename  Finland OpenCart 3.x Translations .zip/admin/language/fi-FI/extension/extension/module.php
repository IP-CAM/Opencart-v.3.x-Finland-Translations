<?php
// Heading
$_['heading_title']    = 'Moduulit';

// Text
$_['text_success']     = 'Menestys: olet muokannut moduulit!';
$_['text_layout']      = 'Kun olet asentanut ja konfiguroinut moduulin, voit lisätä sen asetteluun <a href="%s" class="alert-link">Täällä</a>!';
$_['text_add']         = 'Lisää moduuli';
$_['text_list']        = 'Moduulin luettelo';

// Column
$_['column_name']      = 'Moduulin nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_code']       = 'Moduuli';
$_['entry_name']       = 'Moduulin nimi';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata moduuleja!';
$_['error_name']       = 'Moduulin nimen on oltava välillä 3-64 merkkiä!';
$_['error_code']       = 'Laajennus tarvitaan!';