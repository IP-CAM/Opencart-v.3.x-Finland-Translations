<?php
// Heading
$_['heading_title']     = 'Maksut';

// Text
$_['text_success']      = 'Menestys: olet muuttanut maksuja!';
$_['text_list']         = 'Maksu luettelo';
$_['text_recommended']  = 'Maksut-suositellut ratkaisut';


// Column
$_['column_name']       = 'Maksutapa';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata maksuja!';