<?php
// Heading
$_['heading_title']     = 'Raportit';

// Text
$_['text_success']      = 'Menestys: olet muokannut raportteja!';
$_['text_list']         = 'Raportit-luettelo';

// Column
$_['column_name']       = 'Raportin nimi';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata raportteja!';