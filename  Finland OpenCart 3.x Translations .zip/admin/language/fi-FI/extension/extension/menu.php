<?php
// Heading
$_['heading_title']    = 'Valikko';

// Text
$_['text_success']     = 'Menestys: olet muokannut valikko!';
$_['text_list']        = 'Valikko luettelo';

// Column
$_['column_name']      = 'Valikon nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata valikkoa!';