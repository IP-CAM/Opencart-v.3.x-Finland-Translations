<?php
// Heading
$_['heading_title']     = 'Muut';

// Text
$_['text_success']      = 'Menestys: olet muokannut muita laajennus!';
$_['text_list']         = 'Muu luettelo';

// Column
$_['column_name']       = 'Muut';
$_['column_status']     = 'Tila';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata muita laajennus!';