<?php
// Heading
$_['heading_title']     = 'Toimitus';

// Text
$_['text_success']      = 'Menestys: olet muokannut Shipping!';
$_['text_list']         = 'Postitus lista';

// Column
$_['column_name']       = 'Toimitus tapa';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata toimitusta!';