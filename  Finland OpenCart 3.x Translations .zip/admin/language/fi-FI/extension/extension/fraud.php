<?php
// Heading
$_['heading_title']    = 'Petostentorjunta';

// Text
$_['text_success']     = 'Menestys: olet muuttanut anti-petos!';
$_['text_list']        = 'Petosten vastainen luettelo';

// Column
$_['column_name']      = 'Petosten vastainen nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata anti-petos!';