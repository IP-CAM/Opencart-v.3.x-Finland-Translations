<?php
// Heading
$_['heading_title']    = 'Markkinointi';

// Text
$_['text_success']     = 'Menestys: olet muuttanut markkinointi!';
$_['text_list']        = 'Analytics-luettelo';

// Column
$_['column_name']      = 'Markkinointi nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata markkinointia!';