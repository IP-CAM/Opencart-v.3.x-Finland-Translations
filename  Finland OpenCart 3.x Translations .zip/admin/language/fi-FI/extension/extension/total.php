<?php
// Heading
$_['heading_title']     = 'Tilausten yhteissummat';

// Text
$_['text_success']      = 'Menestys: olet muokannut yhteensä!';
$_['text_list']         = 'Tila uksen summa-luettelo';

// Column
$_['column_name']       = 'Tilausten yhteissummat';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata summia!';