<?php
// Heading
$_['heading_title']     = 'Dashboard';

// Text
$_['text_success']      = 'Onnistui: olet muokannut koonti näyttöjä!';
$_['text_list']         = 'Dashboard-luettelo';

// Column
$_['column_name']       = 'Koonti näytön nimi';
$_['column_width']      = 'Leveys';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia koonti näyttöjen muokkaamiseen.';