<?php
// Heading
$_['heading_title']    = 'Captchas';

// Text
$_['text_success']     = 'Menestys: olet muokannut captchas!';
$_['text_list']        = 'Captcha luettelo';

// Column
$_['column_name']      = 'Captcha nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata captchas!';