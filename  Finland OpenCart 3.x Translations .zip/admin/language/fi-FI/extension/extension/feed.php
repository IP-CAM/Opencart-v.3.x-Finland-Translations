<?php
// Heading
$_['heading_title']    = 'Syötteet';

// Text
$_['text_success']     = 'Menestys: olet muokannut syötteitä!';
$_['text_list']        = 'Rehu luettelo';

// Column
$_['column_name']      = 'Tuotteen syötteen nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata syötteitä!';