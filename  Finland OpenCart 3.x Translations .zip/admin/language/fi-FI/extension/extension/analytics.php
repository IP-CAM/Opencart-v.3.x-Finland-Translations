<?php
// Heading
$_['heading_title']    = 'Analytics';

// Text
$_['text_success']     = 'Menestys: olet muokannut Analytics!';
$_['text_list']        = 'Analytics-luettelo';

// Column
$_['column_name']      = 'Analyticsin nimi';
$_['column_status']    = 'Tila';
$_['column_action']    = 'Toiminta';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Analyticsia!';