<?php
// Heading
$_['heading_title']          = 'Oletus valikko';

// Text
$_['text_extension']         = 'Tiedostopääte';
$_['text_success']           = 'Menestys: olet muuttanut Google Base Feed!';
$_['text_edit']              = 'Muokkaa Google Base';
$_['text_import']            = 'Jotta download viimeistään Google Kategoria haluttaa luona <a href="https://support.google.com/merchants/answer/160081?hl=en" target="_blank" class="alert-link">klikkaamalla tästä</a> ja valitse taksonomia numeeriset tunnukset vain teksti (. txt) tiedosto. Upload kautta kokematon merkitä napittaa.';

// Column
$_['column_google_category'] = 'Google Kategoria';
$_['column_category']        = 'Luokka';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_google_category']  = 'Google Kategoria';
$_['entry_category']         = 'Luokka';
$_['entry_data_feed']        = 'Tietojen syötön URL-osoite';
$_['entry_status']           = 'Tila';

// Error
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeutta muokata Google Base Feed!';
$_['error_upload']           = 'Tiedostoa ei voitu ladata palvelimeen!';
$_['error_filetype']         = 'Virheellinen tiedosto tyyppi!';