<?php
// Heading
$_['heading_title']              = 'Frain Labs Pro';

// Text
$_['text_extension']             = 'Tiedostopääte';
$_['text_success']               = 'Menestys: olet muokannut frahuijari Pro asetukset!';
$_['text_edit']                  = 'Asetukset';
$_['text_signup']                = 'Frapetolabs Pro on petos etsivä palvelu. Voit <a href="http://www.fraudlabspro.com/plan?ref=1730" target="_blank"><u>Rekisteröidy tästä</u></a> ajaksi vapauttaa API avain.';
$_['text_id']                    = 'Fraidlabs Pro tunnus';
$_['text_ip_address']            = 'IP-osoite';
$_['text_ip_net_speed']          = 'IP-verkon nopeus';
$_['text_ip_isp_name']           = 'IP-palveluntarjoajan nimi';
$_['text_ip_usage_type']         = 'IP-käyttö tyyppi';
$_['text_ip_domain']             = 'IP-toimi alue';
$_['text_ip_time_zone']          = 'IP-aika vyöhyke';
$_['text_ip_location']           = 'IP-sijainti';
$_['text_ip_distance']           = 'IP-etäisyys';
$_['text_ip_latitude']           = 'IP Latitude';
$_['text_ip_longitude']          = 'IP-pituus aste';
$_['text_risk_country']          = 'Korkean riskin maa';
$_['text_free_email']            = 'Ilmainen Sähkö posti';
$_['text_ship_forward']          = 'Lähetä eteenpäin';
$_['text_using_proxy']           = 'Välitys palvelimen käyttäminen';
$_['text_bin_found']             = 'Varasto paikka löytyi';
$_['text_email_blacklist']       = 'Sähkö posti musta lista';
$_['text_credit_card_blacklist'] = 'Luotto kortti blacklist';
$_['text_score']                 = 'Frahuijari Labs Pro Pisteet';
$_['text_status']                = 'Frahuijari Pro tila';
$_['text_message']               = 'Viesti';
$_['text_transaction_id']        = 'Tapahtuman tunnus';
$_['text_credits']               = 'Tasapaino';
$_['text_error']                 = 'Virhe:';
$_['text_flp_upgrade']           = '<a href="http://www.fraudlabspro.com/plan" target="_blank">[Upgrade]</a>';
$_['text_flp_merchant_area']     = 'Kirjaudu <a href="http://www.fraudlabspro.com/merchant/login" target="_blank">Frahuijari Pro kauppias alue</a> lisä tietoja tästä tila uksesta.';

// Entry
$_['entry_status']               = 'Tila';
$_['entry_key']                  = 'API-avain';
$_['entry_score']                = 'Riski Pisteet';
$_['entry_order_status']         = 'Tila uksen tila';
$_['entry_review_status']        = 'Tarkistuksen tila';
$_['entry_approve_status']       = 'Hyväksy tila';
$_['entry_reject_status']        = 'Hylkää tila';
$_['entry_simulate_ip']          = 'Simuloi IP';

// Help
$_['help_order_status']          = 'Tila ukset, joiden piste määrä on määritetty riski pistein, määritetään tämän tila uksen tilan mukaan.';
$_['help_review_status']         = 'Tila ukset, jotka on merkitty arvostelun tekijä frahuijari Pro annetaan tämän tila uksen tila.';
$_['help_approve_status']        = 'Tila ukset, jotka on merkitty hyväksyttäväksi Frain Labs Pro annetaan tämän tila uksen tila.';
$_['help_reject_status']         = 'Tila ukset, jotka on merkitty hylätä Frain Labs Pro annetaan tämän tila uksen tila.';
$_['help_simulate_ip']           = 'Simuloi kävijän IP-osoite testausta varten. Jätä tyhjäksi poistaa se.';
$_['help_fraudlabspro_id']       = 'On yksilöllinen tunnus tapahtuman turva tarkastus on frahuijari Pro System.';
$_['help_ip_address']            = 'IP-osoite.';
$_['help_ip_net_speed']          = 'Yhteyden nopeudesta.';
$_['help_ip_isp_name']           = 'IP-osoitteen Internet-palveluntarjoaja.';
$_['help_ip_usage_type']         = 'IP-osoitteen käyttö tyyppi. Esimerkiksi ISP, kaupallinen, asuin.';
$_['help_ip_domain']             = 'IP-osoitteen toimi alue nimi.';
$_['help_ip_time_zone']          = 'IP-osoitteen aika vyöhyke.';
$_['help_ip_location']           = 'IP-osoitteen sijainti.';
$_['help_ip_distance']           = 'Etäisyys IP-osoitteesta laskutus sijaintiin.';
$_['help_ip_latitude']           = 'IP-osoitteen leveys aste.';
$_['help_ip_longitude']          = 'Pituus aste IP-osoitteen.';
$_['help_risk_country']          = 'Onko IP-osoite maa on Viimeisin korkean riskin maiden luettelossa.';
$_['help_free_email']            = 'Onko Sähkö posti viesti ilmainen Sähkö posti palvelu.';
$_['help_ship_forward']          = 'Onko toimitus osoite huolitsija osoite.';
$_['help_using_proxy']           = 'Onko IP-osoite on perä isin anonyymi proxy-palvelin.';
$_['help_bin_found']             = 'Vastaako varasto paikan tiedot varasto paikka luetteloamme.';
$_['help_email_blacklist']       = 'Onko Sähkö posti osoite on meidän mustalle listalle tieto kantaan.';
$_['help_credit_card_blacklist'] = 'Onko luotto kortti on meidän mustalle listalle tieto kantaan.';
$_['help_score']                 = 'Riski Pisteet, 0 (pieni riski)-100 (suuri riski).';
$_['help_status']                = 'Frahuijari Pro tila.';
$_['help_message']               = 'Frahuijari Pro virhe ilmoituksen kuvaus.';
$_['help_transaction_id']        = 'On yksilöllinen tunnus tapahtuman turva tarkastus on frahuijari Pro System.';
$_['help_credits']               = 'Tämän tapahtuman jälkeen käytettävissä olevien luottojen saldo.';

// Error
$_['error_permission']           = 'Varoitus: sinulla ei ole lupaa muokata frahuijari Pro-asetukset!';
$_['error_key']                  = 'API avain tarvitaan!';