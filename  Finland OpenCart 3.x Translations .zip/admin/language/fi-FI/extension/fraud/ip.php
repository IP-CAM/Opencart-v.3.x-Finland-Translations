<?php
// Heading
$_['heading_title']      = 'Petosten vastainen IP';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muuttanut anti-petos IP!';
$_['text_edit']          = 'Edit anti-petos IP';
$_['text_ip_add']        = 'Lisää IP-osoite';
$_['text_ip_list']       = 'Petosten IP-osoite luettelo';

// Column
$_['column_ip']          = 'Ip';
$_['column_total']       = 'Tilejä yhteensä';
$_['column_date_added']  = 'Päivä määrä lisätty';
$_['column_action']      = 'Toiminta';

// Entry
$_['entry_ip']           = 'Ip';
$_['entry_status']       = 'Tila';
$_['entry_order_status'] = 'Tila uksen tila';

// Help
$_['help_order_status']  = 'Asiakkaat, joiden tileissä on kielletty IP-tili, saavat tämän tila uksen tilan, eikä niiden sallita saavuttaa täydellistä tilaa automaattisesti.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole lupaa muuttaa petosten vastaisen IP!';