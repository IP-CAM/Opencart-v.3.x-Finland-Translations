<?php
// Heading
$_['heading_title']    = 'Katsotuimmat tuotteet raportti';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_edit']        = 'Muokkaa Katsotuimmat tuotteet-raporttia';
$_['text_success']     = 'Menestys: olet nollattu tuotteet Katsotuimmat raportti!';

// Column
$_['column_name']      = 'Tuotteen nimi';
$_['column_model']     = 'Malli';
$_['column_viewed']    = 'Katsoneet asiakkaat katsoivat';
$_['column_percent']   = 'Prosenttia';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata tuotteita Katsotuimmat raportti!';