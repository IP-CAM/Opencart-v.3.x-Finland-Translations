<?php
// Heading
$_['heading_title']         = 'Asiakas tilausten raportti';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_edit']             = 'Muokkaa asiakkaan tila uksia-raportti';
$_['text_success']          = 'Onnistui: olet muokannut asiakas tilausten raporttia!';
$_['text_filter']           = 'Suodatin';
$_['text_all_status']       = 'Kaikki tilat';

// Column
$_['column_customer']       = 'Asiakkaan nimi';
$_['column_email']          = 'Sähköposti';
$_['column_customer_group'] = 'Asiakas ryhmä';
$_['column_status']         = 'Tila';
$_['column_orders']         = 'Ei. Tilaukset';
$_['column_products']       = 'Ei. Tuotteet';
$_['column_total']          = 'Yhteensä';
$_['column_action']         = 'Toiminta';

// Entry
$_['entry_date_start']      = 'Alkamis päivä';
$_['entry_date_end']        = 'Päättymis päivä';
$_['entry_customer']        = 'Asiakas';
$_['entry_status']          = 'Tila uksen tila';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata asiakas tilausten raporttia!';