<?php
// Heading
$_['heading_title']     = 'Lähetys raportti';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_edit']         = 'Muokkaa lähetys raporttia';
$_['text_success']      = 'Menestys: olet muokannut Shipping raportti!';
$_['text_filter']       = 'Suodatin';
$_['text_year']         = 'Vuotta';
$_['text_month']        = 'Kuukautta';
$_['text_week']         = 'Viikkoa';
$_['text_day']          = 'Päivää';
$_['text_all_status']   = 'Kaikki tilat';

// Column
$_['column_date_start'] = 'Alkamis päivä';
$_['column_date_end']   = 'Päättymis päivä';
$_['column_title']      = 'Lähetyksen otsikko';
$_['column_orders']     = 'Ei. Tilaukset';
$_['column_total']      = 'Yhteensä';

// Entry
$_['entry_date_start']  = 'Alkamis päivä';
$_['entry_date_end']    = 'Päättymis päivä';
$_['entry_group']       = 'Ryhmittely';
$_['entry_status']      = 'Tila uksen tila';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata lähetys raporttia!';