<?php
// Heading
$_['heading_title']    = 'Markkinointi raportti';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_edit']        = 'Muokkaa markkinointi raporttia';
$_['text_success']     = 'Menestys: olet muokannut markkinointi raportti!';
$_['text_filter']      = 'Suodatin';
$_['text_all_status']  = 'Kaikki tilat';

// Column
$_['column_campaign']  = 'Kampanjan nimi';
$_['column_code']      = 'Koodi';
$_['column_clicks']    = 'Napsautuksia';
$_['column_orders']    = 'Ei. Tilaukset';
$_['column_total']     = 'Yhteensä';

// Entry
$_['entry_date_start'] = 'Alkamis päivä';
$_['entry_date_end']   = 'Päättymis päivä';
$_['entry_status']     = 'Tila uksen tila';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata markkinointi raportti!';