<?php
// Heading
$_['heading_title']     = 'Ostetut tuotteet-raportti';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_edit']         = 'Muokkaa ostettujen tuotteiden raporttia';
$_['text_success']      = 'Menestys: olet muuttanut tuotteita ostettu raportti!';
$_['text_filter']       = 'Suodatin';
$_['text_all_status']   = 'Kaikki tilat';

// Column
$_['column_date_start'] = 'Alkamis päivä';
$_['column_date_end']   = 'Päättymis päivä';
$_['column_name']       = 'Tuotteen nimi';
$_['column_model']      = 'Malli';
$_['column_quantity']   = 'Määrä';
$_['column_total']      = 'Yhteensä';

// Entry
$_['entry_date_start']  = 'Alkamis päivä';
$_['entry_date_end']    = 'Päättymis päivä';
$_['entry_status']      = 'Tila uksen tila';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata ostettujen tuotteiden raportti!';