<?php
// Heading
$_['heading_title']     = 'Asiakas haut-raportti';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_edit']         = 'Muokkaa asiakas haut-raporttia';
$_['text_success']      = 'Onnistui: olet muokannut asiakas haut-raporttia!';
$_['text_filter']       = 'Suodatin';
$_['text_guest']        = 'Guest';
$_['text_customer']     = '<a href="%s">%s</a>';

// Column
$_['column_keyword']    = 'Avainsanan';
$_['column_products']   = 'Löydetyt tuotteet';
$_['column_category']   = 'Luokka';
$_['column_customer']   = 'Asiakas';
$_['column_ip']         = 'Ip';
$_['column_date_added'] = 'Päivä määrä lisätty';

// Entry
$_['entry_date_start']  = 'Alkamis päivä';
$_['entry_date_end']    = 'Päättymis päivä';
$_['entry_keyword']     = 'Avainsanan';
$_['entry_customer']    = 'Asiakas';
$_['entry_ip']          = 'Ip';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata asiakas hakuja raportti!';