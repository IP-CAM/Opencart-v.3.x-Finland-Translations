<?php
// Heading
$_['heading_title']    = 'Kuponkeja raportti';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_edit']        = 'Muokkaa kuponkeja-raportti';
$_['text_success']     = 'Menestys: olet muokannut kuponki raportti!';
$_['text_filter']      = 'Suodatin';

// Column
$_['column_name']      = 'Kupongin nimi';
$_['column_code']      = 'Koodi';
$_['column_orders']    = 'Tilaukset';
$_['column_total']     = 'Yhteensä';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_date_start'] = 'Alkamis päivä';
$_['entry_date_end']   = 'Päättymis päivä';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata kuponki raportti!';