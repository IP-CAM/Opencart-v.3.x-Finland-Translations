<?php
// Heading
$_['heading_title']                = 'Asiakkaan toiminta raportti';

// Text
$_['text_extension']               = 'Tiedostopääte';
$_['text_edit']                    = 'Muokkaa asiakas aktiviteetti raporttia';
$_['text_success']                 = 'Onnistui: olet muokannut asiakas aktiviteetti raporttia!';
$_['text_filter']                  = 'Suodatin';
$_['text_activity_register']       = '<a href="customer_id=%d">%s</a> rekisteröity tili.';
$_['text_activity_edit']           = '<a href="customer_id=%d">%s</a> päivittäneet tili tietonsa.';
$_['text_activity_password']       = '<a href="customer_id=%d">%s</a> päivittänyt tilinsä Sala sanan.';
$_['text_activity_reset']          = '<a href="customer_id=%d">%s</a> Nollaa tilinsä sala sana.';
$_['text_activity_login']          = '<a href="customer_id=%d">%s</a> kirjautunut sisään.';
$_['text_activity_forgotten']      = '<a href="customer_id=%d">%s</a> pyysi Sala sanan palauttamista.';
$_['text_activity_address_add']    = '<a href="customer_id=%d">%s</a> lisätty uusi osoite.';
$_['text_activity_address_edit']   = '<a href="customer_id=%d">%s</a> päivitetty niiden osoite.';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a> poistanut jonkin niiden osoitteista.';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a> toimittanut tuotteen palautuksen.';
$_['text_activity_return_guest']   = '%s toimittanut tuotteen palautuksen.';
$_['text_activity_order_account']  = '<a href="customer_id=%d">%s</a> luonut <a href="order_id=%d">uusi tilaus</a>.';
$_['text_activity_order_guest']    = '%s luonut <a href="order_id=%d">uusi tilaus</a>.';
$_['text_activity_affiliate_add']  = '<a href="customer_id=%d">%s</a> rekisteröity affiliate-tilille.';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a> päivittänyt Affiliate tiedot.';
$_['text_activity_transaction']    = '<a href="customer_id=%d">%s</a> saanut komissiolta uuden <a href="order_id=%d">Tilaa</a>.';

// Column
$_['column_customer']              = 'Asiakas';
$_['column_comment']               = 'Kommentti';
$_['column_ip']                    = 'Ip';
$_['column_date_added']            = 'Päivä määrä lisätty';

// Entry
$_['entry_customer']               = 'Asiakas';
$_['entry_ip']                     = 'Ip';
$_['entry_date_start']             = 'Alkamis päivä';
$_['entry_date_end']               = 'Päättymis päivä';
$_['entry_status']                 = 'Tila';
$_['entry_sort_order']             = 'Lajittelujärjestyksen';

// Error
$_['error_permission']             = 'Varoitus: sinulla ei ole oikeutta muokata asiakas aktiviteetti raporttia!';