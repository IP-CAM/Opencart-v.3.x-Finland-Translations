<?php
// Heading
$_['heading_title']     = 'Palautus raportin';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_edit']         = 'Muokkaa palautus raporttia';
$_['text_success']      = 'Onnistui: olet muokannut palautus raporttia!';
$_['text_filter']       = 'Suodatin';
$_['text_year']         = 'Vuotta';
$_['text_month']        = 'Kuukautta';
$_['text_week']         = 'Viikkoa';
$_['text_day']          = 'Päivää';
$_['text_all_status']   = 'Kaikki tilat';

// Column
$_['column_date_start'] = 'Alkamis päivä';
$_['column_date_end']   = 'Päättymis päivä';
$_['column_returns']    = 'Ei. Palauttaa';

// Entry
$_['entry_date_start']  = 'Alkamis päivä';
$_['entry_date_end']    = 'Päättymis päivä';
$_['entry_group']       = 'Ryhmittely';
$_['entry_status']      = 'Palautuksen tila';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata palautus raporttia!';