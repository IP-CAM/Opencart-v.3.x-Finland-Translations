<?php
// Heading
$_['heading_title']         = 'Asiakas palkinto pisteiden raportti';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_edit']             = 'Muokkaa asiakkaan palkkio pisteitä-raportti';
$_['text_success']          = 'Onnistui: olet muokannut asiakas palkinto pisteiden raporttia!';
$_['text_filter']           = 'Suodatin';

// Column
$_['column_customer']       = 'Asiakkaan nimi';
$_['column_email']          = 'Sähköposti';
$_['column_customer_group'] = 'Asiakas ryhmä';
$_['column_status']         = 'Tila';
$_['column_points']         = 'Palkintopisteitä';
$_['column_orders']         = 'Ei. Tilaukset';
$_['column_total']          = 'Yhteensä';
$_['column_action']         = 'Toiminta';

// Entry
$_['entry_date_start']      = 'Alkamis päivä';
$_['entry_date_end']        = 'Päättymis päivä';
$_['entry_customer']        = 'Asiakas';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata asiakas palkinto pisteiden raporttia!';