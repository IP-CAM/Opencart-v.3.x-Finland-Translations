<?php
// Heading
$_['heading_title']    = 'Asiakkaita yhteensä';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: Dashboard-asiakas on muokattu.';
$_['text_edit']        = 'Muokkaa raportti näkymien asiakasta';
$_['text_view']        = 'Katso lisää...';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';
$_['entry_width']      = 'Leveys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata Dashboard-asiakasta!';