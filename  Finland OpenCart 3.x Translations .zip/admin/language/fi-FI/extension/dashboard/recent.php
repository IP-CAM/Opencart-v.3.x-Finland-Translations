<?php
// Heading
$_['heading_title']     = 'Viimeisimmät tila ukset';

// Text
$_['text_extension']    = 'Tiedostopääte';
$_['text_success']      = 'Menestys: olet muokannut koje laudan Viimeaikaiset tila ukset!';
$_['text_edit']         = 'Muokkaa koonti näyttöä Viimeaikaiset tila ukset';

// Column
$_['column_order_id']   = 'Tilauksen tunnus';
$_['column_customer']   = 'Asiakas';
$_['column_status']     = 'Tila';
$_['column_total']      = 'Yhteensä';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';


// Entry
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';
$_['entry_width']       = 'Leveys';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata Dashboard Viimeaikaiset tila ukset!';