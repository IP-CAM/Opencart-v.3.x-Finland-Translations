<?php
// Heading
$_['heading_title']    = 'Ihmiset online';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Dashboard online!';
$_['text_edit']        = 'Muokkaa koonti näyttöä verkossa';
$_['text_view']        = 'Katso lisää...';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';
$_['entry_width']      = 'Leveys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata Dashboard online!';