<?php
// Heading
$_['heading_title']    = 'Myynti Analytics';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: koje laudan kaaviota on muokattu!';
$_['text_edit']        = 'Koonti näytön kaavion muokkaaminen';
$_['text_order']       = 'Tilaukset';
$_['text_customer']    = 'Asiakkaat';
$_['text_day']         = 'Tänään';
$_['text_week']        = 'Viikolla';
$_['text_month']       = 'Kuukausi';
$_['text_year']        = 'Vuoden';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';
$_['entry_width']      = 'Leveys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole käyttö oikeuksia Dashboard-kaavion muokkaamiseen.';