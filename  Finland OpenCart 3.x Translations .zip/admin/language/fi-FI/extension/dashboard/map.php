<?php
// Heading
$_['heading_title']    = 'Maailman kartta';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut koje laudan karttaa!';
$_['text_edit']        = 'Muokkaa koonti näytön karttaa';
$_['text_order']       = 'Tilaukset';
$_['text_sale']        = 'Myynti';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';
$_['entry_width']      = 'Leveys';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Dashboard Map!';