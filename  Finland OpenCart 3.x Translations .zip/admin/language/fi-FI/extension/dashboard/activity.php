<?php
// Heading
$_['heading_title']                = 'Ajankohtaiset';

// Text
$_['text_extension']               = 'Tiedostopääte';
$_['text_success']                 = 'Onnistui: koonti näytön aktiviteettia on muokattu.';
$_['text_edit']                    = 'Muokkaa koonti näyttöä Viimeaikaiset aktiviteetit';
$_['text_activity_register']       = '<a href="customer_id=%d">%s</a> rekisteröitynyt uusi tili.';
$_['text_activity_edit']           = '<a href="customer_id=%d">%s</a> päivittäneet tili tietonsa.';
$_['text_activity_password']       = '<a href="customer_id=%d">%s</a> päivittänyt tilinsä Sala sanan.';
$_['text_activity_reset']          = '<a href="customer_id=%d">%s</a> Nollaa tilinsä sala sana.';
$_['text_activity_login']          = '<a href="customer_id=%d">%s</a> kirjautunut sisään.';
$_['text_activity_forgotten']      = '<a href="customer_id=%d">%s</a> on pyytänyt Sala sanan palauttamista.';
$_['text_activity_address_add']    = '<a href="customer_id=%d">%s</a> lisätty uusi osoite.';
$_['text_activity_address_edit']   = '<a href="customer_id=%d">%s</a> päivitetty niiden osoite.';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a> poistanut jonkin niiden osoitteista.';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a> lähettänyt tuotteen <a href="return_id=%d">Palauttaa</a>.';
$_['text_activity_return_guest']   = '%s lähettänyt tuotteen <a href="return_id=%d">Palauttaa</a>.';
$_['text_activity_order_account']  = '<a href="customer_id=%d">%s</a> lisäsi <a href="order_id=%d">uusi tilaus</a>.';
$_['text_activity_order_guest']    = '%s luonut <a href="order_id=%d">uusi tilaus</a>.';
$_['text_activity_affiliate_add']  = '<a href="customer_id=%d">%s</a> rekisteröity affiliate-tilille.';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a> päivittänyt Affiliate tiedot.';
$_['text_activity_transaction']    = '<a href="customer_id=%d">%s</a> saanut komissiolta uuden <a href="order_id=%d">Tilaa</a>.';

// Entry
$_['entry_status']                 = 'Tila';
$_['entry_sort_order']             = 'Lajittelujärjestyksen';
$_['entry_width']                  = 'Leveys';

// Error
$_['error_permission']             = 'Varoitus: sinulla ei ole oikeutta muokata koonti näytön toimintaa!';