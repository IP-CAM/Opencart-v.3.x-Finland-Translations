<?php
// Headings
$_['heading_title']        		= 'Marketplace-asetukset';
$_['text_openbay']              = 'Openbay Pro';
$_['text_etsy']                 = 'Etsy';

// Text
$_['text_success']     			= 'Asetukset on tallennettu';
$_['text_status']         		= 'Tila';
$_['text_account_ok']  			= 'Yhteys Etsy OK';
$_['text_token_register']       = 'Rekisteröidy';
$_['text_api_ok']       		= 'API-yhteys OK';
$_['text_pull_orders']    		= 'Vedä tila ukset';
$_['text_sync_settings']    	= 'Synkronoi asetukset';
$_['text_complete']    			= 'Täydellinen';
$_['text_failed']    			= 'Epäonnistui';
$_['text_orders_imported']    	= 'Tilaus vedä on pyydetty';
$_['text_api_status']           = 'API-yhteys';
$_['text_edit']           		= 'Muokkaa Etsy-asetuksia';
$_['text_register_banner']      = 'Klikkaa tästä jos sinun täytyy rekisteröityä tilin';

// Entry
$_['entry_import_def_id']       = 'Tuonnin oletus tila (maksamaton):';
$_['entry_import_paid_id']      = 'Maksettu tila:';
$_['entry_import_shipped_id']   = 'Lähetetty tila:';
$_['entry_encryption_key']      = 'Salaus avain 1';
$_['entry_encryption_iv']       = 'Salaus avain 2';
$_['entry_token']            	= 'API-tunnus';
$_['entry_address_format']      = 'Oletus osoitteen muoto';
$_['entry_debug']				= 'Ota lokiin kirjaaminen käyttöön';

// Error
$_['error_api_connect']         = 'Yhteyden muodostaminen API-liittymään epäonnistui';
$_['error_account_info']    	= 'Ei voi tarkistaa API yhteyden Etsy ';

// Tabs
$_['tab_api_info']            	= 'API-tiedot';

// Help
$_['help_address_format']  		= 'Käytetään vain, jos linkitetylle maalle ei ole jo määritetty osoite muotoa.';
$_['help_sync_settings']  		= 'Tämä päivittää tieto kannan uusimmat asetus vaihtoehdot, kuten ehto tyypit, päivä määrät ja paljon muuta.';
$_['help_pull_orders']  		= 'Tämä käynnistää uusien ja päivitettyjen tilausten manuaalisen tuomisen.';
