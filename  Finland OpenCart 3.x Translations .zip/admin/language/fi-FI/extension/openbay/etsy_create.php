<?php
// Headings
$_['heading_title']      	 = 'Uusi listaus';
$_['text_openbay']           = 'Openbay Pro';
$_['text_etsy']              = 'Etsy';

// Tabs
$_['tab_additional']      	 = 'Lisätietoja';

// Text
$_['text_option']      		 = 'Valitse vaihto ehto';
$_['text_category_selected'] = 'Valittu luokka';
$_['text_material_add']  	 = 'Lisää materiaalia';
$_['text_material_remove']   = 'Poista materiaali';
$_['text_tag_add']  		 = 'Lisää tunniste';
$_['text_tag_remove']  		 = 'Poista tunniste';
$_['text_created']  		 = 'Yritys tietosi on luotu';
$_['text_listing_id']  		 = 'Luettelon tunnus';
$_['text_img_upload']  		 = 'Ladataan kuvaa';
$_['text_img_upload_done']   = 'Ladattu kuva';
$_['text_create']  			 = 'Luo uusi Etsy listalle';

// Entry
$_['entry_title']      		 = 'Tuotteen nimi';
$_['entry_description']      = 'Kuvaus';
$_['entry_price']      		 = 'Hinta';
$_['entry_non_taxable']      = 'Ei verotettavaa';
$_['entry_category']     	 = 'Luokan valinta';
$_['entry_who_made']		 = 'Kuka sen teki?';
$_['entry_when_made']		 = 'Milloin se oli tehty?';
$_['entry_recipient']		 = 'Kenelle se on tarkoitettu?';
$_['entry_occasion']		 = 'Mihin tilaisuuteen se on tarkoitettu?';
$_['entry_is_supply']		 = 'Onko tämä tarjonta?';
$_['entry_state']      		 = 'Luettelon tila';
$_['entry_style']      		 = 'Tyyli Tag 1';
$_['entry_style_2']      	 = 'Tyyli Tag 2';
$_['entry_processing_min']   = 'Käsittely aika min';
$_['entry_processing_max']   = 'Käsittely aika enint.';
$_['entry_materials']  		 = 'Materiaalit';
$_['entry_tags']  			 = 'Tunnisteet';
$_['entry_shipping']  		 = 'Toimitus profiili';
$_['entry_shop']  			 = 'Shop-osa';
$_['entry_is_custom']  		 = 'Voiko se olla räätälöityjä?';
$_['entry_image']  			 = 'Pääkuva';
$_['entry_image_other']		 = 'Muita kuvia';

// Help
$_['help_description']		 = 'Kaikki HTML on poistettu kuva uksen, koska se ei tue Etsy';

// Errors
$_['error_no_shipping']  	 = 'Et ole setup mitään Shipping profiileja!';
$_['error_no_shop_secton']   = 'Et ole setup mitään Shop osia!';
$_['error_no_img_url']  	 = 'Ladattavaksi valittua kuvaa ei ole';
$_['error_no_listing_id']  	 = 'Luettelo tunnusta ei ole annettu';
$_['error_title_length']  	 = 'Otsikko on liian pitkä';
$_['error_title_missing']  	 = 'Otsikko puuttuu';
$_['error_desc_missing']  	 = 'Kuvaus puuttuu tai on tyhjä';
$_['error_price_missing']  	 = 'Hinta puuttuu tai on tyhjä';
$_['error_category']  		 = 'Luokkaa ei ole valittu';
$_['error_style_1_tag']  	 = 'Tyylin 1 tunniste ei kelpaa';
$_['error_style_2_tag']  	 = 'Tyylin 2 tunniste ei kelpaa';
$_['error_materials']  		 = 'Voit lisätä vain 13 materiaalia';
$_['error_tags']  			 = 'Voit lisätä vain 13 Tagit';
$_['error_stock_max']  		 = 'Suurin kalusto voit luettelo Etsy on 999, olet %s varastossa';
$_['error_image_max']  		 = 'Suurin määrä kuvia voit käyttää Etsy on 5, olet valinnut %s';
$_['error_variant']			 = 'Openbay Pro-Etsy.com ei vielä tue Variant-kohteita';