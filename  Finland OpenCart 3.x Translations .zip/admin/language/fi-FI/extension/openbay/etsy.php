<?php
// Heading
$_['heading_title']         = 'Etsy';
$_['text_openbay']			= 'Openbay Pro';
$_['text_dashboard']		= 'Etsy koje lauta';

// Messages
$_['text_success']         	= 'Olet tallentanut muutokset Etsy laajennus';
$_['text_heading_settings'] = 'Asetukset';
$_['text_heading_sync']     = 'Synkronoida';
$_['text_heading_register'] = 'Rekisteröidy tästä';
$_['text_heading_products'] = 'Kohteen linkit';
$_['text_heading_listings'] = 'Etsy listat';

// Errors
$_['error_generic_fail']	= 'Tuntematon virhe juuri tapahtunut!';
$_['error_permission']		= 'Sinulla ei ole oikeutta Etsy asetukset';