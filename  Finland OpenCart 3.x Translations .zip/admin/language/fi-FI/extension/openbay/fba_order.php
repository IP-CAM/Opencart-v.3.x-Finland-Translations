<?php
// Heading
$_['heading_title']					= 'Tilaukset';
$_['text_openbay']					= 'Openbay Pro';
$_['text_fba']						= 'Täyttäminen on Amazon';

// Buttons
$_['button_ship']        			= 'Aluksen toteutus';
$_['button_resend']					= 'Lähetä toteutus pyyntö uudelleen';

// Tab
$_['tab_history']        			= 'Pyydä historiaa';

// Entry
$_['entry_start_date']             	= 'Alkamis päivä (Format VVVV-KK-PP)';
$_['entry_end_date']             	= 'Päättymis päivä (muodossa VVVV-KK-PP)';
$_['entry_status']             		= 'Tila';

// Text
$_['text_no_results'] 				= 'Tila uksia ei löytynyt';
$_['text_fulfillment_list'] 		= 'Amazon täyttäminen List';
$_['text_option_all'] 				= 'Kaikki';
$_['text_option_new'] 				= 'Uusi/odottava';
$_['text_option_error'] 			= 'Virhe';
$_['text_option_held'] 				= 'Järjestetään';
$_['text_option_shipped'] 			= 'Toimitettu';
$_['text_option_cancelled'] 		= 'Peruutettu';
$_['text_order'] 					= 'Tila uksen tiedot';
$_['text_shipping_address'] 		= 'Toimitus osoite';
$_['text_history'] 					= 'Toteutus historia';
$_['text_opencart_order'] 			= 'Opentart-tilaus tunnus';
$_['text_order_info'] 				= 'Tilaus tiedot';
$_['text_status'] 					= 'Täyttymyksen tila';
$_['text_errors'] 					= 'Vastaus virheiden';
$_['text_show_errors'] 				= 'Näytä virheet';
$_['text_no_errors'] 				= 'Tälle toteutus pyynnölle ei ole virheitä';
$_['text_no_sku'] 					= 'Varastointi yksikköä ei löytynyt';
$_['text_show_request'] 			= 'Näytä pyynnön teksti';
$_['text_show_response'] 			= 'Näytä vasta uksen teksti';
$_['text_fulfillment_id'] 			= 'Täyttymyksen tunnus';
$_['text_type_new'] 				= 'Luoda';
$_['text_type_ship'] 				= 'Lähetyksen';
$_['text_type_cancel'] 				= 'Peruutus';
$_['text_no_requests'] 				= 'Pyyntöjä ei ole vielä tehty!';
$_['text_order_list']				= 'Amazon järjestys lista';


// Columns
$_['column_order_id'] 				= 'Tilauksen tunnus';
$_['column_created'] 				= 'Luotu';
$_['column_status'] 				= 'Tila';
$_['column_action'] 				= 'Toiminta';
$_['column_sku'] 					= 'Sku';
$_['column_product'] 				= 'Tuotteen';
$_['column_quantity'] 				= 'Määrä';
$_['column_fba'] 					= 'Amazon täyttäminen';
$_['column_fulfillment_id'] 		= 'Täyttäminen pyynnön viite';
$_['column_response_code'] 			= 'Vastaus koodi';
$_['column_actions'] 				= 'Toimia';
$_['column_type'] 					= 'Pyynnön tyyppi';
$_['column_fba_item_count'] 		= 'FBA-kohteiden määrä';
