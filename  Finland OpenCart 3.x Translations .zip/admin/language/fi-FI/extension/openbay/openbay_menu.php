<?php
// Text
$_['text_openbay_extension']           = 'Openbay Pro';
$_['text_openbay_dashboard']           = 'Dashboard';
$_['text_openbay_orders']              = 'Bulkki tilauksen päivitys';
$_['text_openbay_items']               = 'Hallitse kohteita';
$_['text_openbay_ebay']                = 'Ebay';
$_['text_openbay_amazon']              = 'Amazon (EU)';
$_['text_openbay_amazonus']            = 'Amazon (USA)';
$_['text_openbay_etsy']            	   = 'Etsy';
$_['text_openbay_settings']            = 'Asetukset';
$_['text_openbay_links']               = 'Kohteen linkit';
$_['text_openbay_report_price']        = 'Hinnoittelu raportti';
$_['text_openbay_order_import']        = 'Tilausten tuonti';
$_['text_openbay_fba']                 = 'Täyttäminen on Amazon';
$_['text_openbay_fulfillmentlist']     = 'Täytöistä';
$_['text_openbay_orderlist']           = 'Tilaukset';