<?php
// Heading
$_['heading_title']					     = 'Täytöistä';
$_['text_openbay']					     = 'Openbay Pro';
$_['text_fba']						     = 'Täyttäminen on Amazon';

// Buttons
//$_['button_pull_orders']        	     = 'Start';

// Entry
$_['entry_start_date']             		 = 'Alkamis päivä (Format VVVV-KK-PP)';

// Text
$_['text_no_results'] 					 = 'Ei täyttymystä löytyy Amazon';
$_['text_fulfillment_list'] 			 = 'Amazon täyttäminen List';

// Columns
$_['column_seller_fulfillment_order_id'] = 'Myyjän tilaus tunnus';
$_['column_displayable_order_id'] 		 = 'Näytettävän tila uksen tunnus';
$_['column_displayable_order_date'] 	 = 'Näytettävän päivä määrän ja kellon ajan';
$_['column_shipping_speed_category'] 	 = 'Toimitus nopeus';
$_['column_fulfillment_order_status'] 	 = 'Tila uksen tila';
$_['column_action'] 					 = 'Toiminta';

// Errors
//$_['error_validation']                 = 'You need to register for your API token and enable the module.';