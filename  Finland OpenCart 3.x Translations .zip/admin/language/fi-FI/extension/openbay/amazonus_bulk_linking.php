<?php
// Heading
$_['heading_title'] 			 = 'Bulk linkittäminen';
$_['text_openbay'] 				 = 'Openbay Pro';
$_['text_amazon'] 				 = 'Amazon USA';

// Button
$_['button_load'] 				 = 'Kuormitus';
$_['button_link'] 				 = 'Linkki';

// Text
$_['text_local'] 				 = 'Paikallisia';
$_['text_load_listings'] 		 = "Lastaus kaikki listat Amazon voi kestää jonkin aikaa (jopa 2 tuntia joissakin tapa uksissa). Jos linkität kohteita, varastossa tasoilla Amazon päivitetään oman myymälän varastossa tasolla.";
$_['text_report_requested'] 	 = 'Menestyksellisesti anomus haluttaa erotodistus polveutua Amatsoni';
$_['text_report_request_failed'] = 'Raportin luettelointi pyyntöä ei voi pyytää';
$_['text_loading'] 				 = 'Ladataan kohteita';

// Column
$_['column_asin'] 				 = 'Asin';
$_['column_price'] 				 = 'Hinta';
$_['column_name'] 				 = 'Nimi';
$_['column_sku'] 				 = 'Sku';
$_['column_quantity'] 			 = 'Määrä';
$_['column_combination'] 		 = 'Yhdistelmä';

// Error
$_['error_bulk_link_permission'] = 'Joukko linkitys ei ole käytettävissä suunnitelmassaan, Päivitä käyttää tätä ominaisuutta.';