<?php
// Heading
$_['heading_title']              = 'Nimikkeen tuonti';
$_['text_openbay']               = 'Openbay Pro';
$_['text_ebay']                  = 'Ebay';

// Text
$_['text_sync_import_line1']     = '<strong>Varoitus!</strong> Tämä tuo kaikki eBay tuotteita ja rakentaa luokan rakennetta omassa varastossa. On suositeltavaa, että poistat kaikki luokat ja tuotteet ennen tämän asetuksen suorittamista. <br />Luokka rakenne on normaalista eBay luokkia, ei Shop Luokat (jos sinulla on eBay Shop). Voit nimetä tuodut luokat uudelleen, poistaa ne ja muokata niitä vaikuttamatta eBay-tuotteisiin.';
$_['text_sync_import_line3']     = 'Sinun täytyy varmistaa, että palvelin voi hyväksyä ja käsitellä suuria post Data koot. 1000 eBay kohteita on noin 40MB kooltaan, sinun täytyy laskea, mitä tarvitset. Jos puhelu epäonnistuu niin se on todennäköisesti sinun asetus on liian pieni. Sinun php muisti raja on noin 128.';
$_['text_sync_server_size']      = 'Tällä hetkellä palvelin voi hyväksyä: ';
$_['text_sync_memory_size']      = 'Sinun php muisti kaventaa: ';
$_['text_import_confirm']		 = 'Tämä tuo kaikki eBay kohteita uusia tuotteita, Oletko varma? Tätä ei voi perua! Varmista, että sinulla on varmuus kopio ensimmäinen!';
$_['text_import_notify']		 = 'Tuonti pyyntösi on lähetetty käsiteltäväksi. Tuonti kestää noin 1 tunti per 1000 kohteita.';
$_['text_import_images_msg1']    = 'kuvat odottavat tuonti/kopio eBay. Päivitä tämä sivu, jos numero ei vähena';
$_['text_import_images_msg2']    = 'Klikkaa tästä';
$_['text_import_images_msg3']    = 'ja odota. Lisä tietoja siitä, miksi näin tapahtui, löytyy <a href="http://shop.openbaypro.com/index.php?route=information/faq&topic=8_45" target="_blank">Täällä</a>';

// Entry
$_['entry_import_item_advanced'] = 'Hanki lisä tietoja';
$_['entry_import_categories']    = 'Tuo luokat';
$_['entry_import_description']	 = 'Tuo nimike kuvaukset';
$_['entry_import']				 = 'Tuo eBay kohteet';

// Buttons
$_['button_import']				 = 'Tuoda';
$_['button_complete']			 = 'Täydellinen';

// Help
$_['help_import_item_advanced']  = 'Vie jopa 10 kertaa kauemmin tuoda kohteita. Tuotteiden painot, koot ja ISBN-tuonti, jos saatavilla';
$_['help_import_categories']     = 'Rakentaa luokan rakennetta oman myymälän eBay Kategoriat';
$_['help_import_description']    = 'Tämä tuo kaikki myös HTML, vierailu laskurit jne.';

// Error
$_['error_import']               = 'Lataaminen epäonnistui';
$_['error_maintenance']			 = 'Säilö on ylläpito tilassa. Tuominen epäonnistuu!';
$_['error_ajax_load']			 = 'Yhteyden muodostaminen palvelimeen epäonnistui';
$_['error_validation']			 = 'Te kaivata jotta kirja ajaksi sinun API tunnus ja mahdollistaa kerroin.';