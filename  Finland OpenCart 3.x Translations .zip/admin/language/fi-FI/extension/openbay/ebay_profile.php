<?php
// Heading
$_['heading_title']                                   = 'Profiilit';
$_['text_openbay']                                    = 'Openbay Pro';
$_['text_ebay']                                       = 'Ebay';

//Tabs
$_['tab_returns']          				              = 'Palauttaa';
$_['tab_template']         				              = 'Malli';
$_['tab_gallery']          				              = 'Galleria';
$_['tab_settings']         				              = 'Asetukset';

//Shipping Profile
$_['text_shipping_dispatch_country']                  = 'Toimitus maasta';
$_['text_shipping_postcode']                          = 'Posti numeron sijainti';
$_['text_shipping_location']                          = 'Kaupunki tai osavaltio sijainti';
$_['text_shipping_despatch']                          = 'Lähetys aika';
$_['text_shipping_despatch_help']                     = 'Tämä on kohteen lähettämiseen kuluva päivien enimmäismäärä';
$_['text_shipping_nat']                               = 'Kansalliset meri liikenne palvelut';
$_['text_shipping_intnat']                            = 'Kansainväliset lähetys palvelut';
$_['text_shipping_first']                             = 'Ensimmäinen kohde';
$_['text_shipping_add']                               = 'Muita kohteita';
$_['text_shipping_service']                           = 'Palvelu';
$_['text_shipping_in_desc']                           = 'Rahti tiedot kuva uksessa';
$_['text_shipping_getitfast']                         = 'Hanki se nopeasti!';
$_['text_shipping_zones']                             = 'Toimita vyöhykkeisiin';
$_['text_shipping_worldwide']                         = 'Maailmanlaajuisesti';
$_['text_shipping_type_nat']           	              = 'Kansallinen lähetys tyyppi';
$_['text_shipping_type_int']           	              = 'Kansainvälinen lähetys tyyppi';
$_['text_shipping_flat']           		              = 'Kiinteämääräinen';
$_['text_shipping_calculated']                        = 'Laskettu';
$_['text_shipping_freight']          	              = 'Rahti';
$_['text_shipping_handling']          	              = 'Käsittely maksu';
$_['text_shipping_cod']           		              = 'Posti ennakko maksu';
$_['text_shipping_handling_nat']    	              = 'Käsittely maksu (kansallinen)';
$_['entry_shipping_handling_int']    	              = 'Käsittely maksu (kansainvälinen)';
$_['entry_shipping_pickupdropoff']  	              = 'Klikkaa ja kerää';
$_['entry_shipping_pickupinstore']  	              = 'Saatavana myymälässä pickup';
$_['entry_shipping_global_shipping']  	              = 'Käytä eBay Global Shipping Service';
$_['entry_shipping_promotion_discount']               = 'Yhdistetyt lähetys alennukset (kansalliset)';
$_['entry_shipping_promotion_discount_international'] = 'Yhdistetyt toimitus alennukset (kansainvälinen)';

//Returns profile
$_['text_returns_accept']       		              = 'Palautukset hyväksytty';
$_['text_returns_inst']         		              = 'Palautus käytäntö';
$_['text_returns_days']         		              = 'Paluu päivät';
$_['text_returns_days10']       		              = '10 päivää';
$_['text_returns_days14']       		              = '14 päivää';
$_['text_returns_days30']       		              = '30 päivän';
$_['text_returns_days60']       		              = '60 päivää';
$_['text_returns_type']         		              = 'Palautus tyyppi';
$_['text_returns_type_money']   		              = 'Rahat takaisin';
$_['text_returns_type_exch']    		              = 'Rahat takaisin tai vaihtaa';
$_['text_returns_costs']        		              = 'Paluu posti kulut';
$_['text_returns_costs_b']      		              = 'Ostaja maksaa';
$_['text_returns_costs_s']      		              = 'Myyjä maksaa';
$_['text_returns_restock']      		              = 'Istutuksia maksu';
$_['text_list']           				              = 'Profiili luettelo';

//Template profile
$_['text_template_choose']      		              = 'Oletus malli';
$_['text_template_choose_help'] 		              = 'Oletus malli ladataan automaattisesti, kun listaus säästää aikaa';
$_['text_image_gallery']        		              = 'Gallerian kuva koko';
$_['text_image_gallery_help']   		              = 'Malli pohjaan lisättävien galleria kuvien pikseli koko.';
$_['text_image_thumb']          		              = 'Pienoiskuvan koko';
$_['text_image_thumb_help']     		              = 'Malliin lisättävien miniatyyri kuvien pikseli koko.';
$_['text_image_super']          		              = 'Supersize kuvat';
$_['text_image_gallery_plus']   		              = 'Galleria Plus';
$_['text_image_all_ebay']       		              = 'Lisää kaikki kuvat eBay';
$_['text_image_all_template']   		              = 'Lisää kaikki kuvat malliin';
$_['text_image_exclude_default']		              = 'Ohita oletus kuva';
$_['text_image_exclude_default_help']	              = 'Vain irtotavarana listalle ominaisuus! Ei sisällä oletus arvoista tuote kuvaa teema kuva luettelossa';
$_['text_confirm_delete']       		              = 'Haluatko varmasti poistaa profiilin?';
$_['text_width']      					              = 'Leveys';
$_['text_height']      					              = 'Korkeus';
$_['text_px']      						              = 'Px';
$_['text_add']      					              = 'Lisää profiili';
$_['text_edit']      					              = 'Muokkaa profiilia';

//General profile
$_['text_general_private']      		              = 'Luettelo kohteet yksityisinä huuto kaupaina';
$_['text_general_price']        		              = 'Hinta% muutos';
$_['text_general_price_help']   		              = '0 on oletuksena,-10 vähenee 10%, 10 kasvaa 10% (käytetään vain irtotavarana listalle)';

//General profile options
$_['text_profile_name']         		              = 'Nimi';
$_['text_profile_default']      		              = 'Oletus';
$_['text_profile_type']         		              = 'Tyyppi';
$_['text_profile_desc']         		              = 'Kuvaus';
$_['text_profile_action']       		              = 'Toiminta';

// Profile types
$_['text_type_shipping']       			              = 'Toimitus';
$_['text_type_returns']       			              = 'Palauttaa';
$_['text_type_template']       			              = 'Malli &amp; Galleria';
$_['text_type_general']       			              = 'Yleiset asetukset';

//Success messages
$_['text_added']                		              = 'Uusi profiili on lisätty';
$_['text_updated']              		              = 'Profiilia on päivitetty';

//Errors
$_['error_permission']        			              = 'Sinulla ei ole oikeuksia muokata profiileja';
$_['error_name']           				              = 'Sinun on kirjoitettava profiilin nimi';
$_['error_no_template']          		              = 'Mallin tunnusta ei ole';
$_['error_missing_settings'] 			              = 'Profiileja ei voi lisätä, muokata tai poistaa, ennen kuin voit syncroise eBay asetukset';

//Help
$_['help_shipping_promotion_discount']                = 'Tarjoa kansallisille ostajille alennusta meren kulusta, jos he ostavat useita kohteita. Alennukset on setup eBay voimaan.';
$_['help_shipping_promotion_discount_international']  = 'Tarjoa kansainvälisille ostajille alennusta meren kulusta, jos he ostavat useita tuotteita. Alennukset on setup eBay voimaan.';