<?php
// Headings
$_['heading_title']       = 'Muokkaa luetteloa';
$_['text_openbay']        = 'Openbay Pro';
$_['text_etsy']           = 'Etsy';

// Tabs

// Text
$_['text_option']      	  = 'Valitse vaihto ehto';
$_['text_listing_id']  	  = 'Luettelon tunnus';
$_['text_updated']  	  = 'Sinun Etsy listalle on päivitetty';
$_['text_edit']  		  = 'Päivitä Etsy listalle';

// Entry
$_['entry_title']      	  = 'Tuotteen nimi';
$_['entry_description']   = 'Kuvaus';
$_['entry_price']      	  = 'Hinta';
$_['entry_state']      	  = 'Valtion';

// Errors
$_['error_price_missing'] = 'Hinta puuttuu tai on tyhjä';
$_['error_title_length']  = 'Otsikko on liian pitkä';
$_['error_title_missing'] = 'Otsikko puuttuu';
$_['error_desc_missing']  = 'Kuvaus puuttuu tai on tyhjä';
$_['error_state_missing'] = 'Tila puuttuu tai on tyhjä';