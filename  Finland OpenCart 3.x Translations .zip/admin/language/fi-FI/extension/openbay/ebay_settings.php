<?php
// Heading
$_['heading_title']        		  = 'Marketplace-asetukset';
$_['text_openbay']				  = 'Openbay Pro';
$_['text_ebay']					  = 'Ebay';

// Text
$_['text_developer']				= 'Kehittäjä/support';
$_['text_app_settings']				= 'Sovelluksen asetukset';
$_['text_default_import']			= 'Tuonnin oletus asetukset';
$_['text_payments']					= 'Maksut';
$_['text_notify_settings']			= 'Ilmoituksen asetukset';
$_['text_listing']					= 'Luettelointi oletukset';
$_['text_token_renew']				= 'Uudista eBay Token';
$_['text_application_settings']		= 'Sovellus asetusten avulla voit määrittää, miten openbay Pro toimii ja integroituu järjestelmään.';
$_['text_import_description']		= 'Tila uksen tilan mukauttaminen eri vaiheissa. Et voi käyttää tilaa eBay-järjestyksessä, jota ei ole tässä luettelossa.';
$_['text_payments_description']		= 'Ennen täytät maksu vaihtoehdot uusia luetteloita, tämä säästää kirjoittamalla ne jokaisen uuden luettelon luot.';
$_['text_allocate_1']				= 'Kun asiakas ostaa';
$_['text_allocate_2']				= 'Kun asiakas oli maksanut';
$_['text_developer_description']	= 'Älä käytä tätä aluetta, ellei sinua ole';
$_['text_payment_paypal']			= 'PayPal hyväksytty';
$_['text_payment_paypal_add']		= 'PayPal Sähkö posti osoite';
$_['text_payment_cheque']			= 'Sekki hyväksytty';
$_['text_payment_card']				= 'Hyväksytyt kortit';
$_['text_payment_desc']				= 'Katso kuvaus (esim. pankki siirto)';
$_['text_tax_use_listing'] 			= 'Käytä vero kantaa asetettu eBay listalle';
$_['text_tax_use_value']			= 'Käytä Aseta arvo kaiken';
$_['text_tax_use_product']			= 'Laske vero ostajan maan ja tuotteen vero ryhmän perusteella';
$_['text_notifications']			= 'Hallitse, milloin asiakkaat saavat ilmoituksia sovelluksesta. Päivitys sähkö postien ottaminen käyttöön voi parantaa DSR-luokituksia, koska käyttäjä saa päivityksiä tila uksesta.';
$_['text_listing_1day']             = '1 päivä';
$_['text_listing_3day']             = '3 päivää';
$_['text_listing_5day']             = '5 päivää';
$_['text_listing_7day']             = '7 päivää';
$_['text_listing_10day']            = '10 päivää';
$_['text_listing_30day']            = '30 päivän';
$_['text_listing_gtc']              = 'GTC-hyvä till peruutettu';
$_['text_api_status']               = 'API-yhteyden tila';
$_['text_api_ok']                   = 'Yhteys OK, tunnus vanhenee';
$_['text_api_failed']               = 'Vahvistus epäonnistui';
$_['text_api_other']        		= 'Muut toimet';
$_['text_create_date_0']            = 'Kun lisätään openpart';
$_['text_create_date_1']            = 'Kun luodaan eBay';
$_['text_obp_detail_update']        = 'Päivitä säilön URL-osoite &amp; yhteys tiedot sähkö posti';
$_['text_success']					= 'Asetukset on tallennettu';
$_['text_edit']						= 'Muokkaa eBay-asetuksia';
$_['text_checking_details'] 		= 'Tarkistetaan tietoja';
$_['text_register_banner']          = 'Klikkaa tästä jos sinun täytyy rekisteröityä tilin';

// Entry
$_['entry_status']				  = 'Tila';
$_['entry_token']				  = 'API-tunnus';
$_['entry_secret']				  = 'Salainen';
$_['entry_encryption_key']        = 'Salaus avain 1';
$_['entry_encryption_iv']         = 'Salaus avain 2';
$_['entry_end_items']			  = 'Loppu kohteita?';
$_['entry_relist_items']		  = 'Relist kun takaisin varastoon?';
$_['entry_disable_soldout']		  = 'Poista tuote, kun ei varastossa?';
$_['entry_debug']				  = 'Ota lokiin kirjaaminen käyttöön';
$_['entry_currency']			  = 'Oletus valuutta';
$_['entry_stock_allocate']		  = 'Kohdista kalusto';
$_['entry_created_hours']		  = 'Uuden tila uksen ikäraja';
$_['entry_developer_locks']		  = 'Poistetaanko tilaus lukitukset?';
$_['entry_payment_instruction']	  = 'Maksu ohjeet';
$_['entry_payment_immediate']	  = 'Välitön maksu vaaditaan';
$_['entry_payment_types']		  = 'Maksu lajit';
$_['entry_brand_disable']		  = 'Poista tuote merkin linkki';
$_['entry_duration']			  = 'Oletus luettelon kesto';
$_['entry_measurement']			  = 'Mittaus järjestelmä';
$_['entry_address_format']		  = 'Oletus osoitteen muoto';
$_['entry_timezone_offset']		  = 'Aika vyöhykkeen siirtymä';
$_['entry_tax_listing']			  = 'Tuotteen vero';
$_['entry_tax']					  = 'Kaikkeen käytettävä vero prosentti';
$_['entry_create_date']			  = 'Uusien tilausten luonti päivämäärä';
$_['entry_notify_order_update']	  = 'Tila uksen päivitykset';
$_['entry_notify_buyer']		  = 'Uusi tilaus-ostaja';
$_['entry_notify_admin']		  = 'Uusi järjestys-admin';
$_['entry_import_pending']		  = 'Tuo maksamattomat tila ukset:';
$_['entry_import_def_id']		  = 'Tuonnin oletus tila:';
$_['entry_import_paid_id']		  = 'Maksettu tila:';
$_['entry_import_shipped_id']	  = 'Lähetetty tila:';
$_['entry_import_cancelled_id']	  = 'Peruutettu tila:';
$_['entry_import_refund_id']	  = 'Palautettu tila:';
$_['entry_import_part_refund_id'] = 'Osittain palautettu tila:';

// Tabs
$_['tab_api_info']				  = 'API-tiedot';
$_['tab_setup']					  = 'Asetukset';
$_['tab_defaults']				  = 'Luettelointi oletukset';

// Help
$_['help_disable_soldout']		  = 'Kun tuote myy pois se sitten poistaa tuotteen openpart';
$_['help_relist_items'] 		  = 'Jos nimike linkki oli olemassa, ennen kuin se luetteloi edellisen kohteen uudelleen, jos se on jälleen varastossa';
$_['help_end_items']    		  = 'Jos tuotteet myyvät pois, jos listalle on päättynyt eBayssa?';
$_['help_currency']     		  = 'Myymäläsi valuuttojen perusteella';
$_['help_created_hours']   		  = 'Tila ukset ovat uusia, kun tämän rajan nuorempi (tunteina). Oletus on 72';
$_['help_stock_allocate'] 		  = 'Milloin varasto varataan myymälästä?';
$_['help_payment_instruction']    = 'Olla mahdollisimman kuvaava. Vaatitko maksun tietyn ajan kuluessa? He maksavat maksaa kortilla? Onko sinulla mitään erityisiä maksu ehtoja?';
$_['help_payment_immediate'] 	  = 'Välitön maksu pysähtyy maksamattomat ostajat, koska tuote ei myydä, kunnes ne maksavat.';
$_['help_listing_tax']     		  = 'Jos käytät määrä listat varmistaa kohteita on oikea vero eBay';
$_['help_tax']             		  = 'Käytetään tuotaessa nimikkeitä tai tila uksia';
$_['help_duration']    			  = 'GTC on saatavilla vain on eBay Shop.';
$_['help_address_format']      	  = 'Käytetään vain, jos maa ei ole jo määritetty osoite muotoon.';
$_['help_create_date']         	  = 'Valitse, mikä luotu aika näkyy tila uksen yhteydessä, kun se tuodaan';
$_['help_timezone_offset']     	  = 'Perustuu tuntia. 0 on GMT-aika vyöhyke. Ainoa tehdas tokko eBay aika on käytetty ajaksi aste luomakunta.';
$_['help_notify_admin']   		  = 'Ilmoita kaupan ylläpitäjälle oletusarvoiseen uuteen tilaus sähkö postiin';
$_['help_notify_order_update']	  = 'Tämä on Automaattiset päivitykset, esimerkiksi jos päivität tila uksen eBay ja uusi tila päivitetään tallentaa automaattisesti.';
$_['help_notify_buyer']        	  = 'Ilmoita käyttäjälle oletusarvoiset uudet tilaus sähkö postit';
$_['help_measurement']        	  = 'Valitse, mitä mittaus järjestelmää haluat käyttää luetteloissa';

// Buttons
$_['button_update']               = 'Päivitys';
$_['button_repair_links']    	  = 'Korjaa nimikkeen linkit';

// Error
$_['error_api_connect']           = 'Yhteyden muodostaminen API-liittymään epäonnistui';
