<?php
// Heading
$_['heading_title']           = 'Kohteen linkit';
$_['text_openbay']			  = 'Openbay Pro';
$_['text_ebay']				  = 'Ebay';

// Buttons
$_['button_resync']           = 'Synkronoi uudelleen';
$_['button_check_unlinked']   = 'Poista linkitettyjen kohteiden valinta';
$_['button_remove_link']      = 'Poista linkki';

// Errors
$_['error_ajax_load']         = 'Sorry, ei voinut saada vastausta. Kokeile myöhemmin.';
$_['error_validation']        = 'Te kaivata jotta kirja ajaksi sinun API tunnus ja mahdollistaa kerroin.';
$_['error_no_listings']       = 'Linkitettyjä tuotteita ei löytynyt';
$_['error_link_value']        = 'Tuote linkki ei ole arvo';
$_['error_link_no_stock']     = 'Linkkiä ei voi luoda loppu nimikettä varten. Lopeta kohde manuaalisesti eBayssa.';
$_['error_subtract_setting']  = 'Tämä tuote on asetettu ei vähennä varastossa opencart.';

// Text
$_['text_linked_items']       = 'Linkitetyt kohteet';
$_['text_unlinked_items']     = 'Linkitlinkitetyt kohteet';
$_['text_alert_stock_local']  = 'EBay listalle päivitetään paikalliseen varastossa tasolla!';
$_['text_link_desc1']         = 'Linkitys kohteita mahdollistaa varaston valvonta eBay listat.';
$_['text_link_desc2']         = 'Jokaisen kohteen, joka on päivitetty paikallista kalustoa (varastossa käytettävissä opencart Store) päivittää eBay listalle';
$_['text_link_desc3']         = 'Paikallinen kalusto on varastossa, joka on saatavilla myydä. EBay varastossa tasot pitäisi vastata tähän.';
$_['text_link_desc4']         = 'Kohdistettu varastosi on nimikkeitä, jotka on myyty mutta joita ei ole vielä maksettu. Nämä erät olisi varattava eikä laskea käytettävissä varastossa tasolla.';
$_['text_text_linked_desc']   = 'Linkitetyt kohteet ovat opencart kohteita, jotka on linkki eBay listalle.';
$_['text_text_unlinked_desc'] = 'Linkitälinkitetyt kohteet ovat eBay-tilisi luetteloita, jotka eivät liity mihinkään opencart-tuotteeesi.';
$_['text_text_unlinked_info'] = 'Napsauta Tarkista linkitlinkitetyt kohteet-painiketta ja Etsi aktiiviset eBay-listaukset linkitetetyille kohteille. Tämä voi kestää kauan, jos sinulla on paljon eBay listat.';
$_['text_text_loading_items'] = 'Ladataan kohteita';
$_['text_failed']       	  = 'Lataaminen epäonnistui';
$_['text_limit_reached']      = 'Tarkastusten enimmäismäärä pyyntöä kohden saavutettiin, napsauta painiketta jatkaaksesi etsimistä';
$_['text_stock_error']        = 'Varasto virhe';
$_['text_listing_ended']      = 'Listaus päättyi';
$_['text_filter']             = 'Suodata tulokset';
$_['text_filter_title']       = 'Otsikko';
$_['text_filter_range']       = 'Stock Range';
$_['text_filter_range_from']  = 'Min';
$_['text_filter_range_to']    = 'Maks';
$_['text_filter_var']         = 'Sisällytä variantit';

// Tables
$_['column_action']           = 'Toiminta';
$_['column_status']           = 'Tila';
$_['column_variants']         = 'Vaihtoehdot';
$_['column_item_id']          = 'eBay tuote ID';
$_['column_product']          = 'Tuotteen';
$_['column_product_auto']     = 'Tuotteen nimi (automaattinen täydellinen)';
$_['column_listing_title']    = 'eBay listalle otsikko';
$_['column_allocated']        = 'Kohdistettu kalusto';
$_['column_ebay_stock']       = 'eBay Stock';
$_['column_stock_available']  = 'Shop Stock';
$_['column_stock_reserve']    = 'Vara uksen taso';