<?php
// Heading
$_['heading_title']			  = 'Tuonti tilausten';
$_['text_openbay']			  = 'Openbay Pro';
$_['text_ebay']				  = 'Ebay';

// Buttons
$_['button_pull_orders']      = 'Aloittaa';

// Entry
$_['entry_pull_orders']       = 'Vedä uudet tila ukset';

// Text
$_['text_sync_pull_notice']   = 'Tämä vetää uusia tila uksia edellisen automaattisen tarkistuksen jälkeen. Tokko te hankkia kohtuullinen asettaa niin muodoin se jälki säädös laiminlyöminen jotta kestää 24 aika.';
$_['text_ajax_orders_import'] = 'Kaikki uudet tila ukset pitäisi näkyä muutamassa minuutissa';
$_['text_complete']           = 'Tuonti pyydetty';
$_['text_failed']             = 'Lataaminen epäonnistui';
$_['text_pull']               = 'Pyydä manuaalista tuontia';

// Errors
$_['error_validation']        = 'Te kaivata jotta kirja ajaksi sinun API tunnus ja mahdollistaa kerroin.';