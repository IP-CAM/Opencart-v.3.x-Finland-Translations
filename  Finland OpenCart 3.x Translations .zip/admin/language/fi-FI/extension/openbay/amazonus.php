<?php
// Heading
$_['heading_title']         	  = 'Amazon USA';
$_['text_openbay']				  = 'Openbay Pro';
$_['text_dashboard']			  = 'Amatsoni objekti muoto koje lauta';

// Text
$_['text_heading_settings'] 	  = 'Asetukset';
$_['text_heading_account'] 		  = 'Muuta suunnitelmaa';
$_['text_heading_links'] 		  = 'Kohteen linkit';
$_['text_heading_register'] 	  = 'Rekisteröidy tästä';
$_['text_heading_bulk_listing']   = 'Bulk listaus';
$_['text_heading_stock_updates']  = 'Stock päivitykset';
$_['text_heading_saved_listings'] = 'Tallennetut listat';
$_['text_heading_bulk_linking']   = 'Bulk linkittäminen';
