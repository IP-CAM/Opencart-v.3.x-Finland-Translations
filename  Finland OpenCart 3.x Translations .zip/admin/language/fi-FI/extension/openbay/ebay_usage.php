<?php
// Headings
$_['heading_title']   = 'Käyttö';
$_['text_openbay']    = 'Openbay Pro';
$_['text_ebay']       = 'Ebay';

// Text
$_['text_usage']      = 'Tilin käyttö';

// Errors
$_['error_ajax_load'] = 'Sorry, ei voinut saada vastausta. Kokeile myöhemmin.';