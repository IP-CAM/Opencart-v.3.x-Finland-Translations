<?php
// Heading
$_['heading_title']        	= 'Stock päivitykset';
$_['text_openbay']			= 'Openbay Pro';
$_['text_amazon']			= 'Amazon USA';

// Text
$_['text_empty']            = 'Ei tuloksia!';

// Entry
$_['entry_date_start']      = 'Alkamis päivä';
$_['entry_date_end']        = 'Päättymis päivä';

// Column
$_['column_ref']            = 'Viite';
$_['column_date_requested'] = 'Pyydetty päivä määrä';
$_['column_date_updated']   = 'Päivä määrä päivitetty';
$_['column_status']         = 'Tila';
$_['column_sku']            = 'Amazon SKU';
$_['column_stock']          = 'Stock';

// Error
$_['error_api_connection']  = 'Ei voitu yhdistää API';