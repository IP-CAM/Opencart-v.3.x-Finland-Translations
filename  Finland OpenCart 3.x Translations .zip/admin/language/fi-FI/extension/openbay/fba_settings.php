<?php
// Headings
$_['heading_title']        	   = 'Asetukset';
$_['text_openbay']             = 'Openbay Pro';
$_['text_fba']                 = 'Täyttäminen on Amazon';

// Text
$_['text_success']     		   = 'Asetukset on tallennettu';
$_['text_status']         	   = 'Tila';
$_['text_account_ok']  		   = 'Yhteys täyttymystä Amazon OK';
$_['text_api_ok']       	   = 'API-yhteys OK';
$_['text_api_status']          = 'API-yhteys';
$_['text_edit']           	   = 'Muokkaa täyttymystä Amazon asetukset';
$_['text_standard']            = 'Standard';
$_['text_expedited']           = 'Nopeutettu';
$_['text_priority']            = 'Ensisijainen';
$_['text_fillorkill']          = 'Täyttää tai tappaa';
$_['text_fillall']             = 'Täytä kaikki';
$_['text_fillallavailable']    = 'Täytä kaikki käytettävissä olevat';
$_['text_prefix_warning']      = 'Älä muuta tätä asetusta, kun tila ukset on lähetetty Amazon, vain asettaa tämän, kun ensin asentaa.';
$_['text_disabled_cancel']     = 'Ei käytössä-Älä Peruuta automaattisesti täytöistä';
$_['text_validate_success']    = 'Sinun API tiedot toimivat oikein! Varmista, että asetukset on tallennettu, painamalla Tallenna-näppäintä.';
$_['text_register_banner']     = 'Klikkaa tästä jos sinun täytyy rekisteröityä tilin';

// Entry
$_['entry_api_key']            = 'API-tunnus';
$_['entry_encryption_key']     = 'Salaus avain 1';
$_['entry_encryption_iv']      = 'Salaus avain 2';
$_['entry_account_id']         = 'Tilin tunnus';
$_['entry_send_orders']        = 'Lähetä tila ukset automaattisesti';
$_['entry_fulfill_policy']     = 'Täyttäminen Policy';
$_['entry_shipping_speed']     = 'Oletusarvoinen toimitus nopeus';
$_['entry_debug_log']          = 'Ota käyttöön virheen korjauksen kirjaaminen';
$_['entry_new_order_status']   = 'Uusi toteutus käynnistin';
$_['entry_order_id_prefix']    = 'Tila uksen tunnuksen etuliite';
$_['entry_only_fill_complete'] = 'Kaikki erät on FBA';

// Help
$_['help_api_key']             = 'Tämä on API-tunnuksesi, Hanki se openbay Pro-tilisi alueelta';
$_['help_encryption_key']      = 'Tämä on salaus avaimesi #1, Hanki se openbay Pro-tilisi alueelta';
$_['help_encryption_iv']       = 'Tämä on salaus avaimesi #2, Hanki se openbay Pro-tilisi alueelta';
$_['help_account_id']          = 'Tämä on sen tilin tunnus, joka vastaa openbay Pron rekisteröityä Amazon-tiliä, Hanki se openbay Pro-tili alueelta';
$_['help_send_orders']  	   = 'Tila ukset sisältävät matching täyttämisestä Amazon tuotteet lähetetään Amazon automaattisesti';
$_['help_fulfill_policy']  	   = 'Oletus toteutus käytäntö (fillall-kaikki täyttö tilauksen fulfillable nimikkeet toimitetaan. Täyttö järjestys säilyy käsittely tilassa, kunnes kaikki tuotteet on joko lähetetty Amazonista tai myyjä on peruuttanut sen. Filllavailable-kaikki täyttö tilauksen fulfillable nimikkeet toimitetaan. Amazon on peruuttanut kaikki unfulfillable kohteet. fillorkill-Jos toimitus tilauksessa oleva nimike määritetään unfulfillable, ennen kuin mikään tila uksessa oleva lähetys siirtyy odottavaan tilaan (varasto yksiköiden keräys prosessi on aloitettu), koko tila uksen katsotaan unfulfillable. Jos toimitus tilauksessa oleva nimike kuitenkin määritetään unfulfillable sen jälkeen, kun tila uksen lähetys siirtyy odottavaan tilaan, Amazon peruuttaa niin suuren osan täyttö järjestyksestä kuin mahdollista.)';
$_['help_shipping_speed']  	   = 'Tämä on oletus toimitus nopeus luokka soveltaa uusia tila uksia, eri palvelu taso voi invelr eri kustannuksia';
$_['help_debug_log']  		   = 'Virheen korjauksen lokit tallentaa tiedot loki tiedostoon toiminnoista, joita moduuli tekee. Nyt kuluva pitäisi olla jäljelle mahdollistaa jotta auttaa hankkia aiheena-lta jokin arvoitus.';
$_['help_new_order_status']    = 'Tämä on tila uksen tila, joka käynnistää tila uksen, joka luodaan täyttymystä varten. Varmista, että tämä käyttää tilaa vasta, kun olet vastaanottanut maksun.';
$_['help_order_id_prefix']     = 'Ottaa tila uksen etuliite auttaa tunnistamaan tila uksia, jotka ovat tulleet teidän tallentaa eikä muista integraatiot. Tämä on erittäin hyödyllinen, kun kauppiaat myyvät monia markkina paikkoja ja käyttää FBA';
$_['help_only_fill_complete']  = 'Tämä sallii vain tilausten lähettämisen täyttymisestä, jos kaikki tila uksen kohteet vastaavat Amazon-kohteen täyttämistä. Jos jotakin nimikettä ei ole, koko tilaus jää täyttämättä.';

// Error
$_['error_api_connect']        = 'Yhteyden muodostaminen API-liittymään epäonnistui';
$_['error_account_info']       = 'Ei voi tarkistaa API-yhteyden täyttymystä Amazon ';
$_['error_api_key']    		   = 'API-tunnus on virheellinen';
$_['error_api_account_id']     = 'Tilin tunnus on virheellinen';
$_['error_encryption_key']     = 'Salaus avain #1 ei kelpaa';
$_['error_encryption_iv']      = 'Salaus avain #2 ei kelpaa';
$_['error_validation']    	   = 'Tietojen vahvistuksessa ilmeni virhe';

// Tabs
$_['tab_api_info']             = 'API-tiedot';

// Buttons
$_['button_verify']            = 'Tarkista tiedot';
