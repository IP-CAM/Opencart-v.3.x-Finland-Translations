<?php
// Heading
$_['heading_title'] 	  = 'Tallennetut listat';
$_['text_openbay'] 		  = 'Openbay Pro';
$_['text_amazon'] 		  = 'Amazon EU';

// Text
$_['text_description']    = 'Nyt kuluva on haluttaa-lta hedelmä lista joka aari paitsi ja valmis jotta olla uploaded jotta Amatsoni.';
$_['text_uploaded_alert'] = 'Tallennetut listaus (t) ladattu!';
$_['text_delete_confirm'] = 'Oletko varma?';
$_['text_complete']       = 'Listat Uploaded';

// Column
$_['column_name']         = 'Nimi';
$_['column_model']        = 'Malli';
$_['column_sku']          = 'Sku';
$_['column_amazon_sku']   = 'Amazon erä SKU';
$_['column_action']       = 'Toiminta';