<?php
// Heading
$_['heading_title']						= 'Täytöistä';
$_['text_openbay']						= 'Openbay Pro';
$_['text_fba']							= 'Täyttäminen on Amazon';
$_['heading_order_info']				= 'Tilaus tiedot';
$_['heading_products']					= 'Tuotteet';

// Entry
$_['entry_seller_fulfillment_order_id'] = 'Myyjän täyttäminen tilaus tunnus';
$_['entry_displayable_order_id']     	= 'Näytettävän tila uksen tunnus';
$_['entry_displayable_date']     		= 'Näytettävän päivä määrän ja kellon ajan';
$_['entry_displayable_comment']     	= 'Näytettävän kommentin';
$_['entry_shipping_speed_category']     = 'Toimitus nopeus luokka';
$_['entry_fulfillment_policy']     		= 'Täyttäminen Policy';
$_['entry_fulfillment_order_status']    = 'Tila';
$_['entry_notification_email_list']     = 'Ilmoitus postitus lista';
$_['entry_button_cancel']     			= 'Peruuta täyttäminen';
$_['entry_button_ship']     			= 'Aluksen toteutus';

// Text
$_['text_no_results'] 					= 'Ei täyttymystä löytyy Amazon';
$_['text_fulfillment_list'] 			= 'Amazon täyttäminen List';
$_['text_form'] 						= 'Amazon täyttäminen';
$_['text_ship_success'] 				= 'Toimitus on vahvistettu, se voi kestää muutaman minuutin Amazon päivittää';
$_['text_cancel_success'] 				= 'Täyttäminen on peruutettu, se voi kestää muutaman minuutin Amazon päivittää';
$_['text_cancel_confirm'] 				= 'Haluatko varmasti peruuttaa tämän täyttymyksen?';
$_['text_ship_confirm'] 				= 'Haluatko varmasti lähettää tämän täyttymyksen?';
$_['text_status'] 						= 'Täyttymyksen tila';
$_['text_fulfillment_sent'] 			= 'Täyttäminen on lähetetty!';
$_['text_fulfillment_shipped'] 			= 'Täyttäminen on lähetetty!';
$_['text_fulfillment_cancelled'] 		= 'Täyttäminen on peruutettu!';

// Columns
$_['column_sku'] 						= 'Sku';
$_['column_order_item_id'] 				= 'Tilaus nimikkeen tunnus';
$_['column_quantity'] 					= 'Määrä';
$_['column_cancelled_quantity'] 		= 'Peruutettu määrä';
$_['column_unfulfillable_quantity'] 	= 'Unfulfillable määrä';
$_['column_estimated_ship'] 			= 'Arvioitu alus';
$_['column_estimated_arrive'] 			= 'Arvioitu saapuminen';

// Errors
$_['error_loading_fulfillment']         = 'Oli ongelma saada täyttämisestä tilaus tiedot Amazon';
$_['error_ship']             			= 'Oli ongelma vahvistaa lähetyksen kanssa Amazon';
$_['error_cancel']             			= 'Oli ongelma peruuttamalla täyttymystä kanssa Amazon';
$_['error_missing_id']             		= 'Pyynnön tunnus puuttuu';
$_['error_no_shipping']             	= 'Toimitus tapaa ei löytynyt';
$_['error_no_items']             		= 'Tälle tilaukselle ei löytynyt kohteita';
$_['error_amazon_request']             	= 'Oli virhe vastaus Amazon, Tarkista virheet pyynnön';