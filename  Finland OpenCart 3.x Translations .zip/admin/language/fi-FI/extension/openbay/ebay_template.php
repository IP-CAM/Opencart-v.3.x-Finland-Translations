<?php
// Headings
$_['heading_title']       = 'Mallien luettelointi';
$_['text_ebay']           = 'Ebay';
$_['text_openbay']        = 'Openbay Pro';

// Columns
$_['column_name']         = 'Mallin nimi';
$_['column_action']       = 'Toiminta';

// Entry
$_['entry_template_name'] = 'Nimi';
$_['entry_template_html'] = 'Html';

// Text
$_['text_added']          = 'Uusi malli on lisätty';
$_['text_updated']        = 'Malli on päivitetty';
$_['text_deleted']        = 'Malli on poistettu';
$_['text_confirm_delete'] = 'Haluatko varmasti poistaa mallin?';
$_['text_list']           = 'Mallin luettelo';
$_['text_add']      	  = 'Lisää profiili';
$_['text_edit']      	  = 'Muokkaa profiilia';

// Error
$_['error_name']          = 'Sinun on syötettävä mallin nimi';
$_['error_permission']    = 'Sinulla ei ole oikeuksia muokata malleja';
$_['error_no_template']   = 'Mallin tunnusta ei ole';