<?php
// Heading
$_['heading_title']         	= 'Täyttäminen on Amazon';
$_['text_openbay']				= 'Openbay Pro';
$_['text_dashboard']			= 'Täyttäminen on Amazon Dashboard';

// Text
$_['text_heading_settings'] 	= 'Asetukset';
$_['text_heading_account'] 		= 'Tili/tilaus';
$_['text_heading_fulfillments'] = 'Täytöistä';
$_['text_heading_register'] 	= 'Rekisteröidy tästä';
$_['text_heading_orders'] 		= 'Tilaukset';
