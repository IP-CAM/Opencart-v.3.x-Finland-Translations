<?php
// Heading
$_['heading_title']         	   = 'Ebay';
$_['text_openbay']				   = 'Openbay Pro';
$_['text_dashboard']			   = 'eBay koje lauta';

// Text
$_['text_success']         		   = 'Olet tallentanut muutokset eBay laajennus';
$_['text_heading_settings']        = 'Asetukset';
$_['text_heading_sync']            = 'Synkronoida';
$_['text_heading_subscription']    = 'Muuta suunnitelmaa';
$_['text_heading_usage']           = 'Käyttö';
$_['text_heading_links']           = 'Kohteen linkit';
$_['text_heading_item_import']     = 'Tuo kohteet';
$_['text_heading_order_import']    = 'Tuonti tilausten';
$_['text_heading_adds']            = 'Asennetut lisä osat';
$_['text_heading_summary']         = 'eBay Yhteenveto';
$_['text_heading_profile']         = 'Profiilit';
$_['text_heading_template']        = 'Malleja';
$_['text_heading_ebayacc']         = 'eBay tili';
$_['text_heading_register']        = 'Rekisteröidy tästä';

// Error
$_['error_category_nosuggestions'] = 'Ehdotettuja luokkia ei voitu ladata';
$_['error_loading_catalog']        = 'eBay Catalog haku epäonnistui';
$_['error_generic_fail']           = 'Tuntematon virhe juuri tapahtunut!';
$_['error_no_products']         	= 'Tuotteita ei löytynyt';