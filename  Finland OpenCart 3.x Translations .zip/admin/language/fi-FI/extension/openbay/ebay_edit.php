<?php
// Heading
$_['heading_title']				   = 'Korjaa eBay listaus';
$_['text_openbay']				   = 'Openbay Pro';
$_['text_ebay']					   = 'Ebay';

// Tab
$_['tab_recommendations']		   = 'Suosituksia';

// Text
$_['text_revise']                  = 'Muokkaa luetteloa';
$_['text_loading']                 = 'Getting kohteen tiedot eBay';
$_['text_error_loading']           = 'Oli virhe saada tietoa eBay';
$_['text_saved']                   = 'Listaus on tallennettu';
$_['text_alert_removed']           = 'Listaus on linkittettynä';
$_['text_alert_ended']             = 'Listaus on päättynyt eBayssa';
$_['text_listing_info']            = 'Listaus tiedot';
$_['text_check_recommendations']   = 'Tarkistaminen eBay listalle suositukset';
$_['text_success_recommendations'] = 'Ei listaus parannus suosituksia tälle kohteelle!';

// Buttons
$_['button_view']				   = 'Näytä listaus';
$_['button_remove']				   = 'Poista linkki';
$_['button_end']                   = 'Lopeta listaus';
$_['button_retry']				   = 'Yritä';

// Entry
$_['entry_title']				   = 'Otsikko';
$_['entry_price']				   = 'Myynti hinta (sisältää verot)';
$_['entry_stock_store']			   = 'Paikallinen kalusto';
$_['entry_stock_listed']		   = 'eBay Stock';
$_['entry_stock_reserve']		   = 'Vara uksen taso';
$_['entry_stock_matrix_active']	   = 'Stock Matrix (aktiivinen)';
$_['entry_stock_matrix_inactive']  = 'Stock Matrix (passiivinen)';

// Column
$_['column_sku']				   = 'Sku';
$_['column_stock_listed']		   = 'Lueteltu';
$_['column_stock_reserve']		   = 'Varaus';
$_['column_stock_total']		   = 'Varastossa';
$_['column_price']				   = 'Hinta';
$_['column_status']				   = 'Aktiivinen';
$_['column_add']				   = 'Lisää';
$_['column_combination']		   = 'Yhdistelmä';

// Help
$_['help_stock_store']			   = 'Tämä on taso varastossa on opencart';
$_['help_stock_listed']			   = 'Tämä on nykyinen taso varastossa eBayssa';
$_['help_stock_reserve']		   = 'Tämä on enimmäismäärä varastossa eBay (0 = ei Reserve Limit)';

// Error
$_['error_ended']				   = 'Linkitetyt tiedot ovat päättyneet, et voi muokata sitä. Poista linkki.';
$_['error_reserve']				   = 'Et voi määrittää varausta, joka on suurempi kuin paikallinen';
$_['error_no_sku']          	   = 'Varastointi yksikköä ei löytynyt!';
$_['error_no_item_id']             = 'Pyynnön nimike tunnus puuttuu';
$_['error_recommendations_load']   = 'Nimike suosituksia ei voi ladata';