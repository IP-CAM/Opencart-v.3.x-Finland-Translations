<?php
// Heading
$_['heading_title']         = 'Synkronoida';
$_['text_openbay']          = 'Openbay Pro';
$_['text_ebay']             = 'Ebay';

// Buttons
$_['button_update']			= 'Päivitys';

// Entry
$_['entry_sync_categories'] = 'Hanki eBay Kategoriat';
$_['entry_sync_shop']       = 'Hanki Kauppa Kategoriat';
$_['entry_sync_setting']    = 'Hae asetukset';

// Text
$_['text_complete']         = 'Täydellinen';
$_['text_sync_desc']        = 'Synkronoi tallentaa uusimman saatavilla meren kulun ja luokat vaihto ehtoja eBay, nämä tiedot on vain vaihto ehtoja, kun luetellaan kohteen eBay-se ei tuo luokkia sinun säilyttää jne.';
$_['text_ebay_categories']  = 'Tämä voi kestää jonkin aikaa, odota 5 minuuttia, ennen kuin teet mitään muuta.';
$_['text_category_import']  = 'EBay Shop luokat on tuotu.';
$_['text_setting_import']   = 'Asetukset on tuotu.';
$_['text_sync']  			= 'Päivitä asetukset eBay';

// Help
$_['help_sync_categories']  = 'Tämä ei tuo mitään luokkia sinun säilyttää!';
$_['help_sync_shop']   		= 'Tämä ei tuo mitään luokkia sinun säilyttää!';
$_['help_sync_setting']		= 'Tämä tuonti käytettävissä olevat maksu lajit, toimitus, sijainnit ja paljon muuta.';

// Errors
$_['error_settings']		= 'Virhe ladattaessa asetuksia.';
$_['error_failed']          = 'Lataaminen epäonnistui';