<?php
// Heading
$_['heading_title'] 			  = 'Uusi Amazon listaus';
$_['text_title_advanced'] 		  = 'Tarkennettu listaus';
$_['text_openbay'] 				  = 'Openbay Pro';
$_['text_amazon'] 				  = 'Amazon EU';

// Buttons
$_['button_new'] 				  = 'Luo uusi tuote';
$_['button_amazon_price'] 		  = 'Hanki Amazon hinta';
$_['button_list'] 				  = 'Luettelo Amazon';
$_['button_remove_error'] 		  = 'Virhe sanomien poistaminen';
$_['button_save_upload'] 		  = 'Tallenna ja Lataa';
$_['button_browse'] 			  = 'Selaa';
$_['button_saved_listings'] 	  = 'Tallennettujen luetteloiden tarkasteleminen';
$_['button_remove_links'] 		  = 'Linkkien poistaminen';
$_['button_create_new_listing']   = 'Luo uusi listaus';

// Help
$_['help_sku'] 					  = 'Kauppiaan määrittämä yksilöllinen tuote tunnus';
$_['help_restock_date'] 		  = 'Tämä on päivä määrä, jolloin voit toimittaa kaikki jälki tilatut nimikkeet asiakkaalle. Tämä päivä määrä ei saa olla suurempi kuin 30 päivää luetelluista tai saaduista tila uksista voidaan peruuttaa automaattisesti.';
$_['help_sale_price'] 			  = 'Myynti hinnalla on oltava alkamis-ja päättymis päivä';

// Text
$_['text_products_sent'] 		  = 'Tuotteet lähetettiin jalostukseen';
$_['button_view_on_amazon'] 	  = 'Näytä Amazon';
$_['text_list'] 				  = 'Luettelo Amazon';
$_['text_new'] 					  = 'Uusi';
$_['text_used_like_new'] 		  = 'Käytetty-kuin uusi';
$_['text_used_very_good'] 		  = 'Käytetty-erittäin hyvä';
$_['text_used_good'] 			  = 'Käytetty-hyvä';
$_['text_used_acceptable'] 		  = 'Käytetyt-hyväksyttävät';
$_['text_collectible_like_new']   = 'Keräily tuotteita kaltainen uusi';
$_['text_collectible_very_good']  = 'Keräily tuotteita-erittäin hyvä';
$_['text_collectible_good'] 	  = 'Keräily tuotteita-hyvä';
$_['text_collectible_acceptable'] = 'Keräily tuotteita-hyväksyttäviä';
$_['text_refurbished'] 			  = 'Kunnostettu';
$_['text_product_not_sent'] 	  = 'Tuotetta ei lähetetty Amazon. Syy: %s';
$_['text_not_in_catalog'] 		  = 'Tai, jos se ei ole luettelossa&nbsp;&nbsp;&nbsp;';
$_['text_placeholder_search'] 	  = 'Anna tuotteen nimi, UPC, EAN, ISBN tai Asin';
$_['text_placeholder_condition']  = 'Käytä tätä ruutua tuotteiden kunnon kuvaamiseen.';
$_['text_characters'] 			  = 'Merkkiä';
$_['text_uploaded'] 			  = 'Tallennetut listaus (t) ladattu!';
$_['text_saved_local'] 			  = 'Listaus tallennettu, mutta ei vielä ladattu';
$_['text_product_sent'] 		  = 'Tuote on onnistuneesti lähetetty Amazon.';
$_['text_links_removed'] 		  = 'Amazon tuote Linkit poistettu';
$_['text_product_links'] 		  = 'Tuote linkit';
$_['text_has_saved_listings'] 	  = 'Tämä tuote sisältää yhden tai useita tallennettuja luetteloita, joita ei ole ladattu';
$_['text_edit_heading'] 		  = 'Muokkaa luetteloa';
$_['text_germany'] 				  = 'Saksa';
$_['text_france'] 				  = 'Ranska';
$_['text_italy'] 				  = 'Italia';
$_['text_spain'] 				  = 'Espanja';
$_['text_united_kingdom'] 		  = 'Iso-Britannia';

// Columns
$_['column_image'] 				  = 'Kuva';
$_['column_asin'] 				  = 'Asin';
$_['column_price'] 				  = 'Hinta';
$_['column_action'] 			  = 'Toiminta';
$_['column_name'] 				  = 'Tuotteen nimi';
$_['column_model'] 				  = 'Malli';
$_['column_combination'] 		  = 'Variantti yhdistelmä';
$_['column_sku_variant'] 		  = 'Variantin SKU';
$_['column_sku'] 				  = 'Tuote koodi';
$_['column_amazon_sku'] 		  = 'Amazon erä SKU';

// Entry
$_['entry_sku'] 				  = 'Sku';
$_['entry_condition'] 			  = 'Kunnossa';
$_['entry_condition_note'] 		  = 'Ehto Huomautus';
$_['entry_price'] 				  = 'Hinta';
$_['entry_sale_price'] 			  = 'Myynti hinta';
$_['entry_sale_date'] 			  = 'Myynnin aika väli';
$_['entry_quantity'] 			  = 'Määrä';
$_['entry_start_selling'] 		  = 'Saatavilla päivä määrästä';
$_['entry_restock_date'] 		  = 'Lisää varasto päivä';
$_['entry_country_of_origin'] 	  = 'Alku Perämaa';
$_['entry_release_date'] 		  = 'Julkaisupäivä';
$_['entry_from'] 				  = 'Päivä määrä alkaen';
$_['entry_to'] 					  = 'Ajoittaa jotta';
$_['entry_product'] 			  = 'Listaus tuotteelle';
$_['entry_category'] 			  = 'Amazon luokka';
$_['entry_browse_node'] 		  = 'Valitse Selaa solmu';
$_['entry_marketplace'] 		  = 'Markkinoilla';

//Tabs
$_['tab_main'] 					  = 'Tärkein';
$_['tab_required'] 				  = 'Vaaditut tiedot';
$_['tab_additional'] 			  = 'Lisä asetukset';

// Error
$_['error_required'] 			  = 'Tämä kenttä on pakollinen!';
$_['error_not_saved'] 			  = 'Luetteloa ei tallennettu. Tarkista, että olet täyttänyt kaikki kentät';
$_['error_char_limit'] 			  = 'merkkiä rajan yli';
$_['error_length'] 				  = 'Minimi pituus on';
$_['error_upload_failed'] 		  = 'Lataaminen epäonnistui tuotteen SKU: "%s". Syy: "%s"Lataaminen prosessi peruutettiin.';
$_['error_load_nodes'] 			  = 'Selaus solmujen lataaminen ei onnistu';
$_['error_connecting'] 			  = 'Virhe muodostettaessa yhteyttä API-liittymään. Tarkista openbay Pro Amazon laajennus asetukset. Jos ongelma toistuu, ota yhteyttä tukeen.';
$_['error_text_missing'] 		  = 'Sinun on annettava joitakin haku tietoja';
$_['error_missing_asin'] 		  = 'Asin puuttuu';
$_['error_marketplace_missing']   = 'Valitse kauppa paikka';
$_['error_condition_missing'] 	  = 'Valitse ehto';
$_['error_amazon_price'] 		  = 'Ei voinut saada hinta Amazon';
$_['error_stock'] 				  = 'Et voi luetella nimikettä, jonka varastossa on vähemmän kuin 1 nimikettä';
$_['error_sku'] 				  = 'Nimikkeelle on syötettävä SKU';
$_['error_price'] 				  = 'Nimikkeelle on annettava hinta';
$_['error_sending_products'] 	  = 'Luettelon tuotteiden lähettäminen ei onnistunut. Ota yhteyttä tukeen';
$_['error_no_products_selected']  = 'Tuotteita ei valittu listalle';
$_['error_not_searched'] 		  = 'Etsi vastaavia kohteita ennen kuin yrität luetella. Kohteet on täsmäytetty Amazon Catalog-kohteen kanssa';