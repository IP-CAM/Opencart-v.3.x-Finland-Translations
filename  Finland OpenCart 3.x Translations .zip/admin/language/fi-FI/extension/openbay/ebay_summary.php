<?php
// Heading
$_['heading_title']        = 'Yhteenveto';
$_['text_openbay']         = 'Openbay Pro';
$_['text_ebay']            = 'Ebay';

// Text
$_['text_use_desc']        = 'Tämä on eBay-tilin yhteenveto-sivu. Se on nopea katsaus kaikista rajoituksista tilillesi yhdessä teidän DSR myynti suoritus kykyä.';
$_['text_ebay_limit_head'] = 'EBay-tilillä on myynti rajoituksia!';
$_['text_ebay_limit_t1']   = 'Voit myydä';
$_['text_ebay_limit_t2']   = 'Lisää kohteita (tämä on kokonaismäärä eriä, ei yksittäisiä luetteloita) arvoon';
$_['text_ebay_limit_t3']   = 'Kun yrität luoda uusia luetteloita, se epäonnistuu, jos ylität edellä mainitut summat.';
$_['text_as_described']    = 'Kohde kuvatulla tavalla';
$_['text_communication']   = 'Viestintä';
$_['text_shippingtime']    = 'Toimitus aika';
$_['text_shipping_charge'] = 'Postikulut';
$_['text_score']           = 'Pisteet';
$_['text_count']           = 'Laskea';
$_['text_report_30']       = '30 päivän';
$_['text_report_52']       = '52 viikkoa';
$_['text_title_dsr']       = 'DSR-raportit';
$_['text_failed']          = 'Lataaminen epäonnistui';
$_['text_summary']         = 'Näytä eBay Yhteenveto';

// Error
$_['error_validation']     = 'Te kaivata jotta kirja ajaksi sinun API tunnus ja mahdollistaa kerroin.';
$_['error_ajax_load']      = 'Valitettavasti yhteys palvelimeen epäonnistui';