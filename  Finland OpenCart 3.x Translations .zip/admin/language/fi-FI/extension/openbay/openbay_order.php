<?php
// Heading
$_['heading_title']   		   = 'Bulkki tilauksen päivitys';
$_['text_openbay']             = 'Openbay Pro';
$_['text_confirm_title']       = 'Tarkista bulkki tilan päivitys';

// Button
$_['button_status']            = 'Muuta tila';
$_['button_update']            = 'Päivitys';
$_['button_ship']              = 'Toimitus tilaus';

// Column
$_['column_channel']           = 'Tilaa kanava';
$_['column_additional']        = 'Lisä tietoja';
$_['column_comments']      	   = 'Kommentit';
$_['column_notify']        	   = 'Ilmoittaa';

// Text
$_['text_confirmed']           = '%s tila ukset on päivitetty';
$_['text_no_orders']           = 'Päivitystä varten valittuja tila uksia ei ole valittu';
$_['text_confirm_change_text'] = 'Tila uksen tilan muuttaminen';
$_['text_other']               = 'Muut';
$_['text_error_carrier_other'] = 'Tilaus puuttuu "muu harjoittaja" merkintä!';
$_['text_web']                 = 'Web';
$_['text_ebay']                = 'Ebay';
$_['text_amazon']              = 'Amazon EU';
$_['text_amazonus']            = 'Amazon USA';
$_['text_etsy']                = 'Etsy';
$_['text_list']				   = 'Tilaus luettelo';

// Entry
$_['entry_carrier']            = 'Harjoittaja';
$_['entry_tracking_no']        = 'Seuranta';
$_['entry_other']              = 'Muut';
$_['entry_date_added']         = 'Päivä määrä lisätty';
$_['entry_order_channel']      = 'Tilaa kanava';
