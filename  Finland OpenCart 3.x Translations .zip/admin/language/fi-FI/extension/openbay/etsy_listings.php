<?php
// Headings
$_['heading_title']        	  = 'Etsy listat';
$_['text_openbay']            = 'Openbay Pro';
$_['text_etsy']               = 'Etsy';

// Text
$_['text_link_saved']         = 'Kohde on linkitetty';
$_['text_activate']           = 'Aktivoida';
$_['text_deactivate']         = 'Poistaa';
$_['text_add_link']           = 'Lisää linkki';
$_['text_delete_link']        = 'Poista linkki';
$_['text_delete']         	  = 'Poista listaus';
$_['text_status_stock']       = 'Varasto ei synkronoitu';
$_['text_status_ok']          = 'Okei';
$_['text_status_nolink']      = 'Ole linkitetty';
$_['text_link_added']         = 'Tuote on linkitetty listautumis-';
$_['text_link_deleted']       = 'Tuote on poistettu luettelosta';
$_['text_item_ended']         = 'Kohde on poistettu Etsy';
$_['text_item_deactivated']   = 'Kohde on poistettu käytöstä Etsy';
$_['text_item_activated']     = 'Kohde on aktivoitu Etsy';
$_['text_confirm_end']        = 'Haluatko varmasti poistaa luettelon?';
$_['text_confirm_deactivate'] = 'Haluatko varmasti poistaa luettelon käytöstä?';
$_['text_confirm_activate']   = 'Haluatko varmasti aktivoida luettelon?';
$_['text_listings']     	  = 'Hallitse Etsy listat';
$_['text_active']     	      = 'Aktiivinen';
$_['text_inactive']     	  = 'Passiivinen';
$_['text_draft']     	      = 'Luonnos';
$_['text_expired']     	      = 'Vanhentunut';

// Columns
$_['column_listing_id']		  = 'Etsy tunnus';
$_['column_title']			  = 'Otsikko';
$_['column_listing_qty']	  = 'Luettelon määrä';
$_['column_store_qty']		  = 'Myymälän määrä';
$_['column_status']			  = 'Tila viesti';
$_['column_link_status']	  = 'Linkin tila';
$_['column_action']			  = 'Toiminta';

// Entry
$_['entry_limit']			  = 'Sivun rajoitus';
$_['entry_status']			  = 'Tila';
$_['entry_keywords']		  = 'Avainsanat';
$_['entry_name']			  = 'Tuotteen nimi';
$_['entry_etsy_id']			  = 'Etsy kohteen tunnus';

// Help
$_['help_keywords']			  = 'Avain sanat koskevat vain aktiivisia luetteloita';

// Error
$_['error_etsy']			  = 'Virhe! Etsy API vastaus: ';
$_['error_product_id']		  = 'Tuote tunnus vaaditaan';
$_['error_etsy_id']			  = 'Etsy kohteen tunnus vaaditaan';
