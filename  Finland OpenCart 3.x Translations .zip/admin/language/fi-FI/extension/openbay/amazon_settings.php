<?php
// Heading
$_['heading_title']        			 = 'Marketplace-asetukset';
$_['text_openbay']					 = 'Openbay Pro';
$_['text_amazon']					 = 'Amazon EU';
$_['text_edit']				         = 'Muokkaa Amazon EU asetukset';

// Text
$_['text_api_status']                = 'API-yhteyden tila';
$_['text_api_ok']                    = 'Yhteys OK, auth OK';
$_['text_api_auth_error']            = 'Yhteys OK, todennus epäonnistui';
$_['text_api_error']                 = 'Yhteys virhe';
$_['text_order_statuses']            = 'Tila uksen tilat';
$_['text_unshipped']                 = 'Unlähetetty';
$_['text_partially_shipped']         = 'Osittain toimitettu';
$_['text_shipped']                   = 'Toimitettu';
$_['text_canceled']                  = 'Peruutettu';
$_['text_other']                     = 'Muut';
$_['text_marketplaces']              = 'Kauppapaikkoja';
$_['text_markets']                   = 'Valitse markkinat, joilta haluat tuoda tila ukset';
$_['text_de']                        = 'Saksa';
$_['text_fr']                        = 'Ranska';
$_['text_it']                        = 'Italia';
$_['text_es']                        = 'Espanja';
$_['text_uk']                        = 'Iso-Britannia';
$_['text_settings_updated']        	 = 'Asetukset päivitettiin onnistuneesti.';
$_['text_new'] 						 = 'Uusi';
$_['text_used_like_new'] 			 = 'Käytetty-kuin uusi';
$_['text_used_very_good'] 			 = 'Käytetty-erittäin hyvä';
$_['text_used_good'] 				 = 'Käytetty-hyvä';
$_['text_used_acceptable'] 			 = 'Käytetyt-hyväksyttävät';
$_['text_collectible_like_new'] 	 = 'Keräily tuotteita kaltainen uusi';
$_['text_collectible_very_good'] 	 = 'Keräily tuotteita-erittäin hyvä';
$_['text_collectible_good'] 		 = 'Keräily tuotteita-hyvä';
$_['text_collectible_acceptable'] 	 = 'Keräily tuotteita-hyväksyttäviä';
$_['text_refurbished'] 				 = 'Kunnostettu';
$_['text_register_banner']           = 'Klikkaa tästä jos sinun täytyy rekisteröityä tilin';

// Error
$_['error_permission']         		 = 'Sinulla ei ole tämän moduulin käyttö oikeutta';

// Entry
$_['entry_status']                 	 = 'Tila';
$_['entry_token']                    = 'API-tunnus';
$_['entry_encryption_key']           = 'Salaus avain 1';
$_['entry_encryption_iv']            = 'Salaus avain 2';
$_['entry_import_tax']               = 'Tuotujen nimikkeiden vero';
$_['entry_customer_group']           = 'Asiakas ryhmä';
$_['entry_tax_percentage']           = 'Muokkaa hintaa';
$_['entry_default_condition']        = 'Tuotteen oletus ehto tyyppi';
$_['entry_marketplace_default']		 = 'Oletus kauppa paikka';
$_['entry_notify_admin']             = 'Ilmoita uuden tila uksen ylläpitäjälle';
$_['entry_default_shipping']         = 'Oletus toimitus';

// Tabs
$_['tab_settings']            		 = 'API-tiedot';
$_['tab_listing']                  	 = 'Listat';
$_['tab_orders']                   	 = 'Tilaukset';

// Help
$_['help_import_tax']          		 = 'Käytetään, jos Amazon ei palauta vero tietoja';
$_['help_customer_group']      		 = 'Valitse tuoduille tila uksille määritettävä asiakas ryhmä';
$_['help_default_shipping']    		 = 'Käytetään esivalitussa vaihto ehdossa joukko tilauksen päivityksessä';
$_['help_entry_marketplace_default'] = 'Tuote luetteloiden ja hakujen oletus kauppa paikka';
$_['help_tax_percentage']            = 'Oletus tuotteen hintaan lisätty prosentti luku';
