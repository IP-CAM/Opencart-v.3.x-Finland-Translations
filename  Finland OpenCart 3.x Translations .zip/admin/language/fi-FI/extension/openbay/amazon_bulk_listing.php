<?php
// Heading
$_['heading_title'] 				= 'Bulk listaus';
$_['text_openbay'] 					= 'Openbay Pro';
$_['text_amazon'] 					= 'Amazon EU';

// Text
$_['text_searching'] 				= 'Etsiminen';
$_['text_finished'] 				= 'Valmis';
$_['text_marketplace'] 				= 'Markkinoilla';
$_['text_de'] 						= 'Saksa';
$_['text_fr'] 						= 'Ranska';
$_['text_es'] 						= 'Espanja';
$_['text_it'] 						= 'Italia';
$_['text_uk'] 						= 'Iso-Britannia';
$_['text_dont_list'] 				= 'Älä Luettele';
$_['text_listing_values'] 			= 'Listaus arvot';
$_['text_new'] 						= 'Uusi';
$_['text_used_like_new'] 			= 'Käytetty-kuin uusi';
$_['text_used_very_good'] 			= 'Käytetty-erittäin hyvä';
$_['text_used_good'] 				= 'Käytetty-hyvä';
$_['text_used_acceptable'] 			= 'Käytetyt-hyväksyttävät';
$_['text_collectible_like_new'] 	= 'Keräily tuotteita kaltainen uusi';
$_['text_collectible_very_good'] 	= 'Keräily tuotteita-erittäin hyvä';
$_['text_collectible_good'] 		= 'Keräily tuotteita-hyvä';
$_['text_collectible_acceptable'] 	= 'Keräily tuotteita-hyväksyttäviä';
$_['text_refurbished'] 				= 'Kunnostettu';

// Entry
$_['entry_condition'] 				= 'Kunnossa';
$_['entry_condition_note'] 			= 'Ehto Huomautus';
$_['entry_start_selling'] 			= 'Alkaa myydä';

// Column
$_['column_name'] 					= 'Nimi';
$_['column_image'] 					= 'Kuva';
$_['column_model'] 					= 'Malli';
$_['column_status'] 				= 'Tila';
$_['column_matches']				= 'Ottelut';
$_['column_result'] 				= 'Tulos';

// Button
$_['button_list'] 					= 'Luettelo';

// Error
$_['error_product_sku'] 			= 'Tuotteella on oltava SKU';
$_['error_searchable_fields'] 		= 'Tuotteella on oltava ISBN-, EAN-, UPC-tai Jan-kenttä täytetty';
$_['error_bulk_listing_permission'] = 'Bulk listalle ei ole saatavilla teidän suunnitelma, Päivitä käyttää tätä ominaisuutta.';
$_['error_select_items'] 			= 'Sinun on valittava vähintään 1 kohde, jotta voit etsiä';