<?php
// Heading
$_['heading_title']				= 'Kohteen linkit';
$_['text_openbay']				= 'Openbay Pro';
$_['text_amazon']				= 'Amazon USA';

// Text
$_['text_desc1']                = 'Linkitys kohteita mahdollistaa varastojen hallinnan teidän Amazon listat.';
$_['text_desc2'] 				= 'Jokaisen kohteen, joka on päivitetty paikallista kalustoa (varastossa käytettävissä opencart Store) päivittää Amazon listalle';
$_['text_desc3']                = 'Voit linkittää kohteita manuaalisesti syöttämällä Amazon SKU ja tuotteen nimi tai ladata kaikki linkitätä tuotteet ja kirjoita Amazon SKU. (uploading hedelmä polveutua openpart jotta Amatsoni jälki säädös automaattisesti kartuttaa kytkeä)';
$_['text_new_link']             = 'Uusi linkki';
$_['text_autocomplete_product'] = 'Tuote (automaattinen täydellinen nimestä)';
$_['text_amazon_sku']           = 'Amazon erä SKU';
$_['text_action']               = 'Toiminta';
$_['text_linked_items']         = 'Linkitetyt kohteet';
$_['text_unlinked_items']       = 'Linkitlinkitetyt kohteet';
$_['text_name']                 = 'Nimi';
$_['text_model']                = 'Malli';
$_['text_combination']          = 'Variantti yhdistelmä';
$_['text_sku']                  = 'Tuote koodi';
$_['text_sku_variant']          = 'Variantin SKU';

// Button
$_['button_load']               = 'Kuormitus';

// Error
$_['error_empty_sku']        	= 'Amazon SKU ei voi olla tyhjä!';
$_['error_empty_name']       	= 'Tuotteen nimi ei voi olla tyhjä!';
$_['error_no_product_exists']   = 'Tuotetta ei ole. Käytä automaattisia täydellisiä arvoja.';