<?php
// Heading
$_['heading_title']             = 'Tilaus';
$_['text_openbay']              = 'Openbay Pro';
$_['text_ebay']                 = 'Ebay';

// Buttons
$_['button_plan_change']  		= 'Muuta suunnitelmaksi';

// Columns
$_['column_plan']  				= 'Suunnitelman nimi';
$_['column_call_limit']  		= 'Puhelujen enimmäismäärä';
$_['column_price']  			= 'Hinta (p/kk)';
$_['column_description']  		= 'Kuvaus';
$_['column_current']  			= 'Nykyinen suunnitelma';

// Text
$_['text_subscription_current'] = 'Nykyinen suunnitelma';
$_['text_subscription_avail']   = 'Käytettävissä olevat suunnitelmat';
$_['text_subscription_avail1']  = 'Muuttuvat suunnitelmat ovat välittömiä ja käyttämättömät puhelut eivät hyvitetään.';
$_['text_ajax_acc_load_plan']   = 'PayPal-tilaus tunnus: ';
$_['text_ajax_acc_load_plan2']  = ', Peruuta kaikki muut tila ukset meiltä';
$_['text_load_my_plan']         = 'Suunnitelman lataaminen';
$_['text_load_plans']           = 'Käytettävissä olevien suunnitelmien lataaminen';
$_['text_subscription']         = 'Openbay Pro-tila uksen vaihtaminen';

// Errors
$_['error_ajax_load']      		= 'Sorry, ei voinut saada vastausta. Kokeile myöhemmin.';