<?php
// Heading
$_['heading_title'] 				  = 'Luetteloiden hallinta';

// Text
$_['text_markets']                    = 'Markkinoilla';
$_['text_openbay']                    = 'Openbay Pro';
$_['text_ebay'] 					  = 'Ebay';
$_['text_amazon'] 					  = 'Amazon EU';
$_['text_amazonus'] 				  = 'Amazon USA';
$_['text_etsy'] 					  = 'Etsy';
$_['text_status_all'] 				  = 'Kaikki';
$_['text_status_ebay_active'] 		  = 'eBay aktiivinen';
$_['text_status_ebay_inactive'] 	  = 'eBay ei aktiivinen';
$_['text_status_amazoneu_saved'] 	  = 'Amazon EU tallennettu';
$_['text_status_amazoneu_processing'] = 'Amazon EU Processing';
$_['text_status_amazoneu_active'] 	  = 'Amazon EU aktiivinen';
$_['text_status_amazoneu_notlisted']  = 'Amazon EU ei ole mainittu';
$_['text_status_amazoneu_failed'] 	  = 'Amazon EU epäonnistui';
$_['text_status_amazoneu_linked'] 	  = 'Amazon EU liittyy';
$_['text_status_amazoneu_notlinked']  = 'Amazon EU ei liity';
$_['text_status_amazonus_saved'] 	  = 'Amazon meille tallennettu';
$_['text_status_amazonus_processing'] = 'Amazon Yhdysvaltain Processing';
$_['text_status_amazonus_active'] 	  = 'Amazon Yhdysvaltain aktiivinen';
$_['text_status_amazonus_notlisted']  = 'Amazon USA ei ole mainittu';
$_['text_status_amazonus_failed'] 	  = 'Amazon USA epäonnistui';
$_['text_status_amazonus_linked'] 	  = 'Amazon USA liittyy';
$_['text_status_amazonus_notlinked']  = 'Amazon USA ei liity';
$_['text_processing']       		  = 'Käsittely';
$_['text_category_missing'] 		  = 'Puuttuva luokka';
$_['text_variations'] 				  = 'Muunnelmia';
$_['text_variations_stock'] 		  = 'Stock';
$_['text_min']                        = 'Min';
$_['text_max']                        = 'Maks';
$_['text_option']                     = 'Vaihtoehto';
$_['text_list']              		  = 'Tuote luettelo';

// Entry
$_['entry_title'] 					  = 'Otsikko';
$_['entry_model'] 					  = 'Malli';
$_['entry_manufacturer'] 			  = 'Valmistaja';
$_['entry_status'] 					  = 'Tila';
$_['entry_status_marketplace'] 		  = 'Marketplace-tila';
$_['entry_stock_range'] 			  = 'Stock Range';
$_['entry_category'] 				  = 'Luokka';
$_['entry_populated'] 				  = 'Asutuilla';
$_['entry_sku'] 					  = 'Sku';
$_['entry_description'] 			  = 'Kuvaus';

// Button
$_['button_error_fix']                = 'Virheiden korjaaminen';
$_['button_amazon_eu_bulk']           = 'Amazon EU Bulk upload';
$_['button_amazon_us_bulk']           = 'Amazon Yhdysvaltain Bulk upload';
$_['button_ebay_bulk']                = 'eBay Bulk upload';

// Error
$_['error_select_items']              = 'Sinun on valittava vähintään 1 kohde joukko luetteloon';