<?php
//Heading
$_['heading_title']                = 'Uudet listat';
$_['text_ebay']               	   = 'Ebay';
$_['text_openbay']                 = 'Openbay Pro';

// Buttons
$_['text_none']                    = 'Mikään';
$_['text_preview']                 = 'Esikatselu';
$_['text_add']                     = 'Lisää';
$_['text_preview_all']             = 'Tarkista kaikki';
$_['text_submit']                  = 'Lähetä';
$_['text_features']                = 'Ominaisuuksia';
$_['text_catalog']                 = 'Valitse luettelo';
$_['text_catalog_search']          = 'Etsi kuvasto';
$_['text_search_term']             = 'Haku termin';
$_['text_close']           		   = 'Lähellä';
$_['text_bulk']           		   = 'Uusien luetteloiden luominen irtotavarana';

//Form options / text
$_['text_pixels']                  = 'Pikseliä';
$_['text_other']                   = 'Muut';

//Profile names
$_['text_profile']            	   = 'Profiilit';
$_['text_profile_theme']           = 'Teema profiili';
$_['text_profile_shipping']        = 'Toimitus profiili';
$_['text_profile_returns']         = 'Palauttaa profiilin';
$_['text_profile_generic']         = 'Yleinen profiili';

// Text
$_['text_title']                   = 'Otsikko';
$_['text_price']                   = 'Hinta';
$_['text_stock']                   = 'Stock';
$_['text_search']                  = 'Etsi';
$_['text_loading']                 = 'Ladataan tietoja';
$_['text_preparing0']              = 'Valmistellaan';
$_['text_preparing1']              = 'ja';
$_['text_preparing2']              = 'Elementtejä';
$_['entry_condition']              = 'Kunnossa';
$_['text_duration']                = 'Kesto';
$_['text_category']                = 'Luokka';
$_['text_exists']                  = 'Jotkut kohteet ovat jo listattu eBay niin on poistettu';
$_['text_error_count']             = 'Olet valinnut %s kohteita, tietojen käsittely voi kestää jonkin aikaa';
$_['text_verifying']               = 'Tarkistetaan kohteita';
$_['text_processing']              = 'Käsittely <span id="activeItems"></span> Kohteita';
$_['text_listed']                  = 'Kohde listattu! Id: ';
$_['text_ajax_confirm_listing']    = 'Haluatko varmasti luetella nämä kohteet irtotavarana?';
$_['text_bulk_plan_error']         = 'Nykyinen suunnitelvasi ei salli joukko latauksia, Päivitä suunnitelvasi <a href="%s">Täällä</a>';
$_['text_item_limit']              = 'Et voi luetella näitä kohteita, kun ylität suunnitelma rajan, päivität suunnitelasi <a href="%s">Täällä</a>';
$_['text_search_text']             = 'Kirjoita haku teksti';
$_['text_catalog_no_products']     = 'Luettelo nimikkeitä ei löytynyt';
$_['text_search_failed']           = 'Haku epäonnistui';
$_['text_esc_key']                 = 'Splash Page on piilotettu, mutta ei ehkä ole valmis lastaus';
$_['text_loading_categories']      = 'Lastaus Kategoriat';
$_['text_loading_condition']       = 'Tuotteen olosuhteiden lataaminen';
$_['text_loading_duration']        = 'Luettelon keston lisääminen';
$_['text_total_fee']         	   = 'Palkkiot yhteensä';
$_['text_category_choose']         = 'Etsi Kategoria';
$_['text_suggested']         	   = 'Ehdotetut Kategoriat';
$_['text_product_identifiers']     = 'Tuote tunnukset';
$_['text_ean']    				   = 'Ean';
$_['text_upc']    				   = 'Upc';
$_['text_isbn']    				   = 'Isbn';
$_['text_identifier_not_required'] = 'Ei vaadita';

//Errors
$_['text_error_ship_profile']      = 'Sinun on määritettävä oletus toimitus profiili';
$_['text_error_generic_profile']   = 'Yleinen oletus profiili on määritettävä';
$_['text_error_return_profile']    = 'Oletus palautus profiili on määritettävä';
$_['text_error_theme_profile']     = 'Sinun täytyy olla oletus teema profiili perustettu';
$_['text_error_variants']          = 'Muunnelmat eivät voi olla bulkki luettelossa, ja niitä ei ole valittu';
$_['text_error_stock']             = 'Joitakin nimikkeitä ei ole varastossa, ja ne on poistettu';
$_['text_error_no_product']        = 'Joukko lähetys toiminnon käyttämiseen ei ole valittuja tukikelpoisia tuotteita';
$_['text_error_reverify']          = 'Virhe, sinun pitäisi muokata ja uudelleen tarkistaa kohteet';
$_['error_missing_settings']       = 'Et voi irtotavarana luettelo kohteita, kunnes syncronise eBay asetukset';
$_['text_error_no_selection']      = 'Sinun on valittava vähintään 1 kohde luetteloon';