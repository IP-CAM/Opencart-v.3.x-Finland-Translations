<?php
// Heading
$_['heading_title']                    = 'Oletus säilön teema';

// Text
$_['text_extension']                   = 'Tiedostopääte';
$_['text_success']                     = 'Menestys: olet muokannut default Store teema!';
$_['text_edit']                        = 'Muokkaa oletus säilön teemaa';
$_['text_general']                     = 'Yleiset ehdot';
$_['text_product']                     = 'Tuotteet';
$_['text_image']                       = 'Kuvia';

// Entry
$_['entry_directory']                  = 'Theme Directory';
$_['entry_status']                     = 'Tila';
$_['entry_product_limit']              = 'Oletus alkiot sivulla';
$_['entry_product_description_length'] = 'Luettelon kuvaus raja';
$_['entry_image_category']             = 'Luokan kuvan koko (l x k)';
$_['entry_image_thumb']                = 'Tuotteen kuva peukalon koko (l x k)';
$_['entry_image_popup']                = 'Tuotteen kuva-ikkunan koko (l x k)';
$_['entry_image_product']              = 'Tuote kuva luettelon koko (l x k)';
$_['entry_image_additional']           = 'Tuotteen lisä kuva koko (l x k)';
$_['entry_image_related']              = 'Liittyvä tuote kuva koko (l x k)';
$_['entry_image_compare']              = 'Vertaa kuvan kokoa (l x k)';
$_['entry_image_wishlist']             = 'Toive lista kuvan koko (l x k)';
$_['entry_image_cart']                 = 'Korin kuva koko (l x k)';
$_['entry_image_location']             = 'Säilytä kuvan koko (l x k)';
$_['entry_width']                      = 'Leveys';
$_['entry_height']                     = 'Korkeus';

// Help
$_['help_directory']                   = 'Tämä kenttä on vain, jotta vanhemmat Teemat on yhteensopiva uuden teeman järjestelmä. Te kanisteri asento aine osoite kalenteri jotta apu model after kuvastaa koko laskeva määritellä tähän.';
$_['help_product_limit']               = 'Määrittää, kuinka monta luettelo kohdetta sivulla näkyy (tuotteet, luokat jne.)';
$_['help_product_description_length']  = 'Luettelo näkymässä lyhyt kuvaus merkki rajoitus (Kategoriat, Special etc)';

// Error
$_['error_permission']                 = 'Varoitus: sinulla ei ole oikeutta muokata default Store teema!';
$_['error_limit']                      = 'Tuote raja tarvitaan!';
$_['error_image_thumb']                = 'Tuote kuva peukalo koko mitat tarvitaan!';
$_['error_image_popup']                = 'Tuote kuvan popup koko mitat tarvitaan!';
$_['error_image_product']              = 'Tuote luettelo koko mitat tarvitaan!';
$_['error_image_category']             = 'Luokka luettelo koko mitat tarvitaan!';
$_['error_image_additional']           = 'Lisä tietoja tuotteesta kuvan koko mitat tarvitaan!';
$_['error_image_related']              = 'Liittyvä tuote kuvan koko mitat tarvitaan!';
$_['error_image_compare']              = 'Vertaa kuvan kokoa mitat tarvitaan!';
$_['error_image_wishlist']             = 'Toive lista kuvan koko mitat tarvitaan!';
$_['error_image_cart']                 = 'Cart kuva koko mitat tarvitaan!';
$_['error_image_location']             = 'Säilytä kuvan koko mitat tarvitaan!';