<?php
// Heading
$_['heading_title']    = 'Käsittely maksu';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut käsittely maksu yhteensä!';
$_['text_edit']        = 'Muokkaa käsittely kuluja yhteensä';

// Entry
$_['entry_total']      = 'Tilausten kokonaismäärä';
$_['entry_fee']        = 'Maksu';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Help
$_['help_total']       = 'Tila uksen kokonaissummasta on päästävä, ennen kuin tämä tila uksen kokonaissumma aktivoituu.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata käsittely kuluja yhteensä!';