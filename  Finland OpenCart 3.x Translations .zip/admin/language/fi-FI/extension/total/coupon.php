<?php
// Heading
$_['heading_title']    = 'Kupongin';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut kuponki yhteensä!';
$_['text_edit']        = 'Muokkaa kuponkia';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata kuponki yhteensä!';