<?php
// Heading
$_['heading_title']    = 'Veroja';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut veroja yhteensä!';
$_['text_edit']        = 'Muokkaa ALV-summa';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata veroja yhteensä!';