<?php
// Heading
$_['heading_title']    = 'Klarna Fee';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Klarna Fee yhteensä!';
$_['text_edit']        = 'Muokkaa Klarna-maksua yhteensä';
$_['text_sweden']      = 'Ruotsi';
$_['text_norway']      = 'Norja';
$_['text_finland']     = 'Suomi';
$_['text_denmark']     = 'Tanska';
$_['text_germany']     = 'Saksa';
$_['text_netherlands'] = 'Alanko maat';

// Entry
$_['entry_total']      = 'Tilausten kokonaismäärä';
$_['entry_fee']        = 'Laskun maksu';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Klarna Fee yhteensä!';