<?php
// Heading
$_['heading_title']    = 'Yhteensä';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: olet muokannut kokonaissummia!';
$_['text_edit']        = 'Muokkaa yhteensä yhteensä';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muuttaa kokonaissummia!';