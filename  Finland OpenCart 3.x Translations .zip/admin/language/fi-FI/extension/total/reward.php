<?php
// Heading
$_['heading_title']    = 'Palkintopisteitä';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut palkita pistettä yhteensä!';
$_['text_edit']        = 'Muokkaa palkinto pisteitä yhteensä';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muuttaa palkinto pisteitä yhteensä!';