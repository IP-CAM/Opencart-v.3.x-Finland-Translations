<?php
// Heading
$_['heading_title']    = 'Säilytä luotto';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muokannut Store Credit yhteensä!';
$_['text_edit']        = 'Muokkaa myymälän kredit-summa';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Store Credit yhteensä!';