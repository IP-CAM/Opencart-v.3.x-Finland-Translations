<?php
// Heading
$_['heading_title']    = 'Lahjakortti';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Onnistui: olet muokannut lahja korttia yhteensä!';
$_['text_edit']        = 'Muokkaa lahja korttia yhteensä';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata lahja korttia yhteensä!';