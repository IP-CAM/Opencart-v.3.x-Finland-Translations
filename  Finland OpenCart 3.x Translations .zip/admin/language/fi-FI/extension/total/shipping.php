<?php
// Heading
$_['heading_title']    = 'Toimitus';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Shipping yhteensä!';
$_['text_edit']        = 'Muokkaa lähetyksen kokonaismäärää';

// Entry
$_['entry_estimator']  = 'Toimitus arviointi';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Shipping yhteensä!';