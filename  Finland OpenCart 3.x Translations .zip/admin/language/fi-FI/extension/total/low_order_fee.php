<?php
// Heading
$_['heading_title']    = 'Matala tilaus maksu';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut Low tilaus maksu yhteensä!';
$_['text_edit']        = 'Muokkaa vähäisen tila uksen palkkiota yhteensä';

// Entry
$_['entry_total']      = 'Tilausten kokonaismäärä';
$_['entry_fee']        = 'Maksu';
$_['entry_tax_class']  = 'Vero luokka';
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Help
$_['help_total']       = 'Tila uksen kokonaissummasta on päästävä, ennen kuin tämä tila uksen kokonaissumma on poistettu käytöstä.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muuttaa matalien tilausten maksua yhteensä!';
