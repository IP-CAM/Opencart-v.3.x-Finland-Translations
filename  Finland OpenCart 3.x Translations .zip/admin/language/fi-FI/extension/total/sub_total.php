<?php
// Heading
$_['heading_title']    = 'Väli summa';

// Text
$_['text_extension']   = 'Tiedostopääte';
$_['text_success']     = 'Menestys: olet muuttanut osa yhteensä!';
$_['text_edit']        = 'Muokkaa väli summa yhteensä';

// Entry
$_['entry_status']     = 'Tila';
$_['entry_sort_order'] = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata väli summa yhteensä!';