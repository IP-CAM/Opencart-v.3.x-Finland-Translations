<?php
// Heading
$_['heading_title']					 = 'PayPal Express Checkout';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']				 	 = 'Menestys: olet muokannut PayPal Express Checkout-tilin tiedot!';
$_['text_edit']                      = 'Muokkaa PayPal Express Checkout';
$_['text_pp_express']				 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization']			 = 'Lupa';
$_['text_sale']						 = 'Myynti';
$_['text_signup']                    = 'Rekisteröidy PayPal-Tallenna asetukset ensin tämä sivu päivittyy';
$_['text_sandbox']                   = 'Rekisteröidy PayPal Sandbox-Tallenna asetukset ensin tämä sivu päivittyy';
$_['text_configure_live']            = 'Määritä Live';
$_['text_configure_sandbox']         = 'Eristetyn kokoonpanon määrittäminen';
$_['text_show_advanced']             = 'Näytä lisä asetukset';
$_['text_show_quick_setup']          = 'Näytä pika-asetukset';
$_['text_quick_setup']             	 = 'Pika-asennus-Linkitä olemassa oleva tai luo uusi PayPal-tili, jotta voit aloittaa maksujen hyväksymisen muutamassa minuutissa';
$_['text_paypal_consent']		 	 = 'Käyttämällä Pika-asennus työkalua annat PayPalin saada tietoja myymälästä';
$_['text_success_connect']			 = 'Menestys: olet liittänyt PayPal-tilisi!';
$_['text_preferred_main']		 	 = 'Antaa ostajille yksinkertaistettu Checkout kokemus useita laitteita, jotka pitää ne paikalliset sivustoosi koko maksun lupa menettelyä';
$_['text_learn_more']			 	 = '(lisä tietoja)';
$_['text_preferred_li_1']			 = 'Aloita hyväksymällä PayPal kolmella napsautuksella';
$_['text_preferred_li_2']			 = 'Hyväksy maksuja ympäri maailmaa';
$_['text_preferred_li_3']			 = 'Tarjoa Express Checkout pikakuvake, kerroit ostajat kassalle suoraan ostos koriin sivu';
$_['text_preferred_li_4']			 = 'Paranna muuntaminen PayPal One Touch ja in-Context Checkout';
$_['text_connect_paypal']			 = 'Yhteyden PayPal';
$_['text_incontext_not_supported']	 = '* Ei tueta in-Context Checkout';
$_['text_retrieve']	 				 = 'Tietosi on syötetty PayPal';
$_['text_enable_button']			 = 'Suosittelemme tarjoaa PayPal Express pikakuvake maksimoida kassalle muuntaminen, tämän avulla asiakkaat voivat käyttää PayPal osoite kirjan ja <strong>Checkout on niin vähän kuin kolme hanat</strong> ostos korin sivulta. Valitse Ota asentaa laajentaminen ja pääsy Layout Manager, sinun Ned lisätä "PayPal Express Checkout-painiketta" kassalle layout';

// Entry
$_['entry_username']				 = 'API-käyttäjä nimi';
$_['entry_password']				 = 'API-sala sana';
$_['entry_signature']				 = 'API-allekirjoitus';
$_['entry_sandbox_username']		 = 'API Sandbox-käyttäjä nimi';
$_['entry_sandbox_password']		 = 'API Sandbox sala sana';
$_['entry_sandbox_signature']		 = 'API Sandbox allekirjoitus';
$_['entry_ipn']						 = 'IPN URL';
$_['entry_test']					 = 'Testi (eristetty) tila';
$_['entry_debug']					 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_currency']				 = 'Oletus valuutta';
$_['entry_recurring_cancel']	     = 'Salli asiakkaiden peruuttaa toistuvat maksut tili alueelta';
$_['entry_transaction']		         = 'Tilitys tyyppi';
$_['entry_total']					 = 'Yhteensä';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';
$_['entry_canceled_reversal_status'] = 'Peruutettu peruutuksen tila';
$_['entry_completed_status']		 = 'Valmis tila';
$_['entry_denied_status']			 = 'Evätty tila';
$_['entry_expired_status']			 = 'Vanhentunut tila';
$_['entry_failed_status']			 = 'Epäonnistunut tila';
$_['entry_pending_status']			 = 'Odottava tila';
$_['entry_processed_status']		 = 'Käsitelty tila';
$_['entry_refunded_status']			 = 'Palautettu tila';
$_['entry_reversed_status']			 = 'Palautettu tila';
$_['entry_voided_status']			 = 'Mitätöity tila';
$_['entry_allow_notes']				 = 'Salli muistiinpanot';
$_['entry_colour']	      			 = 'Sivun tausta väri';
$_['entry_logo']					 = 'Logo';
$_['entry_incontext']				 = 'Poista käytöstä in-Context Checkout';

// Tab
$_['tab_api']				         = 'API-tiedot';
$_['tab_order_status']				 = 'Tila uksen tila';
$_['tab_checkout']					 = 'Kassalle';

// Help
$_['help_ipn']						 = 'Pakollinen tila uksille';
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_logo']						 = 'Max 750px (w) x 90px (h)<br />Käytä logoa vain, jos olet määrittänyt SSL-suoja uksen.';
$_['help_colour']					 = '6 merkki HTML väri koodi';
$_['help_currency']					 = 'Käytetään tapahtuma hauissa';

// Error
$_['error_permission']				 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua PayPal Express Checkout!';
$_['error_username']				 = 'API-käyttäjä nimi vaaditaan!';
$_['error_password']				 = 'API sala sana tarvitaan!';
$_['error_signature']				 = 'API allekirjoitus tarvitaan!';
$_['error_sandbox_username']	 	 = 'API Sandbox käyttäjä nimi tarvitaan!';
$_['error_sandbox_password']		 = 'API Sandbox sala sana vaaditaan!';
$_['error_sandbox_signature']		 = 'API Sandbox allekirjoitus vaaditaan!';
$_['error_api']						 = 'PayPal valtuutus virhe';
$_['error_api_sandbox']				 = 'PayPal Sandbox lupa virhe';
$_['error_consent']				 	 = 'Jotta voisit käyttää pika-asennusta, sinun on sallittava PayPalin käyttää';
