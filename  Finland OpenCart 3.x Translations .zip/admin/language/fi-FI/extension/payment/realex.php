<?php
// Heading
$_['heading_title']					 = 'Realex uudelleenohjaus';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']					 = 'Onnistui: olet muokannut realex-tili tietoja!';
$_['text_edit']                      = 'Muokkaa realex-uudelleenohjaus';
$_['text_live']						 = 'Live';
$_['text_demo']						 = 'Demo';
$_['text_card_type']				 = 'Kortin tyyppi';
$_['text_enabled']					 = 'Käytössä';
$_['text_use_default']				 = 'Käytä oletus';
$_['text_merchant_id']				 = 'Kauppias id';
$_['text_subaccount']				 = 'Aliasiakkuus';
$_['text_secret']					 = 'Jaettu salaisuus';
$_['text_card_visa']				 = 'Visa';
$_['text_card_master']				 = 'Mastercard';
$_['text_card_amex']				 = 'American Express';
$_['text_card_switch']				 = 'Switch/Maestro';
$_['text_card_laser']				 = 'Laser';
$_['text_card_diners']				 = 'Diners';
$_['text_capture_ok']				 = 'Capture onnistui';
$_['text_capture_ok_order']			 = 'Capture onnistui, tila uksen tila päivitettiin menestykseen-ratkaistu';
$_['text_rebate_ok']				 = 'Osto hyvitys onnistui';
$_['text_rebate_ok_order']			 = 'Osto hyvitys onnistui, tila uksen tila päivitetty korko hyvityksen';
$_['text_void_ok']					 = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';
$_['text_settle_auto']				 = 'Auto';
$_['text_settle_delayed']			 = 'Viivästynyt';
$_['text_settle_multi']				 = 'Multi';
$_['text_url_message']				 = 'Sinun on annettava kaupan URL-osoite realex Account Manageriin ennen kuin asut';
$_['text_payment_info']				 = 'Maksu tiedot';
$_['text_capture_status']			 = 'Maksu otettu';
$_['text_void_status']				 = 'Maksu mitätöity';
$_['text_rebate_status']			 = 'Maksu kiihtyi';
$_['text_order_ref']				 = 'Tilaa REF';
$_['text_order_total']				 = 'Sallittu kokonaismäärä';
$_['text_total_captured']			 = 'Yhteensä kiinni';
$_['text_transactions']				 = 'Tapahtumat';
$_['text_column_amount']			 = 'Summa';
$_['text_column_type']				 = 'Tyyppi';
$_['text_column_date_added']		 = 'Luotu';
$_['text_confirm_void']				 = 'Haluatko varmasti mitätöidä maksun?';
$_['text_confirm_capture']			 = 'Haluatko varmasti siepata maksun?';
$_['text_confirm_rebate']			 = 'Haluatko varmasti hyvityksen maksusi?';
$_['text_realex']					 = '<a target="_blank" href="http://www.realexpayments.co.uk/partner-refer?id=opencart"><img src="view/image/payment/realex.png" alt="Realex" title="Realex" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant_id']				 = 'Kauppias id';
$_['entry_secret']					 = 'Jaettu salaisuus';
$_['entry_rebate_password']			 = 'Osto hyvityksen sala sana';
$_['entry_total']					 = 'Yhteensä';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_debug']					 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_live_demo']				 = 'Live/Demo';
$_['entry_auto_settle']				 = 'Tilitys tyyppi';
$_['entry_card_select']				 = 'Valitse kortti';
$_['entry_tss_check']				 = 'TSS tarkistaa';
$_['entry_live_url']				 = 'Live-yhteyden URL-osoite';
$_['entry_demo_url']				 = 'Demo yhteyden URL-osoite';
$_['entry_status_success_settled']	 = 'Success-ratkaistu';
$_['entry_status_success_unsettled'] = 'Success-ei ratkaistu';
$_['entry_status_decline']			 = 'Lasku';
$_['entry_status_decline_pending']	 = 'Hylkää-offline-todennus';
$_['entry_status_decline_stolen']	 = 'Hylkää-kadonnut tai varastettu kortti';
$_['entry_status_decline_bank']		 = 'Hylkää-pankki virhe';
$_['entry_status_void']				 = 'Mitätöidä';
$_['entry_status_rebate']			 = 'Korko hyvityksen';
$_['entry_notification_url']		 = 'Ilmoituksen URL-osoite';

// Help
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_card_select']				 = 'Pyydä käyttäjää valitsemaan korttinsa tyyppi, ennen kuin ne ohjataan uudelleen';
$_['help_notification']				 = 'Sinun täytyy toimittaa tämän URL-osoitteen realex saada maksu ilmoitukset';
$_['help_debug']					 = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulee aina poistaa käytöstä, ellei ohjeissa toisin mainita';
$_['help_dcc_settle']				 = 'Jos alitili on käytössä, sinun on käytettävä automaattista asettumistä';

// Tab
$_['tab_api']					     = 'API-tiedot';
$_['tab_account']		     		 = 'Tilit';
$_['tab_order_status']				 = 'Tila uksen tila';
$_['tab_payment']					 = 'Maksu Asetukset';
$_['tab_advanced']					 = 'Kehittynyt';

// Button
$_['button_capture']				 = 'Kaapata';
$_['button_rebate']					 = 'Osto hyvitys/hyvitys';
$_['button_void']					 = 'Mitätön';

// Error
$_['error_merchant_id']				 = 'Merchant ID vaaditaan';
$_['error_secret']					 = 'Jaettu salaisuus on pakollinen';
$_['error_live_url']				 = 'Live URL-osoite on pakollinen';
$_['error_demo_url']				 = 'Demon URL-osoite on pakollinen';
$_['error_data_missing']			 = 'Tiedot puuttuvat';
$_['error_use_select_card']			 = 'Sinulla on oltava "Valitse kortti" käytössä, jos haluat, että alitilin reititys kortti tyypin mukaan toimii';