<?php
// Heading
$_['heading_title']			  = 'Skrill';

// Text
$_['text_extension']		  = 'Tiedostopääte';
$_['text_success']			  = 'Onnistui: olet muokannut Skrill-tietoja.';
$_['text_edit']               = 'Muokkaa Skrillia';
$_['text_skrill']	     	  = '<a href="https://content.skrill.com/en/ecommerce-solutions/opencart/" target="_blank"><img src="view/image/payment/skrill.png" alt="Skrill" title="Skrill" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_email']			  = 'Sähköposti';
$_['entry_secret']		      = 'Salainen';
$_['entry_total']			  = 'Yhteensä';
$_['entry_order_status']	  = 'Tila uksen tila';
$_['entry_pending_status']	  = 'Odottava tila ';
$_['entry_canceled_status']	  = 'Peruutettu-tila';
$_['entry_failed_status']	  = 'Epäonnistunut tila';
$_['entry_chargeback_status'] = 'Takaisinperinnän tila';
$_['entry_geo_zone']		  = 'Geo Zone';
$_['entry_status']			  = 'Tila';
$_['entry_sort_order']		  = 'Lajittelujärjestyksen';

// Help
$_['help_total']			  = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']		  = 'Varoitus: sinulla ei ole oikeutta muokata Skrillia!';
$_['error_email']			  = 'E-Mail tarvitaan!';