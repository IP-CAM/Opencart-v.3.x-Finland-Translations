<?php

// Heading
$_['heading_title'] = 'Power pankki siirto';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muuttanut Power pankki siirto tiedot!';
$_['text_edit']          = 'Muokkaa virta pankki siirtoa';
$_['text_copy']         = 'Kopioi ohje kohteesta';

// Entry
$_['entry_bank']         = 'Ohjeet';
$_['entry_total']        = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';
$_['entry_title']           = 'Otsikko';

// Help
$_['help_total']         = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.'; 

// Error 
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muuttaa maksun Power pankki siirrolla!';
$_['error_bank']         = 'Power pankki siirto ohjeet vaaditaan!';
$_['error_fields']      = 'Ole hyvä, tarkista lomake virheiden varalta!';
$_['error_title'] = 'Extension otsikko vaaditaan!';