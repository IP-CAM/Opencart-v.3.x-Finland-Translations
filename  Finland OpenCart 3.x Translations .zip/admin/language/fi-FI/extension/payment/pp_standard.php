<?php
// Heading
$_['heading_title']					 = 'PayPal maksut Standard';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']					 = 'Menestys: olet muuttanut PayPal-tili tiedot!';
$_['text_edit']                      = 'Muokkaa PayPal maksut Standard';
$_['text_pp_standard']				 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization']			 = 'Lupa';
$_['text_sale']						 = 'Myynti'; 

// Entry
$_['entry_email']					 = 'Sähköposti';
$_['entry_test']					 = 'Eristetty tila';
$_['entry_transaction']				 = 'Tapahtuman menetelmä';
$_['entry_debug']					 = 'Debug mode';
$_['entry_total']					 = 'Yhteensä';
$_['entry_canceled_reversal_status'] = 'Peruutettu peruutuksen tila';
$_['entry_completed_status']		 = 'Valmis tila';
$_['entry_denied_status']			 = 'Evätty tila';
$_['entry_expired_status']			 = 'Vanhentunut tila';
$_['entry_failed_status']			 = 'Epäonnistunut tila';
$_['entry_pending_status']			 = 'Odottava tila';
$_['entry_processed_status']		 = 'Käsitelty tila';
$_['entry_refunded_status']			 = 'Palautettu tila';
$_['entry_reversed_status']			 = 'Palautettu tila';
$_['entry_voided_status']			 = 'Mitätöity tila';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';

// Tab
$_['tab_general']					 = 'Yleiset ehdot';
$_['tab_order_status']       		 = 'Tila uksen tila';

// Help
$_['help_test']						 = 'Käytä Live-tai Testing (Sandbox)-yhdyskäytäväpalvelinta tapahtumien käsittelemiseen?';
$_['help_debug']			    	 = 'Kirjaa lisä tiedot järjestelmä lokiin';
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';

// Error
$_['error_permission']				 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua PayPal!';
$_['error_email']					 = 'E-Mail tarvitaan!';