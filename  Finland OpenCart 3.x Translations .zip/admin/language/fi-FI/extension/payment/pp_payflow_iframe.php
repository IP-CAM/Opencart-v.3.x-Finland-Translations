<?php
// Heading
$_['heading_title']					 = 'PayPal payflow Pro iframe';
$_['heading_refund']				 = 'Palautusta';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']					 = 'Menestys: olet muokannut PayPal payflow Pro iframe tili tiedot!';
$_['text_edit']                      = 'Muokkaa PayPal payflow Pro iframe';
$_['text_pp_payflow_iframe']		 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization']			 = 'Lupa';
$_['text_sale']						 = 'Myynti';
$_['text_authorise']				 = 'Sallia';
$_['text_capture']					 = 'Viivästynyt sieppaus';
$_['text_void']						 = 'Mitätön';
$_['text_payment_info']				 = 'Maksu tiedot';
$_['text_complete']					 = 'Täydellinen';
$_['text_incomplete']				 = 'Epätäydellinen';
$_['text_transaction']				 = 'Tapahtuman';
$_['text_confirm_void']				 = 'Jos olet mitätön et voi kaapata mitään lisä varoja';
$_['text_refund']					 = 'Palautusta';
$_['text_refund_issued']			 = 'Palautus on myönnetty onnistuneesti';
$_['text_redirect']					 = 'Uudelleenohjaus';
$_['text_iframe']					 = 'Iframe';
$_['help_checkout_method']			 = 'Käytä Redirect menetelmä, jos ei ole SSL asennettu tai jos sinulla ei ole maksaa PayPal vaihto ehto pois käytöstä isännöidyn maksun sivulla.';

// Column
$_['column_transaction_id']			 = 'Tapahtuman tunnus';
$_['column_transaction_type']		 = 'Tapahtuman laji';
$_['column_amount']					 = 'Summa';
$_['column_time']					 = 'Aika';
$_['column_actions']				 = 'Toimia';

// Tab
$_['tab_settings']					 = 'Asetukset';
$_['tab_order_status']				 = 'Tila uksen tila';
$_['tab_checkout_customisation']	 = 'Checkout-mukautus';

// Entry
$_['entry_vendor']					 = 'Toimittajan';
$_['entry_user']					 = 'Käyttäjä';
$_['entry_password']				 = 'Salasana';
$_['entry_partner']					 = 'Kumppani';
$_['entry_test']					 = 'Testi tilassa';
$_['entry_transaction']				 = 'Tapahtuman menetelmä';
$_['entry_total']					 = 'Yhteensä';
$_['entry_order_status']			 = 'Tila uksen tila';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';
$_['entry_transaction_id']			 = 'Tapahtuman tunnus';
$_['entry_full_refund']				 = 'Täysi hyvitys';
$_['entry_amount']					 = 'Summa';
$_['entry_message']					 = 'Viesti';
$_['entry_ipn_url']					 = 'IPN URL';
$_['entry_checkout_method']			 = 'Checkout-menetelmä';
$_['entry_debug']					 = 'Debug mode';
$_['entry_transaction_reference']	 = 'Tapahtuman viite';
$_['entry_transaction_amount']		 = 'Tapahtuman summa';
$_['entry_refund_amount']			 = 'Hyvityksen määrä';
$_['entry_capture_status']			 = 'Sieppauksen tila';
$_['entry_void']					 = 'Mitätön';
$_['entry_capture']					 = 'Kaapata';
$_['entry_transactions']			 = 'Tapahtumat';
$_['entry_complete_capture']		 = 'Täydellinen sieppaus';
$_['entry_canceled_reversal_status'] = 'Peruutettu peruutuksen tila:';
$_['entry_completed_status']		 = 'Valmis tila:';
$_['entry_denied_status']			 = 'Evätty tila:';
$_['entry_expired_status']			 = 'Vanhentunut tila:';
$_['entry_failed_status']			 = 'Epäonnistunut tila:';
$_['entry_pending_status']			 = 'Odottava tila:';
$_['entry_processed_status']		 = 'Käsitelty tila:';
$_['entry_refunded_status']			 = 'Palautettu tila:';
$_['entry_reversed_status']			 = 'Palautettu tila:';
$_['entry_voided_status']			 = 'Mitätöity tila:';
$_['entry_cancel_url']				 = 'Peruuta URL-osoite:';
$_['entry_error_url']				 = 'Virhe URL:';
$_['entry_return_url']				 = 'Palautuksen URL-osoite:';
$_['entry_post_url']				 = 'Silent post URL:';

// Help
$_['help_vendor']					 = 'Sinun kauppias kirjautumistunnuksesi että loit, kun olet rekisteröitynyt Website Payments Pro tili';
$_['help_user']						 = 'Jos määrität tilille yhden tai useampia lisä käyttäjiä, tämä arvo on tapahtumien käsittelemiseen valtuutetun käyttäjän tunnus. Jos et kuitenkaan ole määrittänyt tilille muita käyttäjiä, käyttäjällä on sama arvo kuin toimittajalla';
$_['help_password']					 = '6-32 merkin sala sana, jonka olet määrittänyt rekisteröityessäsi tiliin';
$_['help_partner']					 = 'Tunnus, jonka sinulle on antanut valtuutettu PayPal-jälleenmyyjä, joka on rekisteröinyt sinut payflow SDK:ta varten. Jos ostit tilisi suoraan PayPalista, käytä sen sijaan PayPal Prota';
$_['help_test']						 = 'Käytä Live-tai Testing (Sandbox)-yhdyskäytäväpalvelinta tapahtumien käsittelemiseen?';
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_debug']					 = 'Lokit lisä tietoja';

// Button
$_['button_refund']					 = 'Palautusta';
$_['button_void']					 = 'Mitätön';
$_['button_capture']				 = 'Kaapata';

// Error
$_['error_permission']				 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua PayPal Website maksu Pro iframe (UK)!';
$_['error_vendor']					 = 'Myyjä tarvitaan!';
$_['error_user']					 = 'Käyttäjä pakollinen!';
$_['error_password']				 = 'Sala sana vaaditaan!';
$_['error_partner']					 = 'Partner tarvitaan!';
$_['error_missing_data']			 = 'Puuttuvat tiedot';
$_['error_missing_order']			 = 'Tilausta ei löytynyt';
$_['error_general']					 = 'Virhe';
$_['error_capture']				     = 'Anna määrä kaapata';