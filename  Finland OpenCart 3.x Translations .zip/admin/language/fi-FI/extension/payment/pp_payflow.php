<?php
// Heading
$_['heading_title']		 = 'PayPal payflow Pro';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muokannut PayPal Direct (UK) tili tiedot!';
$_['text_edit']          = 'Muokkaa PayPal payflow Pro';
$_['text_pp_payflow']	 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'Lupa';
$_['text_sale']			 = 'Myynti';

// Entry
$_['entry_vendor']		 = 'Toimittajan';
$_['entry_user']		 = 'Käyttäjä';
$_['entry_password']	 = 'Salasana';
$_['entry_partner']		 = 'Kumppani';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_transaction']	 = 'Tapahtuman menetelmä';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_vendor']		 = 'Sinun kauppias kirjautumistunnuksesi että loit, kun olet rekisteröitynyt Website Payments Pro tili';
$_['help_user']			 = 'Jos määrität tilille yhden tai useampia lisä käyttäjiä, tämä arvo on tapahtumien käsittelemiseen valtuutetun käyttäjän tunnus. Jos et kuitenkaan ole määrittänyt tilille muita käyttäjiä, käyttäjällä on sama arvo kuin toimittajalla';
$_['help_password']		 = '6-32 merkin sala sana, jonka olet määrittänyt rekisteröityessäsi tiliin';
$_['help_partner']		 = 'Tunnus, jonka sinulle on antanut valtuutettu PayPal-jälleenmyyjä, joka on rekisteröinyt sinut payflow SDK:ta varten. Jos ostit tilisi suoraan PayPalista, käytä sen sijaan PayPal Prota';
$_['help_test']			 = 'Käytä Live-tai Testing (Sandbox)-yhdyskäytäväpalvelinta tapahtumien käsittelemiseen?';
$_['help_total']		 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua PayPal Website maksu Pro (UK)!';
$_['error_vendor']		 = 'Myyjä tarvitaan!';
$_['error_user']		 = 'Käyttäjä pakollinen!';
$_['error_password']	 = 'Sala sana vaaditaan!';
$_['error_partner']		 = 'Partner tarvitaan!';