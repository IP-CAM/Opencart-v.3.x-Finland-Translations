<?php
// Text
$_['text_extension']		 = 'Maksu tiedot';
$_['text_capture_status']	 = 'Sieppauksen tila';
$_['text_amount_authorised'] = 'Sallittu määrä';
$_['text_amount_captured']	 = 'Määrä kiinni';
$_['text_amount_refunded']	 = 'Hyvitetty summa';
$_['text_transaction']		 = 'Tapahtumat';
$_['text_complete']			 = 'Täydellinen';
$_['text_confirm_void']		 = 'Jos olet mitätön et voi kaapata mitään lisä varoja';
$_['text_view']				 = 'Katso';
$_['text_refund']			 = 'Palautusta';
$_['text_resend']			 = 'Lähettää';
$_['text_success']           = 'Tapahtuman lähetys onnistui';
$_['text_full_refund']		 = 'Täysi hyvitys';
$_['text_partial_refund']	 = 'Osittainen hyvitys';
$_['text_payment']		 	 = 'Maksu';
$_['text_current_refunds']   = 'Tälle tapahtumalle on jo tehty hyvityksiä. Maksimi tuki on';

// Column
$_['column_transaction']	 = 'Tapahtuman tunnus';
$_['column_amount']			 = 'Summa';
$_['column_type']			 = 'Maksu tyyppi';
$_['column_status']			 = 'Tila';
$_['column_pending_reason']	 = 'Odottava syy';
$_['column_date_added']		 = 'Päivä määrä lisätty';
$_['column_action']			 = 'Toiminta';

// Entry
$_['entry_capture_amount']	 = 'Sieppauksen summa';
$_['entry_capture_complete'] = 'Täydellinen sieppaus';
$_['entry_full_refund']		 = 'Täysi hyvitys';
$_['entry_amount']			 = 'Summa';
$_['entry_note']             = 'Huomautus';

// Help
$_['help_capture_complete']  = 'Jos tämä on viimeinen kaapata.';

// Tab
$_['tab_capture']		     = 'Kaapata';
$_['tab_refund']             = 'Palautusta';

// Button
$_['button_void']			 = 'Mitätön';
$_['button_capture']		 = 'Kaapata';
$_['button_refund']		     = 'Issue hyvitys';

// Error
$_['error_capture']		     = 'Anna määrä kaapata';
$_['error_transaction']	     = 'Tapahtumaa ei voitu suorittaa!';
$_['error_not_found']	     = 'Tapahtumaa ei löytynyt!';
$_['error_partial_amt']		 = 'Sinun täytyy syöttää osittainen palautus summa';