<?php
// Heading
$_['heading_title']			 = 'Bluepay uudelleenohjaus (vaatii SSL)';

// Text
$_['text_extension']		 = 'Tiedostopääte';
$_['text_success']			 = 'Onnistui: olet muokannut bluepay Redirect-tili tietoja!';
$_['text_edit']              = 'Muokkaa bluepay uudelleenohjaus (vaatii SSL)';
$_['text_bluepay_redirect']	 = '<a href="http://www.bluepay.com/preferred-partner/opencart" target="_blank"><img src="view/image/payment/bluepay.jpg" alt="BluePay Redirect" title="BluePay Redirect" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_sim']				 = 'Simulator';
$_['text_test']				 = 'Testi';
$_['text_live']				 = 'Live';
$_['text_sale']				 = 'Myynti';
$_['text_authenticate']		 = 'Valtuuttaa';
$_['text_release_ok']		 = 'Julkaisu onnistui';
$_['text_release_ok_order']	 = 'Julkaisu onnistui';
$_['text_rebate_ok']		 = 'Osto hyvitys onnistui';
$_['text_rebate_ok_order']	 = 'Osto hyvitys onnistui, tila uksen tila päivitetty korko hyvityksen';
$_['text_void_ok']			 = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';
$_['text_payment_info']		 = 'Maksu tiedot';
$_['text_release_status']	 = 'Maksu julkaistu';
$_['text_void_status']		 = 'Maksu mitätöity';
$_['text_rebate_status']	 = 'Maksu kiihtyi';
$_['text_order_ref']		 = 'Tilaa REF';
$_['text_order_total']		 = 'Sallittu kokonaismäärä';
$_['text_total_released']	 = 'Yhteensä julkaistu';
$_['text_transactions']		 = 'Tapahtumat';
$_['text_column_amount']	 = 'Summa';
$_['text_column_type']		 = 'Tyyppi';
$_['text_column_date_added'] = 'Luotu';
$_['text_confirm_void']		 = 'Haluatko varmasti mitätöidä maksun?';
$_['text_confirm_release']	 = 'Haluatko varmasti vapauttaa maksun?';
$_['text_confirm_rebate']	 = 'Haluatko varmasti hyvityksen maksusi?';

// Entry
$_['entry_vendor']			 = 'Tilin tunnus';
$_['entry_secret_key']		 = 'Salainen avain';
$_['entry_test']			 = 'Tapahtuma tila';
$_['entry_transaction']		 = 'Tapahtuman menetelmä';
$_['entry_total']			 = 'Yhteensä';
$_['entry_order_status']	 = 'Tila uksen tila';
$_['entry_geo_zone']		 = 'Geo Zone';
$_['entry_status']			 = 'Tila';
$_['entry_sort_order']		 = 'Lajittelujärjestyksen';
$_['entry_debug']			 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_card']			 = 'Säilytä kortit';

// Help
$_['help_total']			 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';
$_['help_debug']			 = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulee aina poistaa käytöstä, ellei ohjeissa toisin mainita';
$_['help_transaction']		 = 'Myynti veloittaa asiakkaalta välittömästi. Valtuutus asettaa varoja pitoon tulevaa sieppausta varten.';
$_['help_cron_job_token']	 = 'Tee tämä pitkä ja vaikea arvata';
$_['help_cron_job_url']		 = 'Aseta ajastettu tehtävä kutsua tätä URL';

// Button
$_['button_release']		 = 'Vapauttaa';
$_['button_rebate']			 = 'Osto hyvitys/hyvitys';
$_['button_void']			 = 'Mitätön';

// Error
$_['error_permission']		 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua bluepay!';
$_['error_account_id']		 = 'Tili tunnus vaaditaan!';
$_['error_secret_key']		 = 'Salainen avain vaaditaan!';