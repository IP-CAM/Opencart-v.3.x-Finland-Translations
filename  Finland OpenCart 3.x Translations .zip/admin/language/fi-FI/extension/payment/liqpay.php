<?php
// Heading
$_['heading_title']		 = 'LIQPAY';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muokannut Liqpay tili tiedot!';
$_['text_edit']          = 'Muokkaa Liqpay';
$_['text_pay']			 = 'LIQPAY';
$_['text_card']			 = 'Luottokortti';
$_['text_liqpay']		 = '<img src="view/image/payment/liqpay.png" alt="LIQPAY" title="LIQPAY" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_merchant']	 = 'Kauppias id';
$_['entry_signature']	 = 'Allekirjoitus';
$_['entry_type']		 = 'Tyyppi';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole oikeutta muuttaa maksu Liqpay!';
$_['error_merchant']	 = 'Kauppias id tarvitaan!';
$_['error_signature']	 = 'Allekirjoitus vaaditaan!';