<?php
// Heading
$_['heading_title']                  = 'Alipay rajat ylittävä';

// Text
$_['text_extension']                 = 'Tiedostopääte';
$_['text_success']                   = 'Menestys: olet muokannut Alipay tili tiedot!';
$_['text_edit']                      = 'Muokkaa Alipay-maksu';
$_['text_alipay_cross']              = '<a target="_BLANK" href="https://global.alipay.com"><img src="view/image/payment/alipay-cross-border.png" alt="Alipay Pay Website" title="Alipay Pay Website" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_live']                      = 'Live';
$_['text_sandbox']                   = 'Hiekkalaatikko';

// Entry
$_['entry_app_id']                   = 'Kumppanin tunnus';
$_['entry_merchant_private_key']     = 'Avain';
$_['entry_test']                     = 'Testi tilassa';
$_['entry_total']                    = 'Yhteensä';
$_['entry_currency']                 = 'Valuutan koodi';
$_['entry_order_status']             = 'Valmis tila';
$_['entry_geo_zone']                 = 'Geo Zone';
$_['entry_status']                   = 'Tila';
$_['entry_sort_order']               = 'Lajittelujärjestyksen';

// Help
$_['help_total']                     = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_currency']                  = 'Tilitys valuutan koodi, jonka kauppias määrittää sopimuksessa. Voit lisätä uuden valuutan järjestelmän&gt;Lokalisointi&gt;Valuutta, jos tilitys valuuttaa ei ole luettelossa';
$_['help_alipay_setup']              = '<a target="_blank" href="http://www.opencart.cn/docs/alipay">Klikkaa tästä</a> lisä tietoja Alipay-tilin määrittämisestä.';

// Error
$_['error_permission']               = 'Varoitus: sinulla ei ole oikeuksia muokata maksu Alipay!';
$_['error_app_id']                   = 'Partner ID vaaditaan!';
$_['error_merchant_private_key']     = 'Avain tarvitaan!';
