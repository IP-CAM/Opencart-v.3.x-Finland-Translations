<?php
// Heading
$_['heading_title']						 = 'Klarna kassalle';

// Text
$_['text_extension']					 = 'Tiedostopääte';
$_['text_success']						 = 'Onnistui: olet muokannut Klarna Checkout-tili tietojasi!';
$_['text_edit']							 = 'Muokkaa Klarna kassalle';
$_['text_live']							 = 'Live';
$_['text_test']							 = 'Testi';
$_['text_payment_info']					 = 'Maksu tiedot';
$_['text_na']							 = 'N/a';
$_['text_confirm_cancel']				 = 'Haluatko varmasti peruuttaa tämän tapahtuman?';
$_['text_confirm_capture']				 = 'Haluatko varmasti tallentaa';
$_['text_confirm_refund']				 = 'Haluatko varmasti palauttaa';
$_['text_confirm_extend_authorization']	 = 'Haluatko varmasti laajentaa valtuutuksen?';
$_['text_confirm_release_authorization'] = 'Haluatko varmasti vapauttaa jäljellä olevan valtuutuksen?';
$_['text_confirm_merchant_reference']	 = 'Haluatko varmasti päivittää Merchant viite 1-päivityksen?';
$_['text_confirm_shipping_info']		 = 'Haluatko varmasti tallentaa lähetys tiedot?';
$_['text_confirm_billing_address']		 = 'Haluatko varmasti päivittää laskutus osoitteen?';
$_['text_confirm_shipping_address']		 = 'Haluatko varmasti laajentaa toimitus osoitteen?';
$_['text_confirm_trigger_send_out']		 = 'Haluatko varmasti käynnistää uuden lähetyksen?';
$_['text_confirm_settlement']			 = 'Haluatko varmasti käsitellä tilitys tiedostot?';
$_['text_no_capture']					 = 'Ei kaappaa';
$_['text_no_refund']					 = 'Ei hyvityksiä';
$_['text_success_action']				 = 'Menestys';
$_['text_error_generic']				 = 'Virhe: pyynnössä tapahtui virhe.';
$_['text_capture_shipping_info_title']	 = 'Kaapata %d -Toimitus info';
$_['text_capture_billing_address_title'] = 'Kaapata %d -Laskutus osoite';
$_['text_new_capture_title']			 = 'Uusi Capture';
$_['text_new_refund_title']				 = 'Uusi hyvitys';
$_['text_downloading_settlement']		 = 'Ladataan tilitys tiedostoja...';
$_['text_processing_orders']			 = 'Käsitellään tila uksia...';
$_['text_processing_order']				 = 'Käsittely järjestys';
$_['text_no_files']						 = 'Ei tiedostoja ladattavaksi.';
$_['text_version']						 = '1,2';

// Column
$_['column_order_id']					 = 'Tilauksen tunnus';
$_['column_capture_id']					 = 'Sieppaus tunnus';
$_['column_reference']					 = 'Klarna-viite';
$_['column_status']						 = 'Tila';
$_['column_merchant_reference_1']		 = 'Kauppias Reference 1';
$_['column_customer_details']			 = 'Asiakkaan tiedot';
$_['column_billing_address']			 = 'Laskutus tiedot';
$_['column_shipping_address']			 = 'Toimitus tiedot';
$_['column_order_lines']				 = 'Kohteen tiedot';
$_['column_amount']						 = 'Summa';
$_['column_authorization_remaining']	 = 'Valtuutus jäljellä';
$_['column_authorization_expiry']		 = 'Luvan päättymis päivä';
$_['column_item_reference']				 = 'Viite';
$_['column_type']						 = 'Tyyppi';
$_['column_quantity']					 = 'Määrä';
$_['column_quantity_unit']				 = 'Määrä yksikkö';
$_['column_name']						 = 'Nimi';
$_['column_total_amount']				 = 'Kokonaissumma';
$_['column_unit_price']					 = 'Yksikkö hinta';
$_['column_total_discount_amount']		 = 'Alennuksen kokonaissumma';
$_['column_tax_rate']					 = 'Vero prosentti';
$_['column_total_tax_amount']			 = 'Vero summa yhteensä';
$_['column_action']						 = 'Toiminta';
$_['column_cancel']						 = 'Peruuta';
$_['column_capture']					 = 'Kaappaa';
$_['column_refund']						 = 'Hyvitykset';
$_['column_date']						 = 'Päivämäärä';
$_['column_title']						 = 'Otsikko';
$_['column_given_name']					 = 'Etunimi';
$_['column_family_name']				 = 'Suku nimi';
$_['column_street_address']				 = 'Katu osoite';
$_['column_street_address2']			 = 'Katu osoite 2';
$_['column_city']						 = 'City';
$_['column_postal_code']				 = 'Postinumero';
$_['column_region']						 = 'Alue';
$_['column_country']					 = 'Maa';
$_['column_email']						 = 'Sähköposti';
$_['column_phone']						 = 'Puhelin';
$_['column_action']						 = 'Toiminta';
$_['column_shipping_info']				 = 'Toimitus info';
$_['column_shipping_company']			 = 'Varustamo';
$_['column_shipping_method']			 = 'Toimitus tapa';
$_['column_tracking_number']			 = 'Seuranta numero';
$_['column_tracking_uri']				 = 'Seurannan URI';
$_['column_return_shipping_company']	 = 'Paluu varustamo';
$_['column_return_tracking_number']		 = 'Palautuksen seuranta numero';
$_['column_return_tracking_uri']		 = 'Palautuksen seurannan URI';

// Entry
$_['entry_debug']						 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_colour_button']				 = 'Painikkeen tausta väri';
$_['entry_colour_button_text']			 = 'Painikkeen tekstin väri';
$_['entry_colour_checkbox']				 = 'Valinta ruutu taustan väri';
$_['entry_colour_checkbox_checkmark']	 = 'Checkbox rasti väri';
$_['entry_colour_header']				 = 'Otsikko tekstin väri';
$_['entry_colour_link']					 = 'Linkin tekstin väri';
$_['entry_separate_shipping_address']	 = 'Salli erillinen toimitus osoite';
$_['entry_dob_mandatory']				 = 'Syntymä aika pakollinen (vain UK Stores)';
$_['entry_title_mandatory']				 = 'Osasto pakollinen (vain UK Stores)';
$_['entry_additional_text_box']			 = 'Salli uutis kirjeen tilaaminen';

$_['entry_total']						 = 'Yhteensä';
$_['entry_order_status']				 = 'Tila uksen tila';
$_['entry_order_status_authorised']		 = 'Valtuutettu';
$_['entry_order_status_part_captured']	 = 'Osa valtasi';
$_['entry_order_status_captured']		 = 'Kiinni';
$_['entry_order_status_cancelled']		 = 'Peruutettu';
$_['entry_order_status_refund']			 = 'Täysi hyvitys';
$_['entry_order_status_fraud_rejected']	 = 'Petos-hylätty';
$_['entry_order_status_fraud_pending']	 = 'Petos-vireillä oleva päätös';
$_['entry_order_status_fraud_accepted']	 = 'Petos-hyväksytty';
$_['entry_status']						 = 'Tila';
$_['entry_terms']						 = 'Ehdot & ehdot';
$_['entry_locale']						 = 'Locale';
$_['entry_currency']					 = 'Valuutta';
$_['entry_merchant_id']					 = 'Kauppias id (Mid)';
$_['entry_secret']						 = 'Jaettu salaisuus';
$_['entry_environment']					 = 'Ympäristö (Live/Test)';
$_['entry_country']						 = 'Maa';
$_['entry_shipping']					 = 'Shipping maat';
$_['entry_api']							 = 'API-sijainti';
$_['entry_shipping_company']			 = 'Varustamo';
$_['entry_shipping_method']				 = 'Toimitus tapa';
$_['entry_tracking_number']				 = 'Seuranta numero';
$_['entry_tracking_uri']				 = 'Seurannan URI';
$_['entry_return_shipping_company']		 = 'Paluu varustamo';
$_['entry_return_tracking_number']		 = 'Palautuksen seuranta numero';
$_['entry_return_tracking_uri']			 = 'Palautuksen seurannan URI';
$_['entry_sftp_username']				 = 'SFTP käyttäjä tunnus';
$_['entry_sftp_password']				 = 'SFTP sala sana';
$_['entry_process_settlement']			 = 'Käsittele tilitys tiedostot';
$_['entry_settlement_order_status']		 = 'Tila uksen tila';
$_['entry_version']						 = 'Laajennuksen versio';

// Help
$_['help_debug']						 = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_separate_shipping_address']	 = 'Jos kyllä, kuluttaja voi syöttää eri laskutus-ja toimitus osoitteita.';
$_['help_dob_mandatory']				 = 'Jos kyllä, kuluttaja ei voi ohittaa syntymä aika.';
$_['help_title_mandatory']				 = 'Jos arvoksi on määritetty ei, otsikko muuttuu valinnaiseksi maissa, jotka Oletus arvon mukaan edellyttävät otsikkoa.';
$_['help_additional_text_box']			 = 'Sallii uutis kirjeen kirjautumisen Iframe-iFrameissa kirjautuneet käyttäjät.';
$_['help_total']						 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';
$_['help_locale']						 = 'Kunkin tilin kieli koodi. Kaksikirjaiminen kieli koodi yhdistettynä kaksikirjaimista maakoodiin RFC 1766-standardin mukaisesti. (esim. en-GB British Englanti tai SV-se ruotsiksi)';
$_['help_api']							 = 'Klarna Checkout ei tarjoa eurooppalaisille käyttäjille asiakas aluetta. Tämä tarkoittaa, että alue erityisiä meren kulun vaihto ehtoja ei toimi (maakohtaiset meren kulku on hieno)';
$_['help_sftp_username']				 = 'Account Managerin antamat SFTP-käyttäjä tunnukset';
$_['help_sftp_password']				 = 'SFTP sala sana, jonka Account Manager';
$_['help_settlement_order_status']		 = 'Tila uksen tila, johon käsitellyt tilitys tilaukset muuttuvat.';
$_['help_shipping']						 = 'Kaikki maat tämän Geo Zone on käytettävissä valita Klarna iframe.';

// Button
$_['button_account_remove']				 = 'Poista tili';
$_['button_account_add']				 = 'Lisää tili';
$_['button_capture']					 = 'Kaapata';
$_['button_refund']						 = 'Palautusta';
$_['button_extend_authorization']		 = 'Laajentaa';
$_['button_release_authorization']		 = 'Vapauttaa';
$_['button_update']						 = 'Päivitys';
$_['button_add_shipping_info']			 = 'Lisää lähetys tiedot';
$_['button_trigger_send_out']			 = 'Käynnistä uusi lähetys';
$_['button_edit_shipping_info']			 = 'Muokkaa lähetys tietoja';
$_['button_edit_billing_address']		 = 'Muokkaa laskutus osoitetta';
$_['button_new_capture']				 = 'Uusi Capture';
$_['button_new_refund']					 = 'Uusi hyvitys';
$_['button_process_settlement']			 = 'Käsittele tilitys tiedostot';

// Error
$_['error_warning']						 = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_php_version']					 = 'Vähimmäis-käännös-lta PHP 5.4.0 on tarvittaessa!';
$_['error_ssl']							 = 'Sinun on otettava käyttöön "Käytä SSL" kaupan asetukset ja on SSL-sertifikaatti on asennettu!';
$_['error_account_minimum']				 = 'Lisää vähintään yksi tili.';
$_['error_locale']						 = 'Anna kelvollinen kieli.';
$_['error_account_currency']			 = 'Tili luettelo sisältää vähintään yhden kahdentuneita valuuttoja.';
$_['error_merchant_id']					 = 'Kauppias id tarvitaan!';
$_['error_secret']						 = 'Jaettu salaisuus vaaditaan!';
$_['error_tax_warning']					 = 'Varoitus: Jotkin tuotteet käyttävät maksu osoitteen perustuvaa vero luokkaa. Klarna Checkout ei toimi, kun jokin näistä sijoitetaan koriin.';

// Tab
$_['tab_setting']						 = 'Asetukset';
$_['tab_order_status']					 = 'Tila uksen tilat';
$_['tab_account']						 = 'Tilit';
$_['tab_settlement']					 = 'Ratkaisun';