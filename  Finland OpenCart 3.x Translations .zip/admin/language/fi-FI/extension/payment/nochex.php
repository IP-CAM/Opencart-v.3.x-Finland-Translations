<?php
// Heading
$_['heading_title']		 = 'Nochex';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muuttanut nochex tili tiedot!';
$_['text_edit']          = 'Muokkaa nochexiä';
$_['text_nochex']		 = '<a href="https://secure.nochex.com/apply/merchant_info.aspx?partner_id=172198798" target="_blank"><img src="view/image/payment/nochex.png" alt="NOCHEX" title="NOCHEX" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_seller']		 = 'Myyjä/henkilökohtainen tili';
$_['text_merchant']		 = 'Kauppias tili';

// Entry
$_['entry_email']		 = 'Sähköposti';
$_['entry_account']		 = 'Tilin tyyppi';
$_['entry_merchant']	 = 'Kauppias id';
$_['entry_template']	 = 'Siirrä malli';
$_['entry_test']		 = 'Testi';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']	     = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Help
$_['help_total']	     = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole lupaa muuttaa maksua nochex!';
$_['error_email']	     = 'E-Mail tarvitaan!';
$_['error_merchant']     = 'Kauppias id tarvitaan!';