<?php
// Heading
$_['heading_title']		 = 'Pysyvät maksut';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Onnistui: olet muokannut pysyvien maksujen tili tietoja!';
$_['text_edit']          = 'Muokkaa jatkuvia maksuja';

// Entry
$_['entry_auth_id']		 = 'Valtuutus tieto tunnus';
$_['entry_auth_pass']	 = 'Valtuutus salasana';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_test']			 = 'Käytä tätä moduulia testissä (Kyllä) tai tuotanto tilassa (ei)?';
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole oikeutta muuttaa maksua pysyviä maksuja!';
$_['error_auth_id']		 = 'Valtuutus tunnus vaaditaan!';
$_['error_auth_pass']	 = 'Valtuutus salasana vaaditaan!';