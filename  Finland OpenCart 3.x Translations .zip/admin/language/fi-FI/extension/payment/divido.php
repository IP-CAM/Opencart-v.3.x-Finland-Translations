<?php
// Heading
$_['heading_title']                    = 'Divido';

// Text
$_['text_divido']                      = '<a href="http://divido.com" target="_blank"><img src="view/image/payment/divido.png"></a>';
$_['text_edit']                        = 'Muokkaa divido';
$_['text_extension']                   = 'Tiedostopääte';
$_['text_order_info']                  = 'Tietoja divido';
$_['text_success']                     = 'Onnistui: olet muokannut divido-moduulia';
$_['text_proposal_id']                 = 'Ehdotuksen tunnus';
$_['text_application_id']              = 'Sovelluksen tunnus';
$_['text_deposit_amount']              = 'Talletus summa';

// Entry
$_['entry_order_status']               = 'Tila uksen tila, kun se on hyväksytty';
$_['entry_sort_order']                 = 'Lajittelujärjestyksen';
$_['entry_status']                     = 'Tila';
$_['entry_api_key']                    = 'API-avain';
$_['entry_title']                      = 'Otsikko';
$_['entry_productselection']           = 'Tuotteen valinta';
$_['entry_planselection']              = 'Näytä oletus suunnitelma';
$_['entry_planlist']                   = 'Suunnitelmat';
$_['entry_plans_options_all']          = 'Näytä kaikki suunnitelmat';
$_['entry_plans_options_selected']     = 'Oletus suunnitelmien valitseminen';
$_['entry_products_options_all']       = 'Kaikki tuotteet';
$_['entry_products_options_selected']  = 'Vain valitut tuotteet';
$_['entry_products_options_threshold'] = 'Kaikki tuotteet yli määritellyn hinnan';
$_['entry_price_threshold']            = 'Tuotteen hinta kynnys';
$_['entry_cart_threshold']             = 'Ostos korin kokonaiskynnys';
$_['entry_threshold_list']             = 'Suunnitelman kynnys arvot';
$_['entry_category']                   = 'Luokat';

// Help
$_['help_api_key']                     = 'Avain, joka tunnistaa sinut divido (saatu divido)';
$_['help_status']                      = 'Maksu tavan tila';
$_['help_order_status']                = 'Tilan tila, kun lainanantaja on hyväksynyt';
$_['help_title']                       = 'Maksu tavan nimi, näkyy kassalla';
$_['help_planselection']               = 'Valitse, Haluatko valita suunnitelmat manuaalisesti vai näytetäänkö oletus joukko';
$_['help_productselection']            = 'Valitse mitä tuotteita on saatavilla Finance';
$_['help_category']                    = 'Rajoita rahoituksen käytettävissä olevia luokkia';
$_['help_cart_threshold']              = 'Kova alaraja on cart määrä divido on saatavilla';