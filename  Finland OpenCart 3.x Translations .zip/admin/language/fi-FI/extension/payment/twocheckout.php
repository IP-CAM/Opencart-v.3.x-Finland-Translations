<?php
// Heading
$_['heading_title']		 = '2checkout';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muuttanut 2checkout-tilin tiedot!';
$_['text_edit']          = 'Muokkaa 2checkout';
$_['text_twocheckout']	 = '<a href="https://www.2checkout.com/2co/affiliate?affiliate=1596408" target="_blank"><img src="view/image/payment/2checkout.png" alt="2Checkout" title="2Checkout" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_account']		 = '2checkout-tilin tunnus';
$_['entry_secret']		 = 'Salainen sana';
$_['entry_display']		 = 'Suora Checkout';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_secret']		 = 'Salainen sana vahvistaa tapahtumien kanssa (on sama kuin määritelty kauppias tilin asetukset sivulla).';
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole oikeutta muokata maksu 2checkout!';
$_['error_account']		 = 'Tilinro Tarvitaan!';
$_['error_secret']		 = 'Salainen sana vaaditaan!';