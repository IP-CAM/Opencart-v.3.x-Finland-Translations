<?php
// Heading
$_['heading_title']		 = 'Payza';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muokannut payza tili tiedot!';
$_['text_edit']          = 'Muokkaa payza';

// Entry
$_['entry_merchant']	 = 'Kauppias id';
$_['entry_security']	 = 'Suoja koodi';
$_['entry_callback']	 = 'Ilmoituksen URL-osoite';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_callback']		 = 'Tämä on asetettava payza ohjaus paneelissa. Te jälki säädös kin kaivata jotta ruudullinen "IPN arvostus" jotta mahdollistaa.';
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole oikeutta muokata maksu payza!';
$_['error_merchant']	 = 'Kauppias id tarvitaan!';
$_['error_security']	 = 'Suoja koodi tarvitaan!';