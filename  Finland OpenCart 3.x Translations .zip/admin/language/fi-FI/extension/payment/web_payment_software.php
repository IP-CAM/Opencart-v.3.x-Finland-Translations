<?php
// Heading
$_['heading_title']				= 'Web-maksu-ohjelmisto';

// Text
$_['text_extension']			= 'Tiedostopääte';
$_['text_success']				= 'Menestys: olet muokannut Web Payment Software tili tiedot!';
$_['text_edit']                 = 'Edit aweb maksu-ohjelmisto';
$_['text_web_payment_software']	= '<a href="http://www.web-payment-software.com/" target="_blank"><img src="view/image/payment/wps-logo.jpg" alt="Web Payment Software" title="Web Payment Software" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_test']					= 'Testi';
$_['text_live']					= 'Live';
$_['text_authorization']		= 'Lupa';
$_['text_capture']				= 'Kaapata';

// Entry
$_['entry_login']				= 'Kauppias id';
$_['entry_key']					= 'Kauppias avain';
$_['entry_mode']				= 'Tapahtuma tila';
$_['entry_method']				= 'Tapahtuman menetelmä';
$_['entry_total']				= 'Yhteensä';
$_['entry_order_status']		= 'Tila uksen tila';
$_['entry_geo_zone']			= 'Geo Zone';
$_['entry_status']				= 'Tila';
$_['entry_sort_order']			= 'Lajittelujärjestyksen';

// Help
$_['help_total']				= 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']			= 'Varoitus: sinulla ei ole oikeutta muokata maksua Web maksu Software!';
$_['error_login']				= 'Kirjautuminen ID vaaditaan!';
$_['error_key']					= 'Tapahtuma avain vaaditaan!';