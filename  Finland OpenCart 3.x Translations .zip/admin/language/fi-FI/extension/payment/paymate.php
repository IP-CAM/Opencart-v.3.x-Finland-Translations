<?php
// Heading
$_['heading_title']		 = 'Paymate';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muokannut Paymate tili tiedot!';
$_['text_edit']          = 'Muokkaa Paymate';
$_['text_paymate']		 = '<img src="view/image/payment/paymate.png" alt="Paymate" title="Paymate" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_username']	 = 'Paymate käyttäjä tunnus';
$_['entry_password']	 = 'Salasana';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_password']		 = 'Just käyttää joitakin satunnaisia sala sana. Tämän avulla varmistetaan, että maksu tietoja ei häiritä sen jälkeen, kun ne on lähetetty maksuyhdyskäytävään.';
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua Paymate!';
$_['error_username']	 = 'Paymate käyttäjä tunnus tarvitaan!';
$_['error_password']	 = 'Sala sana vaaditaan!';