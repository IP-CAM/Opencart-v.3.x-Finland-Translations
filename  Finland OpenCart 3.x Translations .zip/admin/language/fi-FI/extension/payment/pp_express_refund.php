<?php
// Heading
$_['heading_title']		   = 'Hyvitys tapahtuman';

// Text
$_['text_pp_express']	   = 'PayPal Express Checkout';
$_['text_current_refunds'] = 'Tälle tapahtumalle on jo tehty hyvityksiä. Maksimi tuki on';
$_['text_refund']		   = 'Palautusta';

// Entry
$_['entry_transaction_id'] = 'Tapahtuman tunnus';
$_['entry_full_refund']	   = 'Täysi hyvitys';
$_['entry_amount']		   = 'Summa';
$_['entry_message']		   = 'Viesti';

// Button
$_['button_refund']		   = 'Issue hyvitys';

// Error
$_['error_partial_amt']	   = 'Sinun täytyy syöttää osittainen palautus summa';
$_['error_data']		   = 'Pyynnöstä puuttuvat tiedot';