<?php
// Heading
$_['heading_title']      = 'Posti ennakko';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muuttanut käteistä toimitus Maksu moduuli!';
$_['text_edit']          = 'Muokkaa posti ennakko';

// Entry
$_['entry_total']        = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Help
$_['help_total']         = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muuttaa maksua käteisellä toimituksen!';