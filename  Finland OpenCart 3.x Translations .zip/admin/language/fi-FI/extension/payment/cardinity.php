<?php
// Heading
$_['heading_title']			= 'Kardinity';

// Text
$_['text_extension']		= 'Tiedostopääte';
$_['text_success']			= 'Menestys: olet muuttanut cardinity Maksu moduuli!';
$_['text_edit']             = 'Muokkaa kardinticity';
$_['text_cardinity']		= '<a href="http://cardinity.com/?crdp=opencart" target="_blank"><img src="view/image/payment/cardinity.png" alt="Cardinity" title="Cardinity" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_production']		= 'Tuotanto';
$_['text_sandbox']			= 'Hiekkalaatikko';
$_['text_payment_info']		= 'Palautus tiedot';
$_['text_no_refund']		= 'Ei hyvitys historiaa';
$_['text_confirm_refund']	= 'Haluatko varmasti palauttaa';
$_['text_na']				= 'N/a';
$_['text_success_action']	= 'Menestys';
$_['text_error_generic']	= 'Virhe: pyynnössä tapahtui virhe. Tarkista lokit.';

// Column
$_['column_refund']			= 'Palautusta';
$_['column_date']			= 'Päivämäärä';
$_['column_refund_history'] = 'Palautus historia';
$_['column_action']			= 'Toiminta';
$_['column_status']			= 'Tila';
$_['column_amount']			= 'Summa';
$_['column_description']	= 'Kuvaus';

// Entry
$_['entry_total']			= 'Yhteensä';
$_['entry_order_status']	= 'Tila uksen tila';
$_['entry_geo_zone']		= 'Geo Zone';
$_['entry_status']			= 'Tila';
$_['entry_sort_order']		= 'Lajittelujärjestyksen';
$_['entry_key']				= 'Avain';
$_['entry_secret']			= 'Salainen';
$_['entry_debug']			= 'Debug';

// Help
$_['help_debug']			= 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_total']			= 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Button
$_['button_refund']			= 'Palautusta';

// Error
$_['error_key']				= 'Avain tarvitaan!';
$_['error_secret']			= 'Salaisuus vaaditaan!';
$_['error_composer']		= 'Kardinity SDK:n lataaminen ei onnistu. Lataa koottu toimittaja kansio tai Suorita säveltäjä.';
$_['error_php_version']		= 'Vähimmäis-käännös-lta PHP 5.4.0 on tarvittaessa!';
$_['error_permission']		= 'Varoitus: sinulla ei ole oikeuksia muokata maksu kardinelity!';
$_['error_connection']		= 'Virhe määritettäessä yhteyttä kardinity API-liittymään. Tarkista avaimesi ja salaiset asetukset.';
$_['error_warning']			= 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';