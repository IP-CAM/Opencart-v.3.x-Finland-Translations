<?php
// Heading
$_['heading_title']                 = 'Cardconnect';

// Tab
$_['tab_settings']                  = 'Asetukset';
$_['tab_order_status']              = 'Tila uksen tila';

// Text
$_['text_extension']                = 'Tiedostopääte';
$_['text_success']                  = 'Onnistui: olet muokannut cardconnect-maksu moduulia!';
$_['text_edit']                     = 'Muokkaa cardconnect';
$_['text_cardconnect']              = '<a href="http://www.cardconnect.com" target="_blank"><img src="view/image/payment/cardconnect.png" alt="CardConnect" title="CardConnect"></a>';
$_['text_payment']                  = 'Maksu';
$_['text_authorize']                = 'Valtuuttaa';
$_['text_live']                     = 'Live';
$_['text_test']                     = 'Testi';
$_['text_no_cron_time']             = 'Cron ei ole vielä suoritettu';
$_['text_payment_info']             = 'Maksu tiedot';
$_['text_payment_method']           = 'Maksutapa';
$_['text_card']                     = 'Kortti';
$_['text_echeck']                   = 'Echeck';
$_['text_reference']                = 'Viite';
$_['text_update']                   = 'Päivitys';
$_['text_order_total']              = 'Tilausten kokonaismäärä';
$_['text_total_captured']           = 'Yhteensä kiinni';
$_['text_capture_payment']          = 'Sieppauksen maksu';
$_['text_refund_payment']           = 'Palautus maksu';
$_['text_void']                     = 'Mitätön';
$_['text_transactions']             = 'Tapahtumat';
$_['text_column_type']              = 'Tyyppi';
$_['text_column_reference']         = 'Viite';
$_['text_column_amount']            = 'Summa';
$_['text_column_status']            = 'Tila';
$_['text_column_date_modified']     = 'Muokkaus päivämäärä';
$_['text_column_date_added']        = 'Päivä määrä lisätty';
$_['text_column_update']            = 'Päivitys';
$_['text_column_void']              = 'Mitätön';
$_['text_confirm_capture']          = 'Haluatko varmasti siepata maksun?';
$_['text_confirm_refund']           = 'Haluatko varmasti palauttaa maksun?';
$_['text_inquire_success']          = 'Kysely onnistui';
$_['text_capture_success']          = 'Sieppaus pyyntö onnistui';
$_['text_refund_success']           = 'Hyvitys pyyntö onnistui';
$_['text_void_success']             = 'Mitätöity pyyntö onnistui';

// Entry
$_['entry_merchant_id']             = 'Kauppias id';
$_['entry_api_username']            = 'API-käyttäjä nimi';
$_['entry_api_password']            = 'API-sala sana';
$_['entry_token']                   = 'Salainen tunnus';
$_['entry_transaction']             = 'Tapahtuman';
$_['entry_environment']             = 'Ympäristö';
$_['entry_site']                    = 'Sivuston';
$_['entry_store_cards']             = 'Säilytä kortit';
$_['entry_echeck']                  = 'Echeck';
$_['entry_total']                   = 'Yhteensä';
$_['entry_geo_zone']                = 'Geo Zone';
$_['entry_status']                  = 'Tila';
$_['entry_logging']                 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_sort_order']              = 'Lajittelujärjestyksen';
$_['entry_cron_url']                = 'Cron Job URL';
$_['entry_cron_time']               = 'Ajastettu työ viime Run';
$_['entry_order_status_pending']    = 'Odottavat';
$_['entry_order_status_processing'] = 'Käsittely';

// Help
$_['help_merchant_id']              = 'Henkilökohtainen cardconnect-tilisi kauppias tunnus.';
$_['help_api_username']             = 'Sinun username jotta pääsy cardconnect API.';
$_['help_api_password']             = 'Sala sanasi cardconnect API-liittymän käyttöä varten.';
$_['help_token']                    = 'Anna satunnainen tunnus turvallisuuden tai käyttää yksi luotu.';
$_['help_transaction']              = 'Valitse maksu, jos haluat siepata maksun heti tai hyväksyä sen.';
$_['help_site']                     = 'Tämä määrittää API-URL-osoitteen ensimmäisen osan. Ainoa heilahdus tokko antaa tehtäväksi.';
$_['help_store_cards']              = 'Haluatko tallentaa kortteja käyttämällä totoisaatiota.';
$_['help_echeck']                   = 'Haluatko tarjota mahdollisuuden maksaa eCheck-ohjelmalla.';
$_['help_total']                    = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu. On oltava arvo, jolla ei ole valuutta merkkiä.';
$_['help_logging']                  = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_cron_url']                 = 'Aseta ajastettu työ kutsua tätä URL niin, että tila ukset päivitetään automaattisesti. Se on suunniteltu juoksi muutaman tunnin kuluttua viimeisen kaapata arki päivän.';
$_['help_cron_time']                = 'Tämä on viimeinen kerta, kun cron-työn URL-osoite on suoritettu.';
$_['help_order_status_pending']     = 'Tilaus tila, kun kauppias on valtuuttanut tila uksen.';
$_['help_order_status_processing']  = 'Tila uksen tila, kun tilaus on automaattisesti kaapattu.';

// Button
$_['button_inquire_all']            = 'Kysele kaikki';
$_['button_capture']                = 'Kaapata';
$_['button_refund']                 = 'Palautusta';
$_['button_void_all']               = 'Mitätöi kaikki';
$_['button_inquire']                = 'Tiedustella';
$_['button_void']                   = 'Mitätön';

// Error
$_['error_permission']              = 'Varoitus: sinulla ei ole oikeuksia muokata maksu kortti yhteyttä!';
$_['error_merchant_id']             = 'Kauppias id tarvitaan!';
$_['error_api_username']            = 'API-käyttäjä nimi vaaditaan!';
$_['error_api_password']            = 'API sala sana tarvitaan!';
$_['error_token']                   = 'Salainen Token tarvitaan!';
$_['error_site']                    = 'Sivusto tarvitaan!';
$_['error_amount_zero']             = 'Summan on oltava suurempi kuin nolla!';
$_['error_no_order']                = 'Ei vastaavia tilaus info!';
$_['error_invalid_response']        = 'Virheellinen vastaus vastaanotettu!';
$_['error_data_missing']            = 'Puuttuvat tiedot!';
$_['error_not_enabled']             = 'Moduuli ei ole käytössä!';