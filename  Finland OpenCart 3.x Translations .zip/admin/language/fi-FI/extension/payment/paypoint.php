<?php
// Heading
$_['heading_title']		 = 'PayPoint';

// Text
$_['text_extension']	 = 'Tiedostopääte';
$_['text_success']		 = 'Onnistui: olet muokannut PayPoint-tili tietojasi!';
$_['text_edit']          = 'Muokkaa PayPoint';
$_['text_paypoint']		 = '<a href="https://www.paypoint.net/partners/opencart" target="_blank"><img src="view/image/payment/paypoint.png" alt="PayPoint" title="PayPoint" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_live']			 = 'Tuotanto';
$_['text_successful']	 = 'Aina onnistunut';
$_['text_fail']			 = 'Aina epäonnistua';

// Entry
$_['entry_merchant']	 = 'Kauppias id';
$_['entry_password']	 = 'Etäinen tunnus sana';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_password']		 = 'Jätä tyhjä, jos sinulla ei ole "Digest avain todennus" käytössä tililläsi.';
$_['help_total']		 = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muuttaa maksun PayPoint!';
$_['error_merchant']	 = 'Kauppias id tarvitaan!';