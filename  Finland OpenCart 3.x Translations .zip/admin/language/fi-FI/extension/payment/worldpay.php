<?php
// Heading
$_['heading_title']				         = 'WorldPay online-maksut';

// Text
$_['text_extension']				     = 'Tiedostopääte';
$_['text_success']				         = 'Menestys: olet muokannut WorldPay-tili tietoja!';
$_['text_worldpay']				         = '<a href="https://online.worldpay.com/signup/ee48b6e6-d3e3-42aa-a80e-cbee3f4f8b09" target="_blank"><img src="view/image/payment/worldpay.png" alt="Worldpay" title="Worldpay" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_test']					         = 'Testi';
$_['text_live']					         = 'Live';
$_['text_authenticate']			         = 'Todentaa';
$_['text_release_ok']		 	         = 'Julkaisu onnistui';
$_['text_release_ok_order']		         = 'Julkaisu onnistui, tila uksen tila päivitettiin menestykseen-selvitetty';
$_['text_refund_ok']			         = 'Osto hyvitys onnistui';
$_['text_refund_ok_order']		         = 'Osto hyvitys onnistui, tila uksen tila päivitettiin palautusta varten';
$_['text_void_ok']				         = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';

// Entry
$_['entry_service_key']			         = 'Palvelun avain';
$_['entry_client_key']			         = 'Työaseman avain';
$_['entry_total']				         = 'Yhteensä';
$_['entry_order_status']		         = 'Tila uksen tila';
$_['entry_geo_zone']			         = 'Geo Zone';
$_['entry_status']				         = 'Tila';
$_['entry_sort_order']			         = 'Lajittelujärjestyksen';
$_['entry_debug']				         = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_card']				         = 'Säilytä kortit';
$_['entry_secret_token']		         = 'Salainen tunnus';
$_['entry_webhook_url']			         = 'Webhook-URL-osoite:';
$_['entry_cron_job_url']		         = 'Cron Job URL:';
$_['entry_last_cron_job_run']	         = 'Viimeinen cron-työsuorituksen aika:';
$_['entry_success_status']		         = 'Onnistumisen tila:';
$_['entry_failed_status']		         = 'Epäonnistunut tila:';
$_['entry_settled_status']			     = 'Selvitetty tila:';
$_['entry_refunded_status']			     = 'Palautettu tila:';
$_['entry_partially_refunded_status']	 = 'Osittain palautettu tila:';
$_['entry_charged_back_status']			 = 'Ladattu takaisin:';
$_['entry_information_requested_status'] = 'Pyydetyt tiedot tila:';
$_['entry_information_supplied_status']	 = 'Toimitettujen tietojen tila:';
$_['entry_chargeback_reversed_status']	 = 'Takaisinperinnän palautettu tila:';


$_['entry_reversed_status']			     = 'Palautettu tila:';
$_['entry_voided_status']			     = 'Mitätöity tila:';

// Help
$_['help_total']				         = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';
$_['help_debug']				         = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulee aina poistaa käytöstä, ellei ohjeissa toisin mainita';
$_['help_secret_token']			         = 'Tee tämä pitkä ja vaikea arvata';
$_['help_webhook_url']			         = 'Aseta WorldPay webhooks kutsua tätä URL';
$_['help_cron_job_url']			         = 'Aseta ajastettu tehtävä kutsua tätä URL';

// Tab
$_['tab_settings']				         = 'Asetukset';
$_['tab_order_status']			         = 'Tila uksen tila';

// Error
$_['error_permission']			         = 'Varoitus: sinulla ei ole oikeutta muuttaa maksua WorldPay!';
$_['error_service_key']			         = 'Tarvittava palvelu avain!';
$_['error_client_key']			         = 'Tarvittava asiakas avain!';

// Order page - payment tab
$_['text_payment_info']			         = 'Maksu tiedot';
$_['text_refund_status']		         = 'Maksun palautus';
$_['text_order_ref']			         = 'Tilaa REF';
$_['text_order_total']			         = 'Sallittu kokonaismäärä';
$_['text_total_released']		         = 'Yhteensä julkaistu';
$_['text_transactions']			         = 'Tapahtumat';
$_['text_column_amount']		         = 'Summa';
$_['text_column_type']			         = 'Tyyppi';
$_['text_column_date_added']	         = 'Lisännyt';

$_['text_confirm_refund']		         = 'Haluatko varmasti palauttaa maksun?';

$_['button_refund']				         = 'Osto hyvitys/hyvitys';

