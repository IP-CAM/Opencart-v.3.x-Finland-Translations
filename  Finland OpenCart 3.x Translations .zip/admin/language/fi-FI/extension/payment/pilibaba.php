<?php
// Heading
$_['heading_title']         = 'Pilibaba Kiinan kassalle';

// Tab
$_['tab_register']          = 'Rekisteröidy';
$_['tab_settings']          = 'Asetukset';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_success']          = 'Menestys: olet muokannut pilibaba Maksu moduuli!';
$_['text_edit']             = 'Muokkaa pilibaba';
$_['text_pilibaba']         = '<a href="http://www.pilibaba.com" target="_blank"><img src="view/image/payment/pilibaba.png" alt="Pilibaba" title="Pilibaba"></a>';
$_['text_live']             = 'Live';
$_['text_test']             = 'Testi';
$_['text_payment_info']     = 'Maksu info';
$_['text_order_id']         = 'Tilauksen tunnus';
$_['text_amount']           = 'Summa';
$_['text_fee']              = 'Maksu';
$_['text_date_added']       = 'Päivä määrä lisätty';
$_['text_tracking']         = 'Seuranta';
$_['text_barcode']          = 'Viivakoodi';
$_['text_barcode_info']     = '(Tulosta tämä ainutlaatuinen viiva koodi ja pysyä sen pinnalla paketti)';
$_['text_confirm']          = 'Haluatko varmasti päivittää seuranta numeron?';
$_['text_register_success'] = 'Olet rekisteröitynyt. Sinun pitäisi saada sähköpostitse lähiaikoina.';
$_['text_tracking_success'] = 'Seuranta numero päivitettiin onnistuneesti.';
$_['text_other']            = 'Muut';
$_['text_email']            = 'Pilibaba-tilisi rekisteröity Sähkö posti osoite on %s';

// Entry
$_['entry_email_address']   = 'Sähköpostiosoite';
$_['entry_password']        = 'Salasana';
$_['entry_currency']        = 'Valuutta';
$_['entry_warehouse']       = 'Varasto';
$_['entry_country']         = 'Maa';
$_['entry_merchant_number'] = 'Kauppias numero';
$_['entry_secret_key']      = 'Salainen avain';
$_['entry_environment']     = 'Ympäristö';
$_['entry_shipping_fee']    = 'Toimitus maksu';
$_['entry_order_status']    = 'Tila uksen tila';
$_['entry_status']          = 'Tila';
$_['entry_logging']         = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

// Help
$_['help_email_address']    = 'Kirjoita tämän yrityksen omistajan Sähkö posti osoite.';
$_['help_password']         = 'Anna sala sana väliltä 8-30 merkkiä.';
$_['help_currency']         = 'Valitse valuuttaa käytetään sivustossasi ja vetäytyä pankki tilillesi.';
$_['help_warehouse']        = 'Valitse Lähin varasto, johon toimitus toimitetaan. Kun vastaanotat tila uksia kiinalaisilta asiakkailta (Via pilibaba Gateway), voit toimittaa paketteja tähän varastoon.';
$_['help_country']          = 'Kerro meille maasi, ja me ilmoitamme sinulle, kun varasto tässä maassa on avattu.';
$_['help_merchant_number']  = 'Henkilökohtainen pilibaba tili kauppias numero.';
$_['help_secret_key']       = 'Salainen avain käyttää pilibaba API.';
$_['help_shipping_fee']     = 'Toimitus kulut varastostamme pilibaba-varastoon. Käytä kahta Desi maalia.';
$_['help_order_status']     = 'Tila uksen tila, kun asiakas on asettanut tila uksen.';
$_['help_total']            = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu. On oltava arvo, jolla ei ole valuutta merkkiä.';
$_['help_logging']          = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';

// Error
$_['error_warning']         = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']      = 'Varoitus: sinulla ei ole lupaa muuttaa maksua pilibaba!';
$_['error_merchant_number'] = 'Kauppias numero tarvitaan!';
$_['error_secret_key']      = 'Salainen avain vaaditaan!';
$_['error_shipping_fee']    = 'Toimitus maksun on oltava desimaali luku!';
$_['error_not_enabled']     = 'Moduuli ei ole käytössä!';
$_['error_data_missing']    = 'Tiedot puuttuvat!';
$_['error_tracking_length'] = 'Seuranta numeron on oltava 1-50 merkkiä!';
$_['error_email_address']   = 'Kirjoita Sähkö posti osoitteesi!';
$_['error_email_invalid']   = 'Sähkö posti osoite ei kelpaa!';
$_['error_password']        = 'Sala sanassa on oltava vähintään 8 merkkiä!';
$_['error_currency']        = 'Valitse valuutta!';
$_['error_warehouse']       = 'Valitse varasto!';
$_['error_country']         = 'Ole hyvä ja valitse maa!';
$_['error_weight']          = 'Haluta heilahdus sinun <a href="%s">Paino luokka</a> asetukseksi grammaa. Se on "System-> asetukset" in "Local"-väli lehti.';
$_['error_bad_response']    = 'Vastaanotettiin virheellinen vastaus. Yritä myöhemmin uudelleen.';

// Button
$_['button_register']       = 'Rekisteröidy';
$_['button_tracking']       = 'Päivityksen seuranta numero';
$_['button_barcode']        = 'Luo viiva koodi';