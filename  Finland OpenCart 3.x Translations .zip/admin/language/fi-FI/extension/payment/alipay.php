<?php
// Heading
$_['heading_title']                  = 'Alipay-maksu';

// Text
$_['text_extension']                 = 'Tiedostopääte';
$_['text_success']                   = 'Menestys: olet muokannut Alipay tili tiedot!';
$_['text_edit']                      = 'Muokkaa Alipay-maksu';
$_['text_alipay']                    = '<a target="_BLANK" href="https://open.alipay.com"><img src="view/image/payment/alipay.png" alt="Alipay Pay Website" title="Alipay Pay Website" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_live']                      = 'Live';
$_['text_sandbox']                   = 'Hiekkalaatikko';

// Entry
$_['entry_app_id']                   = 'Sovelluksen tunnus';
$_['entry_merchant_private_key']     = 'Kauppias yksityinen avain';
$_['entry_alipay_public_key']        = 'Alipay julkinen avain';
$_['entry_test']                     = 'Testi tilassa';
$_['entry_total']                    = 'Yhteensä';
$_['entry_order_status']             = 'Valmis tila';
$_['entry_geo_zone']                 = 'Geo Zone';
$_['entry_status']                   = 'Tila';
$_['entry_sort_order']               = 'Lajittelujärjestyksen';

// Help
$_['help_total']                     = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_alipay_setup']              = '<a target="_blank" href="http://www.opencart.cn/docs/alipay">Klikkaa tästä</a> lisä tietoja Alipay-tilin määrittämisestä.';

// Error
$_['error_permission']               = 'Varoitus: sinulla ei ole oikeutta muuttaa maksu Alipay!';
$_['error_app_id']                   = 'Sovelluksen tunnus vaaditaan!';
$_['error_merchant_private_key']     = 'Merchant yksityinen avain tarvitaan!';
$_['error_alipay_public_key']        = 'Alipay julkinen avain tarvitaan!';
