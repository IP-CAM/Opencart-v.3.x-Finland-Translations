<?php
// Heading
$_['heading_title']      = 'Ilmainen Checkout';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muokannut vapaa kassalle Maksu moduuli!';
$_['text_edit']          = 'Muokkaa ilmainen Checkout';

// Entry
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muokata maksuvapaata kassalle!';