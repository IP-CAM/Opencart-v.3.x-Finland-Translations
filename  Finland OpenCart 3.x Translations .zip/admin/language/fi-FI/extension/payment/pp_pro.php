<?php
// Heading
$_['heading_title']		 = 'PayPal Pro';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']		 = 'Menestys: olet muokannut PayPal Website Payment Pro Checkout-tilin tiedot!';
$_['text_edit']          = 'Muokkaa PayPal Pro';
$_['text_pp_pro']		 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Website Payment Pro" title="PayPal Website Payment Pro iFrame" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'Lupa';
$_['text_sale']			 = 'Myynti';

// Entry
$_['entry_username']	 = 'API-käyttäjä nimi';
$_['entry_password']	 = 'API-sala sana';
$_['entry_signature']	 = 'API-allekirjoitus';
$_['entry_test']		 = 'Testi tilassa';
$_['entry_transaction']	 = 'Tapahtuma menetelmä:';
$_['entry_total']		 = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Tila';
$_['entry_sort_order']	 = 'Lajittelujärjestyksen';

// Help
$_['help_test']			 = 'Käytä Live-tai Testing (Sandbox)-yhdyskäytäväpalvelinta tapahtumien käsittelemiseen?';
$_['help_total']		 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';

// Error
$_['error_permission']	 = 'Varoitus: sinulla ei ole lupaa muuttaa maksua PayPal Website maksu Pro kassalle!';
$_['error_username']	 = 'API-käyttäjä nimi vaaditaan!';
$_['error_password']	 = 'API sala sana tarvitaan!';
$_['error_signature']	 = 'API allekirjoitus tarvitaan!';