<?php
// Heading
$_['heading_title']      = 'Sekki/maksu määräys';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muokannut sekki/maksu määräys tili tiedot!';
$_['text_edit']          = 'Muokkaa sekki/maksu määräys';

// Entry
$_['entry_payable']      = 'Maksettava';
$_['entry_total']        = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Help
$_['help_total']         = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muuttaa maksu sekkiä/raha tilausta!';
$_['error_payable']      = 'Maksettava vaaditaan!';