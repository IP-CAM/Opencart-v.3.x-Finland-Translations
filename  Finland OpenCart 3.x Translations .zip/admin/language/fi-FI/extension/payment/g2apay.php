<?php
// Heading
$_['heading_title']				 	  = 'G2APay';

// Text
$_['text_extension']				  = 'Tiedostopääte';
$_['text_success']				 	  = 'Menestys: olet muokannut G2APay yksityiskohtia.';
$_['text_edit']					 	  = 'Muokkaa G2APay';
$_['text_g2apay']				 	  = '<a href="https://pay.g2a.com/" target="_blank"><img src="view/image/payment/g2apay.png" alt="G2APay" title="G2APay" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_payment_info']			 	  = 'Maksu tiedot';
$_['text_refund_status']		 	  = 'Maksun palautus';
$_['text_order_ref']			 	  = 'Tilaa REF';
$_['text_order_total']			 	  = 'Sallittu kokonaismäärä';
$_['text_total_released']		 	  = 'Yhteensä julkaistu';
$_['text_transactions']			 	  = 'Tapahtumat';
$_['text_column_amount']		 	  = 'Summa';
$_['text_column_type']			 	  = 'Tyyppi';
$_['text_column_date_added']	 	  = 'Lisännyt';
$_['text_refund_ok']			 	  = 'Palautusta pyydettiin';
$_['text_refund_ok_order']		 	  = 'Hyvitys pyyntö onnistui, summa palautetaan kokonaan';

// Entry
$_['entry_username']			 	  = 'Käyttäjätunnus';
$_['entry_secret']				 	  = 'Salainen';
$_['entry_api_hash']		     	  = 'API hash';
$_['entry_environment']			 	  = 'Ympäristö';
$_['entry_secret_token']		 	  = 'Salainen tunnus';
$_['entry_ipn_url']				 	  = 'IPN URL:';
$_['entry_total']				 	  = 'Yhteensä';
$_['entry_geo_zone']			 	  = 'Geo Zone';
$_['entry_status']				 	  = 'Tila';
$_['entry_sort_order']			 	  = 'Lajittelujärjestyksen';
$_['entry_debug']				 	  = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_order_status']			  = 'Tila uksen tila';
$_['entry_complete_status']			  = 'Täydellinen tila:';
$_['entry_rejected_status']			  = 'Hylätty tila:';
$_['entry_cancelled_status']		  = 'Peruutettu tila:';
$_['entry_pending_status']            = 'Odottava tila:';
$_['entry_refunded_status']			  = 'Palautettu tila:';
$_['entry_partially_refunded_status'] = 'Osittain palautettu tila:';

// Help
$_['help_username']					  = 'Tiliisi käytetty Sähkö posti osoite';
$_['help_total']				 	  = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';
$_['help_debug']				 	  = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulee aina poistaa käytöstä, ellei ohjeissa toisin mainita';

// Tab
$_['tab_settings']				 	  = 'Asetukset';
$_['tab_order_status']				  = 'Tila uksen tila';

// Error
$_['error_permission']			 	  = 'Varoitus: sinulla ei ole oikeutta muokata G2APay!';
$_['error_email']				 	  = 'E-Mail tarvitaan!';
$_['error_secret']				 	  = 'Salaisuus vaaditaan!';
$_['error_api_hash']			 	  = 'API hash tarvitaan!';
$_['entry_status']				 	  = 'Tila';

//Button
$_['btn_refund']				 	  = 'Palautusta';

$_['g2apay_environment_live']	 	  = 'Live';
$_['g2apay_environment_test']	 	  = 'Testi';