<?php
// Heading
$_['heading_title']					 = 'Ensimmäinen tieto EMEA-verkko palvelun API-liittymä';

// Text
$_['text_firstdata_remote']			 = '<img src="view/image/payment/firstdata.png" alt="First Data" title="First Data" style="border: 1px solid #EEEEEE;" />';
$_['text_extension']					 = 'Tiedostopääte';
$_['text_success']					 = 'Menestys: olet muokannut ensimmäinen Data tili tiedot!';
$_['text_edit']                      = 'Muokkaa ensimmäisiä tietoja EMEA-verkko palvelun API-liittymä';
$_['text_card_type']				 = 'Kortin tyyppi';
$_['text_enabled']					 = 'Käytössä';
$_['text_merchant_id']				 = 'Myymälän tunnus';
$_['text_subaccount']				 = 'Aliasiakkuus';
$_['text_user_id']					 = 'Käyttäjätunnus';
$_['text_capture_ok']				 = 'Capture onnistui';
$_['text_capture_ok_order']			 = 'Capture onnistui, tila uksen tila päivitettiin menestykseen-ratkaistu';
$_['text_refund_ok']				 = 'Hyvitys onnistui';
$_['text_refund_ok_order']			 = 'Palautus onnistui, tila uksen tilaksi päivitetään palautettu';
$_['text_void_ok']					 = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';
$_['text_settle_auto']				 = 'Myynti';
$_['text_settle_delayed']			 = 'Pre auth';
$_['text_mastercard']				 = 'Mastercard';
$_['text_visa']						 = 'Visa';
$_['text_diners']					 = 'Diners';
$_['text_amex']						 = 'American Express';
$_['text_maestro']					 = 'Maestro';
$_['text_payment_info']				 = 'Maksu tiedot';
$_['text_capture_status']			 = 'Maksu otettu';
$_['text_void_status']				 = 'Maksu mitätöity';
$_['text_refund_status']			 = 'Maksu palautetaan';
$_['text_order_ref']				 = 'Tilaa REF';
$_['text_order_total']				 = 'Sallittu kokonaismäärä';
$_['text_total_captured']			 = 'Yhteensä kiinni';
$_['text_transactions']				 = 'Tapahtumat';
$_['text_column_amount']			 = 'Summa';
$_['text_column_type']				 = 'Tyyppi';
$_['text_column_date_added']		 = 'Luotu';
$_['text_confirm_void']				 = 'Haluatko varmasti mitätöidä maksun?';
$_['text_confirm_capture']			 = 'Haluatko varmasti siepata maksun?';
$_['text_confirm_refund']			 = 'Haluatko varmasti palauttaa maksun?';

// Entry
$_['entry_certificate_path']		 = 'Varmenteen polku';
$_['entry_certificate_key_path']	 = 'Yksityisen avaimen polku';
$_['entry_certificate_key_pw']		 = 'Yksityisen avaimen sala sana';
$_['entry_certificate_ca_path']		 = 'Varmenteiden myöntäjän polku';
$_['entry_merchant_id']				 = 'Myymälän tunnus';
$_['entry_user_id']					 = 'Käyttäjätunnus';
$_['entry_password']				 = 'Salasana';
$_['entry_total']					 = 'Yhteensä';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_debug']					 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_auto_settle']				 = 'Tilitys tyyppi';
$_['entry_status_success_settled']	 = 'Success-ratkaistu';
$_['entry_status_success_unsettled'] = 'Success-ei ratkaistu';
$_['entry_status_decline']			 = 'Lasku';
$_['entry_status_void']				 = 'Mitätöidä';
$_['entry_status_refund']			 = 'Palautetaan';
$_['entry_enable_card_store']		 = 'Ota kortti säilö tunnukset käyttöön';
$_['entry_cards_accepted']			 = 'Hyväksytyt kortti tyypit';

// Help
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_certificate']				 = 'Sertifikaatit ja yksityiset avaimet tulee tallentaa julkisten Web-kansioiden ulkopuolelle';
$_['help_card_select']				 = 'Pyydä käyttäjää valitsemaan korttinsa tyyppi, ennen kuin ne ohjataan uudelleen';
$_['help_notification']				 = 'Sinun täytyy toimittaa tämä URL ensimmäinen tiedot saada maksu ilmoitukset';
$_['help_debug']					 = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_settle']					 = 'Jos käytät pre-auth sinun on täytettävä post-auth toiminnan kuluessa 3-5 päivää muuten liike toimi poistetaan';

// Tab
$_['tab_account']					 = 'API-tiedot';
$_['tab_order_status']				 = 'Tila uksen tila';
$_['tab_payment']					 = 'Maksu Asetukset';

// Button
$_['button_capture']				 = 'Kaapata';
$_['button_refund']					 = 'Palautusta';
$_['button_void']					 = 'Mitätön';

// Error
$_['error_merchant_id']				 = 'Myymälän tunnus on pakollinen';
$_['error_user_id']					 = 'Käyttäjä tunnus on pakollinen';
$_['error_password']				 = 'Sala sana on pakollinen';
$_['error_certificate']				 = 'Sertifikaatin polku on pakollinen';
$_['error_key']						 = 'Varmenne avain on pakollinen';
$_['error_key_pw']					 = 'Varmenne avaimen sala sana on pakollinen';
$_['error_ca']						 = 'Sertifikaatin myöntäjä (CA) on pakollinen';