<?php
// Heading
$_['heading_title']      = 'Pankkisiirto';

// Text
$_['text_extension']     = 'Tiedostopääte';
$_['text_success']       = 'Menestys: olet muuttanut pankki siirrolla tiedot!';
$_['text_edit']          = 'Muokkaa pankki siirtoa';

// Entry
$_['entry_bank']         = 'Pankki siirto-ohjeet';
$_['entry_total']        = 'Yhteensä';
$_['entry_order_status'] = 'Tila uksen tila';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Tila';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Help
$_['help_total']         = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.'; 

// Error 
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muokata maksu pankki siirtoa!';
$_['error_bank']         = 'Pankki siirrolla tarvittavat ohjeet!';