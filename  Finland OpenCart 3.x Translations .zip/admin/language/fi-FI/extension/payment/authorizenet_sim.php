<?php
// Heading
$_['heading_title']			= 'Authorize.net (SIM)';

// Text
$_['text_extension']		= 'Tiedostopääte';
$_['text_success']			= 'Menestys: olet muokannut Authorize.net (SIM) tili tiedot!';
$_['text_edit']             = 'Muokkaa Authorize.net (SIM)';
$_['text_authorizenet_sim']	= '<a onclick="window.open(\'http://reseller.authorize.net/application/?id=5561142\');"><img src="view/image/payment/authorizenet.png" alt="Authorize.Net" title="Authorize.Net" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant']		= 'Kauppias id';
$_['entry_key']				= 'Tapahtuman avain';
$_['entry_callback']		= 'Rele vasta uksen URL-osoite';
$_['entry_md5']				= 'MD5-hajautus arvo';
$_['entry_test']			= 'Testi tilassa';
$_['entry_total']			= 'Yhteensä';
$_['entry_order_status']	= 'Tila uksen tila';
$_['entry_geo_zone']		= 'Geo Zone';
$_['entry_status']			= 'Tila';
$_['entry_sort_order']		= 'Lajittelujärjestyksen';

// Help
$_['help_callback']			= 'Ole hyvä ja Kirjaudu sisään ja Aseta tämä <a href="https://secure.authorize.net" target="_blank" class="txtLink">https://Secure.Authorize.net</a>.';
$_['help_md5']				= 'MD5-hajautus ominaisuuden avulla voit todentaa, että tapahtuma vastaus on saatu turvallisesti .net-valtuutuksella. Kirjaudu sisään ja Aseta tämä <a href="https://secure.authorize.net" target="_blank" class="txtLink">https://Secure.Authorize.net</a>. vAlinnainen';
$_['help_total']			= 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']		= 'Varoitus: sinulla ei ole oikeutta muokata maksu Authorize.net (SIM)!';
$_['error_merchant']		= 'Kauppias id tarvitaan!';
$_['error_key']				= 'Tapahtuma avain vaaditaan!';