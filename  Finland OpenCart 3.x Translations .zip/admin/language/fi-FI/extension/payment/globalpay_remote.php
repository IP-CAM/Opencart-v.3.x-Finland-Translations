<?php
// Heading
$_['heading_title']					 = 'Globalpay etäinen';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']					 = 'Menestys: olet muokannut globalpay tili tiedot!';
$_['text_edit']                      = 'Muokkaa globalpay-kaukosäädin';
$_['text_card_type']				 = 'Kortin tyyppi';
$_['text_enabled']					 = 'Käytössä';
$_['text_use_default']				 = 'Käytä oletus';
$_['text_merchant_id']				 = 'Kauppias id';
$_['text_subaccount']				 = 'Alatili';
$_['text_secret']					 = 'Jaettu salaisuus';
$_['text_card_visa']				 = 'Visa';
$_['text_card_master']				 = 'Mastercard';
$_['text_card_amex']				 = 'American Express';
$_['text_card_switch']				 = 'Switch/Maestro';
$_['text_card_laser']				 = 'Laser';
$_['text_card_diners']				 = 'Diners';
$_['text_capture_ok']				 = 'Capture onnistui';
$_['text_capture_ok_order']			 = 'Capture onnistui, tila uksen tila päivitettiin menestykseen-ratkaistu';
$_['text_rebate_ok']				 = 'Osto hyvitys onnistui';
$_['text_rebate_ok_order']			 = 'Osto hyvitys onnistui, tila uksen tila päivitetty korko hyvityksen';
$_['text_void_ok']					 = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';
$_['text_settle_auto']				 = 'Auto';
$_['text_settle_delayed']			 = 'Viivästynyt';
$_['text_settle_multi']				 = 'Multi';
$_['text_ip_message']				 = 'Sinun täytyy toimittaa palvelimen IP-osoite globalpay tilipäälliköksi ennen kuin asut';
$_['text_payment_info']				 = 'Maksu tiedot';
$_['text_capture_status']			 = 'Maksu otettu';
$_['text_void_status']				 = 'Maksu mitätöity';
$_['text_rebate_status']			 = 'Maksu kiihtyi';
$_['text_order_ref']				 = 'Tilaa REF';
$_['text_order_total']				 = 'Sallittu kokonaismäärä';
$_['text_total_captured']			 = 'Yhteensä kiinni';
$_['text_transactions']				 = 'Tapahtumat';
$_['text_confirm_void']				 = 'Haluatko varmasti mitätöidä maksun?';
$_['text_confirm_capture']			 = 'Haluatko varmasti siepata maksun?';
$_['text_confirm_rebate']			 = 'Haluatko varmasti hyvityksen maksusi?';
$_['text_globalpay_remote']			 = '<a target="_blank" href="https://resourcecentre.globaliris.com/getting-started.php?id=OpenCart"><img src="view/image/payment/globalpay.png" alt="Globalpay" title="Globalpay" style="border: 1px solid #EEEEEE;" /></a>';

// Column
$_['text_column_amount']			 = 'Summa';
$_['text_column_type']				 = 'Tyyppi';
$_['text_column_date_added']		 = 'Luotu';

// Entry
$_['entry_merchant_id']				 = 'Kauppias id';
$_['entry_secret']					 = 'Jaettu salaisuus';
$_['entry_rebate_password']			 = 'Osto hyvityksen sala sana';
$_['entry_total']					 = 'Yhteensä';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_debug']					 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_auto_settle']				 = 'Tilitys tyyppi';
$_['entry_tss_check']				 = 'TSS tarkistaa';
$_['entry_card_data_status']		 = 'Kortin tietojen kirjaaminen';
$_['entry_3d']						 = 'Ota 3D Secure';
$_['entry_liability_shift']			 = 'Hyväksy ei-korvaus vastuun vaihtuvien skenaarioiden hyväksyminen';
$_['entry_status_success_settled']	 = 'Success-ratkaistu';
$_['entry_status_success_unsettled'] = 'Success-ei ratkaistu';
$_['entry_status_decline']			 = 'Lasku';
$_['entry_status_decline_pending']	 = 'Hylkää-offline-todennus';
$_['entry_status_decline_stolen']	 = 'Hylkää-kadonnut tai varastettu kortti';
$_['entry_status_decline_bank']		 = 'Hylkää-pankki virhe';
$_['entry_status_void']				 = 'Mitätöidä';
$_['entry_status_rebate']			 = 'Korko hyvityksen';

// Help
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';
$_['help_card_select']				 = 'Pyydä käyttäjää valitsemaan korttinsa tyyppi, ennen kuin ne ohjataan uudelleen';
$_['help_notification']				 = 'Sinun täytyy toimittaa tämän URL globalpay saada maksu ilmoitukset';
$_['help_debug']					 = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_liability']				 = 'Vastuun hyväksyminen tarkoittaa, että voit silti hyväksyä maksut, kun käyttäjä epäonnistuu 3D Secure.';
$_['help_card_data_status']			 = 'Lokit viimeiset 4 korttia numeroa, voimassaolo aika, nimi, tyyppi ja myöntävän pankin tiedot';

// Tab
$_['tab_api']					     = 'API-tiedot';
$_['tab_account']				     = 'Tilit';
$_['tab_order_status']				 = 'Tila uksen tila';
$_['tab_payment']					 = 'Maksu Asetukset';

// Button
$_['button_capture']				 = 'Kaapata';
$_['button_rebate']					 = 'Osto hyvitys/hyvitys';
$_['button_void']					 = 'Mitätön';

// Error
$_['error_merchant_id']				 = 'Merchant ID vaaditaan';
$_['error_secret']					 = 'Jaettu salaisuus on pakollinen';