<?php
// Heading
$_['heading_title']                 = 'Myy-Osta';
$_['heading_transaction_title']     = 'Tapahtuman';

// Tab
$_['tab_settings']                  = 'Asetukset';
$_['tab_reports']                   = 'Raportit';
$_['tab_reference']                 = 'Viite tiedot';
$_['tab_customer']                  = 'Asiakkaan tiedot';
$_['tab_payment']                   = 'Maksu suunnitelma';
$_['tab_modify']                    = 'Muokkaa suunnitelmaa';

// Text
$_['text_extension']                = 'Tiedostopääte';
$_['text_success']                  = 'Menestys: olet muokannut myy-Buy Maksu moduuli!';
$_['text_edit']                     = 'Edit myy-Osta';
$_['text_laybuy']                   = '<a href="https://www.lay-buys.com" target="_blank"><img src="view/image/payment/laybuys.png" style="width:94px;height:25px" alt="Lay-Buys" title="Lay-Buys"></a>';
$_['text_cancel_success']           = 'Tapahtuma peruutettiin onnistuneesti.';
$_['text_cancel_failure']           = 'Peruutus pyyntö epäonnistui. Haluta koetus jälleen!';
$_['text_revise_success']           = 'Tarkistus pyyntö onnistui.';
$_['text_revise_failure']           = 'Tarkistus pyyntöä ei voitu korjata. Haluta koetus jälleen!';
$_['text_type_laybuy']              = 'Myy-Osta';
$_['text_type_buynow']              = 'Osta-nyt';
$_['text_status_1']                 = 'Odottavat';
$_['text_status_5']                 = 'Valmis';
$_['text_status_7']                 = 'Peruutettu';
$_['text_status_50']                = 'Tarkistamis pyyntö';
$_['text_status_51']                = 'Tarkistettu';
$_['text_fetched_some']             = 'Onnistuneesti päivitetty %d tapahtuma (t)';
$_['text_fetched_none']             = 'Päivitetäänkö tapahtumia ei ole.';
$_['text_transaction_details']      = 'Tapahtuman tiedot';
$_['text_not_found']                = 'Tällä tunnuksella ei ole tapahtumaa.';
$_['text_paypal_profile_id']        = 'PayPal-profiilin tunnus';
$_['text_laybuy_ref_no']            = 'Myy-Osta Reference ID';
$_['text_order_id']                 = 'Tilauksen tunnus';
$_['text_status']                   = 'Tila';
$_['text_amount']                   = 'Summa';
$_['text_downpayment_percent']      = 'Maksu prosentti';
$_['text_month']                    = 'Kuukausi';
$_['text_months']                   = 'Kuukautta';
$_['text_downpayment_amount']       = 'Maksun summa';
$_['text_payment_amounts']          = 'Maksujen summat';
$_['text_first_payment_due']        = 'Ensimmäinen erääntymistä koskeva maksu';
$_['text_last_payment_due']         = 'Viimeinen erääntymis maksu';
$_['text_instalment']               = 'Erä';
$_['text_date']                     = 'Päivämäärä';
$_['text_pp_trans_id']              = 'PayPal tapahtuma ID';
$_['text_downpayment']              = 'Alas maksu';
$_['text_report']                   = 'Maksu tietueen';
$_['text_revise_plan']              = 'Suunnitelman tarkistaminen';
$_['text_today']                    = 'Tänään';
$_['text_due_date']                 = 'Eräpäivä';
$_['text_cancel_plan']              = 'Peruuta suunnitelma';
$_['text_firstname']                = 'Etunimi';
$_['text_lastname']                 = 'Suku nimi';
$_['text_email']                    = 'Sähköposti';
$_['text_address']                  = 'Osoite';
$_['text_suburb']                   = 'Esikaupungissa';
$_['text_state']                    = 'Valtion';
$_['text_country']                  = 'Maa';
$_['text_postcode']                 = 'Postinumero';
$_['text_payment_info']		     	= 'Maksu tiedot';
$_['text_no_cron_time']             = 'Cron ei ole vielä suoritettu';
$_['text_comment'] 	                = 'Päivitetty Lay-Osta';
$_['text_comment_canceled'] 	    = 'Tilaa peruutettu ja toistuva PayPal Profile #%s Peruutettu.';
$_['text_remaining'] 	            = 'Jäljellä:';
$_['text_payment'] 	                = 'Maksu';

// Column
$_['column_order_id']               = 'Tilauksen tunnus';
$_['column_customer']               = 'Asiakas';
$_['column_amount']                 = 'Summa';
$_['column_dp_percent']             = 'Maksu prosentti';
$_['column_months']                 = 'Kuukautta';
$_['column_dp_amount']              = 'Maksun summa';
$_['column_first_payment']          = 'Ensimmäinen erääntymistä koskeva maksu';
$_['column_last_payment']           = 'Viimeinen erääntymis maksu';
$_['column_status']                 = 'Tila';
$_['column_date_added']             = 'Päivä määrä lisätty';
$_['column_action']                 = 'Toiminta';

// Entry
$_['entry_membership_id']           = 'Myy-Buy-jäsenyyden tunnus';
$_['entry_token']                   = 'Salainen tunnus';
$_['entry_minimum']                 = 'Minimi maksu (%)';
$_['entry_maximum']                 = 'Maksimi maksu (%)';
$_['entry_max_months']              = 'Kuukautta';
$_['entry_category']                = 'Sallitut Luokat';
$_['entry_product_ids']             = 'Poissuljetut tuote tunnukset';
$_['entry_customer_group']          = 'Sallitut asiakas ryhmät';
$_['entry_logging']                 = 'Virheen korjauksen kirjaaminen lokiin';
$_['entry_total']                   = 'Yhteensä';
$_['entry_order_status_pending']    = 'Tila uksen tila (odottaa)';
$_['entry_order_status_canceled']   = 'Tila uksen tila (peruutettu)';
$_['entry_order_status_processing'] = 'Tila uksen tila (käsittely)';
$_['entry_gateway_url']             = 'Yhdyskäytävän URL-osoite';
$_['entry_api_url']                 = 'API-URL';
$_['entry_geo_zone']                = 'Geo Zone';
$_['entry_status']                  = 'Tila';
$_['entry_sort_order']              = 'Lajittelujärjestyksen';
$_['entry_cron_url']                = 'Cron Job URL';
$_['entry_cron_time']               = 'Ajastettu työ viime Run';
$_['entry_order_id']                = 'Tilauksen tunnus';
$_['entry_customer']                = 'Asiakas';
$_['entry_dp_percent']              = 'Maksu prosentti';
$_['entry_months']                  = 'Kuukautta';
$_['entry_date_added']              = 'Päivä määrä lisätty';

// Help
$_['help_membership_id']            = 'Henkilökohtaisen Lay-Buy-tilin jäsen numero. (saavutetaan, kun rekisteröidyt kauppias tili osoitteessa https://www.Lay-Buys.com/index.php/vtmob/Login)';
$_['help_token']                    = 'Anna satunnainen tunnus turvallisuuden tai käyttää yksi luotu.';
$_['help_minimum']                  = 'Minimi talletus summa.';
$_['help_maximum']                  = 'Maksimi talletus summa.';
$_['help_months']                   = 'Makstasaldon enimmäismäärä kuukausia.';
$_['help_category']                 = 'Valitse, mihin luokkiin maksu vaihtoehto on käytettävissä. Jätä tyhjäksi, jos ei rajoitusta.';
$_['help_product_ids']              = 'Lisää tuote tunnukset pilkulla erotettuina (,), joiden menetelmää ei voi käyttää.';
$_['help_customer_group']           = 'Asiakkaan on oltava näissä asiakas ryhmissä, ennen kuin tämä maksu tapa aktivoituu. Jätä tyhjäksi, jos ei ole rajoitusta.';
$_['help_logging']                  = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulisi aina poistaa käytöstä, ellei toisin määrätä.';
$_['help_total']                    = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu. On oltava arvo, jolla ei ole valuutta merkkiä.';
$_['help_order_status_pending']     = 'Tila uksen tila asiakkaan tila uksen jälkeen.';
$_['help_order_status_canceled']    = 'Tila uksen tila asiakkaan tila uksen peruutuksen jälkeen.';
$_['help_order_status_processing']  = 'Tila uksen tila asiakkaan tila uksen jälkeen.';
$_['help_cron_url']                 = 'Aseta ajastettu tehtävä, jos haluat kutsua tätä URL-osoitetta niin, että raportit haetaan automaattisesti.';
$_['help_cron_time']                = 'Tämä on viimeinen kerta, kun cron-työn URL-osoite on suoritettu.';

// Error
$_['error_permission']              = 'Varoitus: sinulla ei ole lupaa muuttaa maksua myy-buy!';
$_['error_membership_id']           = 'Lay-Buy-jäsenyyden tunnus vaaditaan!';
$_['error_token']                   = 'Myy-Osta salainen Token tarvitaan!';
$_['error_min_deposit']             = 'Ei voi ylittää maksusi enimmäismäärää!';

// Button
$_['button_fetch']                  = 'Hakea';
$_['button_revise_plan']            = 'Suunnitelman tarkistaminen';
$_['button_cancel_plan']            = 'Peruuta suunnitelma';