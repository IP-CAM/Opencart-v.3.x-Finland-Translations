<?php
// Heading
$_['heading_title']         = 'Authorize.net (AIM)';

// Text
$_['text_extension']        = 'Tiedostopääte';
$_['text_success']          = 'Menestys: olet muuttanut Authorize.net (AIM) tili tiedot!';
$_['text_edit']             = 'Muokkaa Authorize.net (AIM)';
$_['text_test']             = 'Testi';
$_['text_live']             = 'Live';
$_['text_authorization']    = 'Lupa';
$_['text_capture']          = 'Kaapata';
$_['text_authorizenet_aim'] = '<a onclick="window.open(\'http://reseller.authorize.net/application/?id=5561142\');"><img src="view/image/payment/authorizenet.png" alt="Authorize.Net" title="Authorize.Net" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_login']           = 'Sisäänkirjautumistunnus';
$_['entry_key']             = 'Tapahtuman avain';
$_['entry_hash']            = 'MD5 hakata hienoksi';
$_['entry_server']          = 'Transaction Serverin';
$_['entry_mode']            = 'Tapahtuma tila';
$_['entry_method']          = 'Tapahtuman menetelmä';
$_['entry_total']           = 'Yhteensä';
$_['entry_order_status']    = 'Tila uksen tila';
$_['entry_geo_zone']        = 'Geo Zone';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

// Help
$_['help_total']            = 'Uloskuittaus tila uksen on oltava käytettävissä, ennen kuin tämä maksu tapa aktivoituu.';

// Error
$_['error_permission']      = 'Varoitus: sinulla ei ole oikeutta muokata maksu Authorize.net (SIM)!';
$_['error_login']           = 'Kirjautuminen ID vaaditaan!';
$_['error_key']             = 'Tapahtuma avain vaaditaan!';