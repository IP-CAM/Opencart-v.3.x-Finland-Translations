<?php
// Heading
$_['heading_title']					 = 'Yksinkertainen OTP-maksu';

// Text
$_['text_extension']				 = 'Tiedostopääte';
$_['text_success']					 = 'Menestys: olet muuttanut PayPal-tili tiedot!';
$_['text_edit']                      = 'Muokkaa yksinkertaista OTP-maksua';

$_['text_authorization']			 = 'Lupa';
$_['text_sale']						 = 'Myynti'; 

$_['text_all_stores'] = 'Kaikki myymälät';

$_['text_simple_otp_payment'] = '<img src="view/image/payment/simple_otp_payment.png"/>';

// Entry
$_['entry_email']					 = 'Sähköposti';
$_['entry_test']					 = 'Eristetty tila';
$_['entry_transaction']				 = 'Tapahtuman menetelmä';
$_['entry_total']					 = 'Yhteensä';

$_['entry_complete_status']		 = 'Valmis tila';
$_['entry_cancelled_status'] = 'Peruutettu-tila';
$_['entry_timeout_status'] = 'Aika katkaisun tila';
$_['entry_card_not_authorized_status'] = 'Kortti ei ole valtuutettu tila';
$_['entry_waiting_payment_status'] = 'Odottavan maksun tila';
$_['entry_payment_authorized_status'] = 'Maksun valtuutettu tila';
$_['entry_fraud_status'] = 'Petosten tila';
$_['entry_reversed_status'] = 'Palautettu tila';
$_['entry_refund_status'] = 'Hyvityksen tila';

$_['entry_api_key'] = 'API-avain';
$_['entry_api_user'] = 'API-käyttäjä';
$_['entry_store'] = 'Store';

$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Tila';
$_['entry_sort_order']				 = 'Lajittelujärjestyksen';

// AIRCode
$_['entry_merchant_currency']       = 'Kauppias valuutta';
$_['column_gateway_response'] = 'OTP-yhdyskäytävän vastaus';
$_['column_set_status'] = 'Määritä tila uksen tilaksi';

// Tab
$_['tab_general']					 = 'Yleiset ehdot';
$_['tab_order_status']       		 = 'Tila uksen tila';

// Help
$_['help_test']						 = 'Käytä Live-tai Testing (Sandbox)-yhdyskäytäväpalvelinta tapahtumien käsittelemiseen?';
$_['help_total']					 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';

// Error
$_['error_permission']				 = 'Varoitus: sinulla ei ole oikeutta muokata maksua yksinkertainen OTP maksu!';
$_['error_email']					 = 'E-Mail tarvitaan!';
$_['error_api_key'] = 'API avain tarvitaan!';
$_['error_api_user'] = 'API käyttäjä tarvitaan!';