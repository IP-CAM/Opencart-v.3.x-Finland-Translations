<?php
//Headings
$_['heading_title']                = 'Amazon pay';

// Text
$_['text_success']                 = 'Amazon Pay moduuli on päivitetty';
$_['text_ipn_url']				   = 'Cron Job URL';
$_['text_ipn_token']			   = 'Salainen tunnus';
$_['text_us']					   = 'Amerikkalainen';
$_['text_de']					   = 'saksa';
$_['text_uk']                      = 'englanti';
$_['text_fr']                      = 'ranska';
$_['text_it']                      = 'italia';
$_['text_es']                      = 'espanja';
$_['text_us_region']			   = 'Yhdysvallat';
$_['text_eu_region']               = 'Euro alueen';
$_['text_uk_region']               = 'Iso-Britannia';
$_['text_live']                    = 'Live';
$_['text_sandbox']                 = 'Hiekkalaatikko';
$_['text_auth']		           	   = 'Lupa';
$_['text_payment']		           = 'Maksu';
$_['text_extension']               = 'Tiedostopääte';
$_['text_account']                 = 'Tili';
$_['text_guest']				   = 'Guest';
$_['text_no_capture']              = '---Ei automaattista sieppausta---';
$_['text_all_geo_zones']           = 'Kaikki maantieteelliset vyöhykkeet';
$_['text_button_settings']         = 'Checkout-painikkeen asetukset';
$_['text_colour']                  = 'Väri';
$_['text_orange']                  = 'Oranssi';
$_['text_tan']                     = 'Tan';
$_['text_white']                   = 'Valkoinen';
$_['text_light']                   = 'Valo';
$_['text_dark']                    = 'Tumma';
$_['text_size']                    = 'Koko';
$_['text_medium']                  = 'Keskipitkällä';
$_['text_large']                   = 'Suuri';
$_['text_x_large']                 = 'Erittäin suuri';
$_['text_background']              = 'Tausta';
$_['text_edit']					   = 'Muokkaa Amazon pay';
$_['text_amazon_login_pay']        = '<a href="https://pay.amazon.com/uk/sp/opencart" target="_blank" title="Sign-up to Amazon Pay"><img src="view/image/payment/amazonpay.png" alt="Amazon Pay" title="Amazon Pay" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_amazon_join']             = '<a href="https://pay.amazon.com/uk/sp/opencart" target="_blank" title="Sign-up to Amazon Pay"><u>Rekisteröidy Amazon pay</u></a>';
$_['text_payment_info']			   = 'Maksu tiedot';
$_['text_capture_ok']			   = 'Capture onnistui';
$_['text_capture_ok_order']		   = 'Capture oli onnistunut, valtuutus on täysin kiinni';
$_['text_refund_ok']			   = 'Palautusta pyydettiin';
$_['text_refund_ok_order']		   = 'Hyvitys pyyntö onnistui, summa palautetaan kokonaan';
$_['text_cancel_ok']			   = 'Peruuttaminen onnistui, tila uksen tila päivitettiin peruutetuksi';
$_['text_capture_status']		   = 'Maksu otettu';
$_['text_cancel_status']		   = 'Maksu peruutettu';
$_['text_refund_status']		   = 'Maksu palautetaan';
$_['text_order_ref']			   = 'Tilaa REF';
$_['text_order_total']			   = 'Valtuutettu kokonaismäärä';
$_['text_total_captured']		   = 'Yhteensä kiinni';
$_['text_transactions']			   = 'Tapahtumat';
$_['text_column_authorization_id'] = 'Amazon lupa ID';
$_['text_column_capture_id']	   = 'Amazon kaapata ID';
$_['text_column_refund_id']		   = 'Amazon palautus tunnus';
$_['text_column_amount']		   = 'Summa';
$_['text_column_type']			   = 'Tyyppi';
$_['text_column_status']		   = 'Tila';
$_['text_column_date_added']	   = 'Päivä määrä lisätty';
$_['text_confirm_cancel']		   = 'Haluatko varmasti peruuttaa maksun?';
$_['text_confirm_capture']		   = 'Haluatko varmasti siepata maksun?';
$_['text_confirm_refund']		   = 'Haluatko varmasti palauttaa maksun?';
$_['text_minimum_total']           = 'Minimi tilaus yhteensä';
$_['text_geo_zone']                = 'Geo Zone';
$_['text_status']                  = 'Tila';
$_['text_declined_codes']          = 'Testaa hylkäävän koodin';
$_['text_sort_order']              = 'Lajittelujärjestyksen';
$_['text_amazon_invalid']          = 'Invalidi PaymentMethod';
$_['text_amazon_rejected']         = 'Amazonhylätty';
$_['text_amazon_timeout']          = 'Transactitimedout';
$_['text_amazon_no_declined']      = '---Ei automaattista hylättyä valtuutusta---';
$_['text_amazon_signup']		   = 'Rekisteröidy Amazon pay';
$_['text_credentials']			   = 'Ole hyvä ja liitä avaimet täällä (JSON-muodossa)';
$_['text_validate_credentials']	   = 'Vahvista ja käytä tunniste tietoja';

// Columns
$_['column_status']                = 'Tila';

//entry
$_['entry_merchant_id']            = 'Kauppias id';
$_['entry_access_key']             = 'Access-näppäin';
$_['entry_access_secret']          = 'Salainen avain';
$_['entry_client_id']              = 'Asiakas tunnus';
$_['entry_client_secret']          = 'Client Secret';
$_['entry_language']			   = 'Kieli';
$_['entry_login_pay_test']         = 'Testi tilassa';
$_['entry_login_pay_mode']         = 'Maksu tapa';
$_['entry_checkout']			   = 'Checkout-tila';
$_['entry_payment_region']		   = 'Maksu alueen';
$_['entry_capture_status']         = 'Automaattisen sieppauksen tila';
$_['entry_pending_status']         = 'Odottava tila uksen tila';
$_['entry_ipn_url']				   = 'IPN n URL';
$_['entry_ipn_token']			   = 'Salainen tunnus';
$_['entry_debug']				   = 'Virheen korjauksen kirjaaminen lokiin';

// Help
$_['help_pay_mode']				   = 'Maksu on saatavilla vain Yhdysvaltain markkinoilla';
$_['help_checkout']				   = 'Jos maksu painike myös kirjautunut asiakas';
$_['help_capture_status']		   = 'Valitse tilaa staus, joka käynnistää automaattisesti kaapata valtuutetun maksun';
$_['help_ipn_url']				   = 'Aseta tämä kun merhcant URL Amazon myyjä Keski';
$_['help_ipn_token']			   = 'Tee tämä pitkä ja vaikea arvata';
$_['help_minimum_total']		   = 'Tämän on oltava nollaa suurempi';
$_['help_debug']				   = 'Virheen korjauksen ottaminen käyttöön kirjoittaa luottamuksellisia tietoja loki tiedostoon. Sinun tulee aina poistaa käytöstä, ellei ohjeissa toisin mainita';
$_['help_declined_codes']		   = 'Tämä on testausta varten vain';

// Order Info
$_['tab_order_adjustment']         = 'Tila uksen oikaisu';

// Errors
$_['error_permission']             = 'Sinulla ei ole oikeuksia tämän moduulin muokkaamiseen';
$_['error_merchant_id']			   = 'Merchant ID vaaditaan';
$_['error_access_key']			   = 'Käyttö avain on pakollinen';
$_['error_access_secret']		   = 'Salainen avain on pakollinen';
$_['error_client_id']			   = 'Asiakas tunnus on pakollinen';
$_['error_client_secret']		   = 'Asiakkaan avain on pakollinen';
$_['error_pay_mode']			   = 'Maksu on saatavilla vain Yhdysvaltain markkinoilla';
$_['error_minimum_total']		   = 'Minimi tilaus summan on oltava nollaa suurempi';
$_['error_curreny']                = 'Shopissa on oltava %s valuutta asennettu ja käytössä';
$_['error_upload']                 = 'Lataus epäonnistui';
$_['error_data_missing'] 		   = 'Vaaditut tiedot puuttuvat';
$_['error_credentials'] 		   = 'Kirjoita avaimet voimassa JSON-muodossa';


// Buttons
$_['button_capture']			   = 'Kaapata';
$_['button_refund']				   = 'Palautusta';
$_['button_cancel']				   = 'Peruuta';
