<?php
// Heading
$_['heading_title']			   = 'Haku tapahtumat';

// Text
$_['text_pp_express']		   = 'PayPal Express Checkout';
$_['text_date_search']		   = 'Etsi päivä määrän mukaan';
$_['text_searching']		   = 'Etsiminen';
$_['text_name']				   = 'Nimi';
$_['text_buyer_info']		   = 'Ostajan tiedot';
$_['text_view']				   = 'Katso';
$_['text_format']			   = 'Muodossa';

// Column
$_['column_date']			   = 'Päivämäärä';
$_['column_type']			   = 'Tyyppi';
$_['column_email']			   = 'Sähköposti';
$_['column_name']			   = 'Nimi';
$_['column_transid']		   = 'Tapahtuman tunnus';
$_['column_status']			   = 'Tila';
$_['column_currency']		   = 'Valuutta';
$_['column_amount']			   = 'Summa';
$_['column_fee']			   = 'Maksu';
$_['column_netamt']		       = 'Netto summa';
$_['column_action']		       = 'Toiminta';

// Entry
$_['entry_trans_all']		   = 'Kaikki';
$_['entry_trans_sent']		   = 'Lähetti';
$_['entry_trans_received']     = 'Vastaanotettu';
$_['entry_trans_masspay']	   = 'Massa palkan';
$_['entry_trans_money_req']	   = 'Maksu pyyntö';
$_['entry_trans_funds_add']	   = 'Lisätyt varat';
$_['entry_trans_funds_with']   = 'Peruutetut varat';
$_['entry_trans_referral']	   = 'Asian';
$_['entry_trans_fee']		   = 'Maksu';
$_['entry_trans_subscription'] = 'Tilaus';
$_['entry_trans_dividend']     = 'Osinko';
$_['entry_trans_billpay']      = 'Bill Pay';
$_['entry_trans_refund']       = 'Palautusta';
$_['entry_trans_conv']         = 'Valuuttamuunnoksen';
$_['entry_trans_bal_trans']	   = 'Saldon siirron';
$_['entry_trans_reversal']	   = 'Kääntyminen';
$_['entry_trans_shipping']	   = 'Toimitus';
$_['entry_trans_bal_affect']   = 'Saldo, joka vaikuttaa';
$_['entry_trans_echeque']	   = 'E Tarkista';
$_['entry_date']			   = 'Päivämäärä';
$_['entry_date_start']		   = 'Aloittaa';
$_['entry_date_end']		   = 'Lopussa';
$_['entry_date_to']			   = 'jotta';
$_['entry_transaction']		   = 'Tapahtuman';
$_['entry_transaction_type']   = 'Tyyppi';
$_['entry_transaction_status'] = 'Tila';
$_['entry_email']			   = 'Sähköposti';
$_['entry_email_buyer']		   = 'Ostaja';
$_['entry_email_merchant']	   = 'Vastaanotin';
$_['entry_receipt']			   = 'Kuitin tunnus';
$_['entry_transaction_id']	   = 'Tapahtuman tunnus';
$_['entry_invoice_no']		   = 'Laskun numero';
$_['entry_auction']			   = 'Huuto kaupan nimike numero';
$_['entry_amount']			   = 'Summa';
$_['entry_recurring_id']	   = 'Toistuvan profiilin tunnus';
$_['entry_salutation']		   = 'Tervehdys';
$_['entry_firstname']		   = 'Ensimmäinen';
$_['entry_middlename']		   = 'Lähi';
$_['entry_lastname']		   = 'Viime';
$_['entry_suffix']			   = 'Liite';
$_['entry_status_all']		   = 'Kaikki';
$_['entry_status_pending']	   = 'Odottavat';
$_['entry_status_processing']  = 'Käsittely';
$_['entry_status_success']	   = 'Menestys';
$_['entry_status_denied']	   = 'Estetty';
$_['entry_status_reversed']	   = 'Käänteinen';