<?php
$_['heading_title']                              = 'Turvalliset kaupan käynti maksu sivut';

$_['text_securetrading_pp']                      = '<a href="http://www.securetradingfs.com/partner/open-cart/" target="_blank"><img src="view/image/payment/secure_trading.png" alt="Secure Trading" title="Secure Trading" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_extension']                             = 'Tiedostopääte';
$_['text_all_geo_zones']                         = 'Kaikki maantieteelliset vyöhykkeet';
$_['text_process_immediately']                   = 'Käsittele heti';
$_['text_wait_x_days']                           = 'Odota %d Päivää';
$_['text_success']                               = 'Menestys: sinulla on muutettu turvallinen kaupan käynnin moduuli!';
$_['text_pending_settlement']                    = 'Odottava tilitys';
$_['text_authorisation_reversed']                = 'Valtuutuksen peruttiin onnistuneesti';
$_['text_refund_issued']                         = 'Palautus onnistui';
$_['text_pending_settlement_manually_overriden'] = 'Odottava tilitys, manuaalisesti ohittaa';
$_['text_pending_suspended']                     = 'Keskeytetty';
$_['text_pending_settled']                       = 'Ratkaistu';

$_['entry_site_reference']                       = 'Sivuston viite';
$_['entry_username']                             = 'Käyttäjätunnus';
$_['entry_password']                             = 'Salasana';
$_['entry_site_security_status']                 = 'Sivuston suoja uksen hajautus arvon käyttäminen';
$_['entry_site_security_password']               = 'Sivuston suoja uksen sala sana';
$_['entry_notification_password']                = 'Ilmoituksen sala sana';
$_['entry_order_status']                         = 'Tila uksen tila';
$_['entry_declined_order_status']                = 'Hylätyn tila uksen tila';
$_['entry_refunded_order_status']                = 'Palautettu tila uksen tila';
$_['entry_authorisation_reversed_order_status']  = 'Myynti luvan peruutetun tila uksen tila';
$_['entry_settle_status']                        = 'Selvityksen tila';
$_['entry_settle_due_date']                      = 'Selvityksen eräpäivä';
$_['entry_geo_zone']                             = 'Geo Zone';
$_['entry_sort_order']                           = 'Lajittelujärjestyksen';
$_['entry_status']                               = 'Tila';
$_['entry_total']                                = 'Yhteensä';
$_['entry_parent_css']                           = 'Vanhempi CSS';
$_['entry_child_css']                            = 'Lapsi CSS';
$_['entry_cards_accepted']                       = 'Hyväksytyt kortit';
$_['entry_reverse_authorisation']                = 'Käänteinen valtuutus:';
$_['entry_refunded']                             = 'Palautetaan:';
$_['entry_refund']                               = 'Issue hyvitys (%s):';

$_['error_permission']                           = 'Sinulla ei ole oikeuksia tämän moduulin muokkaamiseen';
$_['error_site_reference']                       = 'Sivuston viite on pakollinen';
$_['error_notification_password']                = 'Ilmoitus sala sana on pakollinen';
$_['error_cards_accepted']                       = 'Hyväksytyt kortit vaaditaan';
$_['error_username']                             = 'Käyttäjä tunnus on pakollinen';
$_['error_password']                             = 'Sala sana on pakollinen';
$_['error_connection']                           = 'Ei voitu yhdistää turvallisen kaupan käynnin';
$_['error_data_missing']                         = 'Tiedot puuttuvat';

$_['help_username']                              = 'Sinun WebService käyttäjä tunnus';
$_['help_password']                              = 'Sinun WebService sala sana';
$_['help_refund']                                = 'Sisällytä desimaali pilkku ja summan desimaali osa';
$_['help_total']                                 = 'Kassalle yhteensä tila uksen on saavutettava ennen tämän maksu tavan aktivoituu';

$_['button_reverse_authorisation']               = 'Käänteinen valtuutus';
$_['button_refund']                              = 'Palautusta';


// Order page - payment tab
$_['text_payment_info']                          = 'Maksu tiedot';
$_['text_release_status']                        = 'Maksu julkaistu';
$_['text_void_status']                           = 'Käänteinen valtuutus';
$_['text_rebate_status']                         = 'Maksu kiihtyi';
$_['text_order_ref']                             = 'Tilaa REF';
$_['text_order_total']                           = 'Sallittu kokonaismäärä';
$_['text_total_released']                        = 'Yhteensä julkaistu';
$_['text_transactions']                          = 'Tapahtumat';
$_['text_column_amount']                         = 'Summa';
$_['text_column_type']                           = 'Tyyppi';
$_['text_column_created']                        = 'Luotu';
$_['text_release_ok']                            = 'Julkaisu onnistui';
$_['text_release_ok_order']                      = 'Julkaisu onnistui, tila uksen tila päivitettiin menestykseen-selvitetty';
$_['text_rebate_ok']                             = 'Osto hyvitys onnistui';
$_['text_rebate_ok_order']                       = 'Osto hyvitys onnistui, tila uksen tila päivitetty korko hyvityksen';
$_['text_void_ok']                               = 'Void onnistui, tila uksen tila päivitettiin mitätöidyksi';

$_['text_confirm_void']                          = 'Haluatko varmasti peruuttaa valtuutuksen?';
$_['text_confirm_release']                       = 'Haluatko varmasti vapauttaa maksun?';
$_['text_confirm_rebate']                        = 'Haluatko varmasti hyvityksen maksusi?';

$_['button_release']                             = 'Vapauttaa';
$_['button_rebate']                              = 'Osto hyvitys/hyvitys';
$_['button_void']                                = 'Käänteinen valtuutus';
