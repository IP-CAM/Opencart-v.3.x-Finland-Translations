<?php
// Heading
$_['heading_title']				= 'eway maksu';

// Text
$_['text_extension']			= 'Tiedostopääte';
$_['text_success']				= 'Menestys: olet muokannut eway yksityiskohtia!';
$_['text_edit']					= 'Muokkaa eway';
$_['text_eway']					= '<a target="_BLANK" href="http://www.eway.com.au/"><img src="view/image/payment/eway.png" alt="eWAY" title="eWAY" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorisation']		= 'Lupa';
$_['text_sale']					= 'Myynti';
$_['text_transparent']			= 'Läpinäkyvä uudelleenohjaus (maksu lomake päällä)';
$_['text_iframe']				= 'IFrame (maksu lomake ikkunassa)';

// Entry
$_['entry_paymode']				= 'Maksu tapa';
$_['entry_test']				= 'Testi tilassa';
$_['entry_order_status']		= 'Tila uksen tila';
$_['entry_order_status_refund'] = 'Palautettu tila uksen tila';
$_['entry_order_status_auth']	= 'Valtuutetun tila uksen tila';
$_['entry_order_status_fraud']	= 'Epäillyn petoksen tila uksen tila';
$_['entry_status']				= 'Tila';
$_['entry_username']			= 'eway API avain';
$_['entry_password']			= 'eway sala sana';
$_['entry_payment_type']		= 'Maksu tyyppi';
$_['entry_geo_zone']			= 'Geo Zone';
$_['entry_sort_order']			= 'Lajittelujärjestyksen';
$_['entry_transaction_method']	= 'Tapahtuman menetelmä';

// Error
$_['error_permission']			= 'Varoitus: sinulla ei ole oikeuksia muuttaa eway-maksu moduulia';
$_['error_username']			= 'eway API avain tarvitaan!';
$_['error_password']			= 'eway sala sana on pakollinen!';
$_['error_payment_type']		= 'Vähintään yksi maksu tyyppi vaaditaan!';

// Help hints
$_['help_testmode']				= 'Aseta arvoksi Kyllä, jos haluat käyttää eway-hiekka laatikkoa.';
$_['help_username']				= 'Eway API-avaimesi myeway-tililtäsi.';
$_['help_password']				= 'Sinun eway API tunnus sana polveutua sinun myeway arvo.';
$_['help_transaction_method']	= 'Valtuutus on saatavilla vain australialaisille pankeille';

// Order page - payment tab
$_['text_payment_info']			= 'Maksu tiedot';
$_['text_order_total']			= 'Sallittu kokonaismäärä';
$_['text_transactions']			= 'Tapahtumat';
$_['text_column_transactionid'] = 'eway-tapahtuman tunnus';
$_['text_column_amount']		= 'Summa';
$_['text_column_type']			= 'Tyyppi';
$_['text_column_created']		= 'Luotu';
$_['text_total_captured']		= 'Yhteensä kiinni';
$_['text_capture_status']		= 'Maksu otettu';
$_['text_void_status']			= 'Maksu mitätöity';
$_['text_refund_status']		= 'Maksu palautetaan';
$_['text_total_refunded']		= 'Hyvitetty summa';
$_['text_refund_success']		= 'Hyvitys onnistui!';
$_['text_capture_success']		= 'Capture onnistui!';
$_['text_refund_failed']		= 'Palautus epäonnistui: ';
$_['text_capture_failed']		= 'Sieppaus epäonnistui: ';
$_['text_unknown_failure']		= 'Virheellinen tilaus tai summa';

$_['text_confirm_capture']		= 'Haluatko varmasti siepata maksun?';
$_['text_confirm_release']		= 'Haluatko varmasti vapauttaa maksun?';
$_['text_confirm_refund']		= 'Haluatko varmasti palauttaa maksun?';

$_['text_empty_refund']			= 'Määritä palautettava summa';
$_['text_empty_capture']		= 'Kirjoita määrä kaapata';

$_['btn_refund']				= 'Palautusta';
$_['btn_capture']				= 'Kaapata';

// Validation Error codes
$_['text_card_message_V6000']	= 'Määrittämätön oikeellisuus tarkistus virhe';
$_['text_card_message_V6001'] 	= 'Virheellinen asiakkaan IP-';
$_['text_card_message_V6002'] 	= 'Virheellinen DeviceID';
$_['text_card_message_V6011'] 	= 'Virheellinen summa';
$_['text_card_message_V6012'] 	= 'Virheellinen laskun kuvaus';
$_['text_card_message_V6013'] 	= 'Virheellinen laskun numero';
$_['text_card_message_V6014'] 	= 'Virheellinen laskun viite';
$_['text_card_message_V6015'] 	= 'Virheellinen valuutta koodi';
$_['text_card_message_V6016'] 	= 'Maksu vaaditaan';
$_['text_card_message_V6017'] 	= 'Maksun valuutta koodi vaaditaan';
$_['text_card_message_V6018'] 	= 'Tuntematon maksu valuutan koodi';
$_['text_card_message_V6021'] 	= 'Kortin haltijan nimi vaaditaan';
$_['text_card_message_V6022'] 	= 'Kortin numero vaaditaan';
$_['text_card_message_V6023'] 	= 'CVN tarvitaan';
$_['text_card_message_V6031'] 	= 'Kortin numero ei kelpaa';
$_['text_card_message_V6032'] 	= 'Virheellinen CVN';
$_['text_card_message_V6033'] 	= 'Virheellinen vanhenemis päivä';
$_['text_card_message_V6034'] 	= 'Virheellinen seuranta kohteen numero';
$_['text_card_message_V6035'] 	= 'Virheellinen alkamis päivä';
$_['text_card_message_V6036'] 	= 'Virheellinen kuukausi';
$_['text_card_message_V6037'] 	= 'Virheellinen vuosi';
$_['text_card_message_V6040'] 	= 'Virheellinen tunnus sanoman asiakas tunnus';
$_['text_card_message_V6041'] 	= 'Asiakkaan vaatimat';
$_['text_card_message_V6042'] 	= 'Asiakkaan etunimi vaaditaan';
$_['text_card_message_V6043'] 	= 'Asiakkaan suku nimi vaaditaan';
$_['text_card_message_V6044'] 	= 'Asiakas maakoodi vaaditaan';
$_['text_card_message_V6045'] 	= 'Asiakkaan otsikko vaaditaan';
$_['text_card_message_V6046'] 	= 'Token asiakas tunnus vaaditaan';
$_['text_card_message_V6047'] 	= 'RedirectUrl tarvitaan';
$_['text_card_message_V6051'] 	= 'Virheellinen etunimi';
$_['text_card_message_V6052'] 	= 'Virheellinen suku nimi';
$_['text_card_message_V6053'] 	= 'Maakoodi ei kelpaa';
$_['text_card_message_V6054'] 	= 'Virheellinen Sähkö posti osoite';
$_['text_card_message_V6055'] 	= 'Puhelin ei kelpaa';
$_['text_card_message_V6056'] 	= 'Virheellinen matka Puhelin';
$_['text_card_message_V6057'] 	= 'Virheellinen Faksi';
$_['text_card_message_V6058'] 	= 'Virheellinen otsikko';
$_['text_card_message_V6059'] 	= 'Uudelleenohjauksen URL-osoite ei kelpaa';
$_['text_card_message_V6060'] 	= 'Uudelleenohjauksen URL-osoite ei kelpaa';
$_['text_card_message_V6061'] 	= 'Virheellinen viittaus';
$_['text_card_message_V6062'] 	= 'Virheellinen yrityksen nimi';
$_['text_card_message_V6063'] 	= 'Virheellinen työn kuvaus';
$_['text_card_message_V6064'] 	= 'Virheellinen Street1';
$_['text_card_message_V6065'] 	= 'Virheellinen Street2';
$_['text_card_message_V6066'] 	= 'Virheellinen kaupunki';
$_['text_card_message_V6067'] 	= 'Virheellinen tila';
$_['text_card_message_V6068'] 	= 'Virheellinen PostalCode';
$_['text_card_message_V6069'] 	= 'Virheellinen Sähkö posti osoite';
$_['text_card_message_V6070'] 	= 'Puhelin ei kelpaa';
$_['text_card_message_V6071'] 	= 'Virheellinen matka Puhelin';
$_['text_card_message_V6072'] 	= 'Virheellisiä kommentteja';
$_['text_card_message_V6073'] 	= 'Virheellinen Faksi';
$_['text_card_message_V6074'] 	= 'Virheellinen URL-osoite';
$_['text_card_message_V6075'] 	= 'Virheellinen toimitus osoitteen etunimi';
$_['text_card_message_V6076'] 	= 'Virheellinen toimitus osoitteen suku nimi';
$_['text_card_message_V6077'] 	= 'Virheellinen toimitus osoite Street1';
$_['text_card_message_V6078'] 	= 'Virheellinen toimitus osoite Street2';
$_['text_card_message_V6079'] 	= 'Virheellinen toimitus osoitteen paikka kunta';
$_['text_card_message_V6080'] 	= 'Virheellinen toimitus osoitteen tila';
$_['text_card_message_V6081'] 	= 'Virheellinen toimitus osoitteen posti numero';
$_['text_card_message_V6082'] 	= 'Virheellinen toimitus osoitteen Sähkö posti osoite';
$_['text_card_message_V6083'] 	= 'Virheellinen toimitus osoitteen Puhelin numero';
$_['text_card_message_V6084'] 	= 'Virheellinen toimitus osoitteen maa';
$_['text_card_message_V6091'] 	= 'Tuntematon maakoodi';
$_['text_card_message_V6100'] 	= 'Kortin nimi ei kelpaa';
$_['text_card_message_V6101'] 	= 'Virheellinen kortin vanhenemis kuukausi';
$_['text_card_message_V6102'] 	= 'Virheellinen kortin vanhenemis vuosi';
$_['text_card_message_V6103'] 	= 'Kortin aloitus kuukausi ei kelpaa';
$_['text_card_message_V6104'] 	= 'Kortin alkamis vuosi ei kelpaa';
$_['text_card_message_V6105'] 	= 'Virheellinen kortin myöntämis numero';
$_['text_card_message_V6106'] 	= 'Virheellinen kortti CVN';
$_['text_card_message_V6107'] 	= 'Virheellinen Accesscode';
$_['text_card_message_V6108'] 	= 'Virheellinen custovahostaddress';
$_['text_card_message_V6109'] 	= 'Virheellinen UserAgent';
$_['text_card_message_V6110'] 	= 'Kortin numero ei kelpaa';
$_['text_card_message_V6111'] 	= 'Luvaton API pääsy, tili ei PCI sertifioitu';
$_['text_card_message_V6112'] 	= 'Redundantti kortin tiedot muut kuin päättymis vuosi ja-kuukausi';
$_['text_card_message_V6113'] 	= 'Virheellinen palautus tapahtuma';
$_['text_card_message_V6114'] 	= 'Yhdyskäytävän vahvistus virhe';
$_['text_card_message_V6115'] 	= 'Virheellinen directrefunrequest-tapahtuma tunnus';
$_['text_card_message_V6116'] 	= 'Virheelliset kortti tiedot alkuperäisessä transaperid-kohteessa';
$_['text_card_message_V6124'] 	= 'Rivi nimikkeet eivät kelpaa. Rivi nimikkeet on annettu, mutta summat eivät vastaa totalsumount-kenttää';
$_['text_card_message_V6125'] 	= 'Valittua maksu lajia ei ole otettu käyttöön';
$_['text_card_message_V6126'] 	= 'Virheellinen salatun kortin numero, Sala uksen purkaminen epäonnistui';
$_['text_card_message_V6127'] 	= 'Virheellinen salattu CVN, Sala uksen purkaminen epäonnistui';
$_['text_card_message_V6128'] 	= 'Maksu lajin menetelmä ei kelpaa';
$_['text_card_message_V6129'] 	= 'Tapahtumaa ei ole hyväksytty sieppausta tai peruutusta varten';
$_['text_card_message_V6130'] 	= 'Yleinen asiakas tieto virhe';
$_['text_card_message_V6131'] 	= 'Yleinen lähetys tietojen virhe';
$_['text_card_message_V6132'] 	= 'Tapahtuma on jo täytetty tai mitätöity, toiminto ei ole sallittu';
$_['text_card_message_V6133'] 	= 'Checkout ei ole käytettävissä maksu tyypille';
$_['text_card_message_V6134'] 	= 'Virheellinen auth-tapahtuma tunnus sieppausta tai mitätöidylle';
$_['text_card_message_V6135'] 	= 'PayPal virheiden käsittely tuki';
$_['text_card_message_V6140'] 	= 'Kauppias tili on keskeytetty';
$_['text_card_message_V6141'] 	= 'Virheellinen PayPal-tilin tiedot tai API-allekirjoitus';
$_['text_card_message_V6142'] 	= 'Valtuuta ei käytettävissä pankki/sivu konttori';
$_['text_card_message_V6150'] 	= 'Virheellinen palautus summa';
$_['text_card_message_V6151'] 	= 'Alkuperäistä tapahtumaa suurempi hyvitys summa';
$_['text_card_message_D4406'] 	= 'Tuntematon virhe';
$_['text_card_message_S5010'] 	= 'Tuntematon virhe';