<?php
// Heading
$_['heading_title']      = 'Vaihtoehtoja';

// Text
$_['text_success']       = 'Menestys: olet muokannut vaihto ehtoja!';
$_['text_list']          = 'Vaihtoehto luettelo';
$_['text_add']           = 'Lisää vaihto ehto';
$_['text_edit']          = 'Muokkaa-vaihto ehto';
$_['text_choose']        = 'Valita';
$_['text_select']        = 'Valitse';
$_['text_radio']         = 'Radio';
$_['text_checkbox']      = 'Valintaruutu';
$_['text_input']         = 'Syöttää';
$_['text_text']          = 'Teksti';
$_['text_textarea']      = 'Textarea';
$_['text_file']          = 'Tiedosto';
$_['text_date']          = 'Päivämäärä';
$_['text_datetime']      = 'Päivämäärä &amp; Aika';
$_['text_time']          = 'Aika';
$_['text_option']        = 'Vaihtoehto';
$_['text_value']         = 'Asetuksen arvot';

// Column
$_['column_name']        = 'Vaihto ehdon nimi';
$_['column_sort_order']  = 'Lajittelujärjestyksen';
$_['column_action']      = 'Toiminta';

// Entry
$_['entry_name']         = 'Vaihto ehdon nimi';
$_['entry_type']         = 'Tyyppi';
$_['entry_option_value'] = 'Asetus arvon nimi';
$_['entry_image']        = 'Kuva';
$_['entry_sort_order']   = 'Lajittelujärjestyksen';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muokata asetuksia!';
$_['error_name']         = 'Vaihto ehdon nimen on oltava väliltä 1-128 merkkiä!';
$_['error_type']         = 'Varoitus: tarvitaan asetus arvoja!';
$_['error_option_value'] = 'Asetus arvon nimen on oltava väliltä 1-128 merkkiä!';
$_['error_product']      = 'Varoitus: tätä asetusta ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';