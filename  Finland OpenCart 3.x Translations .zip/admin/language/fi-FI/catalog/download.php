<?php
// Heading
$_['heading_title']     = 'Lataukset';

// Text
$_['text_success']      = 'Menestys: olet muokannut lataukset!';
$_['text_list']         = 'Lataa luettelo';
$_['text_add']          = 'Lisää lataus';
$_['text_edit']         = 'Muokkaa latausta';
$_['text_upload']       = 'Tiedoston lataaminen onnistui!';

// Column
$_['column_name']       = 'Lataa nimi';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Lataa nimi';
$_['entry_filename']    = 'Tiedostonimi';
$_['entry_mask']        = 'Naamio';

// Help
$_['help_filename']     = 'Voit ladata upload-painiketta tai käyttää FTP ladata ladata hakemistoon ja kirjoita tiedot alla.';
$_['help_mask']         = 'On suositeltavaa, että tiedosto nimi ja maski ovat erilaisia estää ihmisiä yrittää suoraan linkittää lataukset.';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata latauksia!';
$_['error_name']        = 'Lataus nimi on oltava välillä 3 ja 64 merkkiä!';
$_['error_upload']      = 'Upload tarvitaan!';
$_['error_filename']    = 'Tiedosto nimen on oltava välillä 3-128 merkkiä!';
$_['error_exists']      = 'Tiedostoa ei ole olemassa!';
$_['error_mask']        = 'Maskin on oltava välillä 3 ja 128 merkkiä!';
$_['error_filetype']    = 'Virheellinen tiedosto tyyppi!';
$_['error_product']     = 'Varoitus: tätä latausta ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';