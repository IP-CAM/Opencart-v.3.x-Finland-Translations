<?php
// Heading
$_['heading_title']     = 'Suodattimet';

// Text
$_['text_success']      = 'Menestys: olet muokannut suodattimet!';
$_['text_list']         = 'Suodata luettelo';
$_['text_add']          = 'Lisää suodatin';
$_['text_edit']         = 'Muokkaa suodatinta';
$_['text_group']        = 'Suodata ryhmä';
$_['text_value']        = 'Suodata arvot';

// Column
$_['column_group']      = 'Suodata ryhmä';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_group']       = 'Suodattimen ryhmän nimi';
$_['entry_name']        = 'Suodattimen nimi';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata suodattimia!';
$_['error_group']       = 'Suodatin ryhmän nimen on oltava väliltä 1-64 merkkiä!';
$_['error_name']        = 'Suodattimen nimen on oltava 1-64 merkkiä!';