<?php
// Heading
$_['heading_title']          = 'Määritteet';

// Text
$_['text_success']           = 'Menestys: olet muokannut määritteitä!';
$_['text_list']              = 'Määrite luettelo';
$_['text_add']               = 'Lisää määrite';
$_['text_edit']              = 'Muokkaa määritettä';

// Column
$_['column_name']            = 'Määritteen nimi';
$_['column_attribute_group'] = 'Määrite ryhmä';
$_['column_sort_order']      = 'Lajittelujärjestyksen';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_name']             = 'Määritteen nimi';
$_['entry_attribute_group']  = 'Määrite ryhmä';
$_['entry_sort_order']       = 'Lajittelujärjestyksen';

// Error
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeuksia muokata määritteitä!';
$_['error_attribute_group']  = 'Määrite ryhmä tarvitaan!';
$_['error_name']             = 'Määritteen nimen on oltava 1-64 merkkiä!';
$_['error_product']          = 'Varoitus: tätä määritettä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';