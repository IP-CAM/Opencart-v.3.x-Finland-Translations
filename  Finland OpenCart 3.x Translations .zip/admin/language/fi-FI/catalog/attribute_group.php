<?php
// Heading
$_['heading_title']     = 'Määrite ryhmät';

// Text
$_['text_success']      = 'Onnistui: olet muokannut määrite ryhmiä!';
$_['text_list']         = 'Määrite ryhmä luettelo';
$_['text_add']          = 'Lisää määrite ryhmä';
$_['text_edit']         = 'Muokkaa määrite ryhmää';

// Column
$_['column_name']       = 'Määrite ryhmän nimi';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Määrite ryhmän nimi';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata määrite ryhmiä!';
$_['error_name']        = 'Määrite ryhmän nimen on oltava väliltä 1-64 merkkiä!';
$_['error_attribute']   = 'Varoitus: tätä määrite ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty %s Määritteet!';
$_['error_product']     = 'Varoitus: tätä määrite ryhmää ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';