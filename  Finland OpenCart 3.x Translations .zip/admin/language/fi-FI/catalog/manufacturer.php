<?php
// Heading
$_['heading_title']     = 'Valmistajat';

// Text
$_['text_success']      = 'Menestys: olet muokannut valmistajia!';
$_['text_list']         = 'Valmistajan luettelo';
$_['text_add']          = 'Lisää valmistaja';
$_['text_edit']         = 'Muokkaa valmistajaa';
$_['text_default']      = 'Oletus';
$_['text_percent']      = 'Prosenttiosuus';
$_['text_amount']       = 'Kiinteä summa';
$_['text_keyword']      = 'Älä käytä väli lyöntejä, vaan korvata väli lyöntejä-ja varmista, että SEO URL on maailmanlaajuisesti ainutlaatuinen.';

// Column
$_['column_name']       = 'Valmistajan nimi';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Valmistajan nimi';
$_['entry_store']       = 'Tallentaa';
$_['entry_keyword']     = 'Avainsanan';
$_['entry_image']       = 'Kuva';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';
$_['entry_type']        = 'Tyyppi';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata valmistajia!';
$_['error_name']        = 'Valmistajan nimen on oltava väliltä 1-64 merkkiä!';
$_['error_keyword']     = 'SEO URL jo käytössä!';
$_['error_unique']      = 'SEO URL on ainutlaatuinen!';
$_['error_product']     = 'Varoitus: tätä valmistajaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';