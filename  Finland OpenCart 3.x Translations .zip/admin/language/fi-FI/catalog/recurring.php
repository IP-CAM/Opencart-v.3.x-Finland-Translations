<?php
// Heading
$_['heading_title']         = 'Toistuvat profiilit';

// Text
$_['text_success']          = 'Onnistui: olet muokannut toistuvia profiileja!';
$_['text_list']             = 'Toistuva profiili luettelo';
$_['text_add']              = 'Lisää toistuva profiili';
$_['text_edit']             = 'Muokkaa toistuvaa profiilia';
$_['text_day']              = 'Päivä';
$_['text_week']             = 'Viikolla';
$_['text_semi_month']       = 'Semi kuukausi';
$_['text_month']            = 'Kuukausi';
$_['text_year']             = 'Vuoden';
$_['text_recurring']        = '<p><i class="fa fa-info-circle"></i> Toistuvat summat lasketaan frekvenssin ja jaksojen mukaan.</p><p>Esimerkiksi jos käytät taajuus "viikko" ja sykli "2", niin käyttäjä laskutetaan 2 viikon välein.</p><p>Kesto on niiden kertojen määrä, jolloin käyttäjä suorittaa maksun, aseta arvoksi 0, jos haluat suorittaa maksut, kunnes ne peruutetaan.</p>';
$_['text_profile']          = 'Toistuva profiili';
$_['text_trial']            = 'Karsinta kilpailu leikkaus kuva';

// Entry
$_['entry_name']            = 'Nimi';
$_['entry_price']           = 'Hinta';
$_['entry_duration']        = 'Kesto';
$_['entry_cycle']           = 'Sykli';
$_['entry_frequency']       = 'Taajuus';
$_['entry_trial_price']     = 'Karsinta kilpailu hinta';
$_['entry_trial_duration']  = 'Kokeilu jakson kesto';
$_['entry_trial_status']    = 'Kokeilu version tila';
$_['entry_trial_cycle']     = 'Karsinta kilpailu ajan jakso';
$_['entry_trial_frequency'] = 'Karsinta kilpailu frekvenssi';
$_['entry_status']          = 'Tila';
$_['entry_sort_order']      = 'Lajittelujärjestyksen';

// Column
$_['column_name']           = 'Nimi';
$_['column_sort_order']     = 'Lajittelujärjestyksen';
$_['column_action']         = 'Toiminta';

// Error
$_['error_warning']         = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']      = 'Varoitus: sinulla ei ole oikeuksia muokata toistuvia profiileja!';
$_['error_name']            = 'Profiilin nimen on oltava suurempi kuin 3 ja pienempi kuin 255 merkkiä!';
$_['error_product']         = 'Varoitus: tätä toistuvaa profiilia ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';