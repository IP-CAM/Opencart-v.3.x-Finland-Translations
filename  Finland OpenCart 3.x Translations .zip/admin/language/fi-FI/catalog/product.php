<?php
// Heading
$_['heading_title']          = 'Tuotteet';

// Text
$_['text_success']           = 'Menestys: olet muokannut tuotteita!';
$_['text_list']              = 'Tuote luettelo';
$_['text_add']               = 'Lisää tuote';
$_['text_edit']              = 'Muokkaa tuotetta';
$_['text_filter']            = 'Suodatin';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'Oletus';
$_['text_option']            = 'Vaihtoehto';
$_['text_option_value']      = 'Vaihto ehdon arvo';
$_['text_percent']           = 'Prosenttiosuus';
$_['text_amount']            = 'Kiinteä summa';
$_['text_keyword']           = 'Älä käytä väli lyöntejä, vaan korvata väli lyöntejä-ja varmista, että SEO URL on maailmanlaajuisesti ainutlaatuinen.';

// Column
$_['column_name']            = 'Tuotteen nimi';
$_['column_model']           = 'Malli';
$_['column_image']           = 'Kuva';
$_['column_price']           = 'Hinta';
$_['column_quantity']        = 'Määrä';
$_['column_status']          = 'Tila';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_name']             = 'Tuotteen nimi';
$_['entry_description']      = 'Kuvaus';
$_['entry_meta_title']       = 'Metatunnisteen otsikko';
$_['entry_meta_keyword']     = 'Metakoodin avain sanat';
$_['entry_meta_description'] = 'Meta-tunnisteen kuvaus';
$_['entry_store']            = 'Tallentaa';
$_['entry_keyword']          = 'Avainsanan';
$_['entry_model']            = 'Malli';
$_['entry_sku']              = 'Sku';
$_['entry_upc']              = 'Upc';
$_['entry_ean']              = 'Ean';
$_['entry_jan']              = 'Tammikuu';
$_['entry_isbn']             = 'Isbn';
$_['entry_mpn']              = 'Mpn';
$_['entry_location']         = 'Sijainti';
$_['entry_shipping']         = 'Edellyttää toimitus';
$_['entry_manufacturer']     = 'Valmistaja';
$_['entry_date_available']   = 'Päivä määrä saatavilla';
$_['entry_quantity']         = 'Määrä';
$_['entry_minimum']          = 'Vähimmäismäärä';
$_['entry_stock_status']     = 'Loppu varastosta tila';
$_['entry_price']            = 'Hinta';
$_['entry_tax_class']        = 'Vero luokka';
$_['entry_points']           = 'Pistettä';
$_['entry_option_points']    = 'Pistettä';
$_['entry_subtract']         = 'Vähennä varasto';
$_['entry_weight_class']     = 'Paino luokka';
$_['entry_weight']           = 'Paino';
$_['entry_dimension']        = 'Mitat (p x l x k)';
$_['entry_length_class']     = 'Pituus luokka';
$_['entry_length']           = 'Pituus';
$_['entry_width']            = 'Leveys';
$_['entry_height']           = 'Korkeus';
$_['entry_image']            = 'Kuva';
$_['entry_additional_image'] = 'Muita kuvia';
$_['entry_customer_group']   = 'Asiakas ryhmä';
$_['entry_date_start']       = 'Alkamis päivä';
$_['entry_date_end']         = 'Päättymis päivä';
$_['entry_priority']         = 'Ensisijainen';
$_['entry_attribute']        = 'Määrite';
$_['entry_attribute_group']  = 'Määrite ryhmä';
$_['entry_text']             = 'Teksti';
$_['entry_option']           = 'Vaihtoehto';
$_['entry_option_value']     = 'Vaihto ehdon arvo';
$_['entry_required']         = 'Tarvitaan';
$_['entry_status']           = 'Tila';
$_['entry_sort_order']       = 'Lajittelujärjestyksen';
$_['entry_category']         = 'Luokat';
$_['entry_filter']           = 'Suodattimet';
$_['entry_download']         = 'Lataukset';
$_['entry_related']          = 'Aiheeseen liittyvät tuotteet';
$_['entry_tag']              = 'Tuote Tunnisteet';
$_['entry_reward']           = 'Palkintopisteitä';
$_['entry_layout']           = 'Asettelun ohitus';
$_['entry_recurring']        = 'Toistuva profiili';

// Help
$_['help_sku']               = 'Varasto säilö yksikkö';
$_['help_upc']               = 'Universal tuote koodi';
$_['help_ean']               = 'Eurooppalainen tuote numero';
$_['help_jan']               = 'Japanin tuote numero';
$_['help_isbn']              = 'Kansainvälinen standardi kirja numero';
$_['help_mpn']               = 'Valmistajan osanumero';
$_['help_manufacturer']      = 'AUtomaattinen täydennys';
$_['help_minimum']           = 'Pakota pienin tilattu summa';
$_['help_stock_status']      = 'Tila, joka näkyy, kun tuote on loppu';
$_['help_points']            = 'Tämän kohteen ostamiseen tarvittava määrä pisteitä. Jos et halua, että tämä tuote ostetaan pisteillä, jätä arvoksi 0.';
$_['help_category']          = 'AUtomaattinen täydennys';
$_['help_filter']            = 'AUtomaattinen täydennys';
$_['help_download']          = 'AUtomaattinen täydennys';
$_['help_related']           = 'AUtomaattinen täydennys';
$_['help_tag']               = 'Pilkulla erotettuna';

// Error
$_['error_warning']          = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeutta muokata tuotteita!';
$_['error_name']             = 'Tuotteen nimen on oltava suurempi kuin 1 ja pienempi kuin 255 merkkiä!';
$_['error_meta_title']       = 'Meta otsikko on suurempi kuin 1 ja alle 255 merkkiä!';
$_['error_model']            = 'Tuote mallin on oltava suurempi kuin 1 ja pienempi kuin 64 merkkiä!';
$_['error_keyword']          = 'SEO URL jo käytössä!';
$_['error_unique']           = 'SEO URL on ainutlaatuinen!';