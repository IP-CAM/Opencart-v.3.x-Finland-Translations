<?php
// Heading
$_['heading_title']          = 'Huoneesta';

// Text
$_['text_success']           = 'Menestys: olet muuttanut tietoja!';
$_['text_list']              = 'Tieto luettelo';
$_['text_add']               = 'Lisää tietoja';
$_['text_edit']              = 'Muokkaa tietoja';
$_['text_default']           = 'Oletus';
$_['text_keyword']           = 'Älä käytä väli lyöntejä, vaan korvata väli lyöntejä-ja varmista, että SEO URL on maailmanlaajuisesti ainutlaatuinen.';

// Column
$_['column_title']           = 'Tietojen otsikko';
$_['column_sort_order']      = 'Lajittelujärjestyksen';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_title']            = 'Tietojen otsikko';
$_['entry_description']      = 'Kuvaus';
$_['entry_meta_title']       = 'Metatunnisteen otsikko';
$_['entry_meta_keyword']     = 'Metakoodin avain sanat';
$_['entry_meta_description'] = 'Meta-tunnisteen kuvaus';
$_['entry_store']            = 'Tallentaa';
$_['entry_keyword']          = 'Avainsanan';
$_['entry_bottom']           = 'Pohja';
$_['entry_status']           = 'Tila';
$_['entry_sort_order']       = 'Lajittelujärjestyksen';
$_['entry_layout']           = 'Asettelun ohitus';

// Help
$_['help_bottom']            = 'Näytä alatunnisteessa.';

// Error
$_['error_warning']          = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeutta muokata tietoja!';
$_['error_title']            = 'Tiedon otsikon on oltava väliltä 1-64 merkkiä!';
$_['error_description']      = 'Kuva uksen on oltava enemmän kuin 3 merkkiä!';
$_['error_meta_title']       = 'Meta otsikko on suurempi kuin 1 ja alle 255 merkkiä!';
$_['error_keyword']          = 'SEO URL jo käytössä!';
$_['error_unique']           = 'SEO URL on ainutlaatuinen!';
$_['error_account']          = 'Varoitus: tätä tieto sivua ei voi poistaa, koska se on tällä hetkellä määritetty myymälän tilin termiksi!';
$_['error_checkout']         = 'Varoitus: tätä tieto sivua ei voi poistaa, koska se on tällä hetkellä määritetty myymälän uloskuittaustermiksi!';
$_['error_affiliate']        = 'Varoitus: tätä tieto sivua ei voi poistaa, koska se on tällä hetkellä määritetty myymälän kumppani termein!';
$_['error_return']           = 'Varoitus: tätä tieto sivua ei voi poistaa, koska se on tällä hetkellä määritetty myymälän palautus ehdiksi!';
$_['error_store']            = 'Varoitus: tätä tieto sivua ei voi poistaa, koska se on tällä hetkellä käytössä %s Tallentaa!';