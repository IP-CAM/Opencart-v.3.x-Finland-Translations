<?php
// Heading
$_['heading_title']     = 'Arvion perusteella';

// Text
$_['text_success']      = 'Menestys: olet muokannut arvostelut!';
$_['text_list']         = 'Tarkista luettelo';
$_['text_add']          = 'Lisää arvostelu';
$_['text_edit']         = 'Muokkaa tarkistusta';
$_['text_filter']       = 'Suodatin';

// Column
$_['column_product']    = 'Tuotteen';
$_['column_author']     = 'Kirjoittaja';
$_['column_rating']     = 'Arvostelun';
$_['column_status']     = 'Tila';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_product']     = 'Tuotteen';
$_['entry_author']      = 'Kirjoittaja';
$_['entry_rating']      = 'Arvostelun';
$_['entry_status']      = 'Tila';
$_['entry_text']        = 'Teksti';
$_['entry_date_added']  = 'Päivä määrä lisätty';

// Help
$_['help_product']      = 'AUtomaattinen täydennys';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata arvosteluja!';
$_['error_product']     = 'Tuote tarvitaan!';
$_['error_author']      = 'Kirjoittaja on välillä 3 ja 64 merkkiä!';
$_['error_text']        = 'Review teksti on oltava vähintään 1 merkki!';
$_['error_rating']      = 'Review Luokitus tarvitaan!';