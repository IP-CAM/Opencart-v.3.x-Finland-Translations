<?php
// Heading
$_['heading_title']          = 'Luokat';

// Text
$_['text_success']           = 'Menestys: olet muokannut Kategoriat!';
$_['text_list']              = 'Luokka List';
$_['text_add']               = 'Lisää kategoria';
$_['text_edit']              = 'Muokkaa luokkaa';
$_['text_default']           = 'Oletus';
$_['text_keyword']           = 'Älä käytä väli lyöntejä, vaan korvata väli lyöntejä-ja varmista, että SEO URL on maailmanlaajuisesti ainutlaatuinen.';

// Column
$_['column_name']            = 'Luokan nimi';
$_['column_sort_order']      = 'Lajittelujärjestyksen';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_name']             = 'Luokan nimi';
$_['entry_description']      = 'Kuvaus';
$_['entry_meta_title'] 	     = 'Metatunnisteen otsikko';
$_['entry_meta_keyword']     = 'Metakoodin avain sanat';
$_['entry_meta_description'] = 'Meta-tunnisteen kuvaus';
$_['entry_store']            = 'Tallentaa';
$_['entry_keyword']          = 'Avainsanan';
$_['entry_parent']           = 'Vanhempi';
$_['entry_filter']           = 'Suodattimet';
$_['entry_image']            = 'Kuva';
$_['entry_top']              = 'Top';
$_['entry_column']           = 'Sarakkeet';
$_['entry_sort_order']       = 'Lajittelujärjestyksen';
$_['entry_status']           = 'Tila';
$_['entry_layout']           = 'Asettelun ohitus';

// Help
$_['help_filter']            = 'AUtomaattinen täydennys';
$_['help_top']               = 'Näkyy ylävalikkopalkissa. Ainoa tehdas ajaksi ylin isä kategoria.';
$_['help_column']            = 'Alimmille 3-luokille käytettävä sarake määrä. Ainoa tehdas ajaksi ylin isä kategoria.';

// Error
$_['error_warning']          = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeutta muokata luokkia!';
$_['error_name']             = 'Luokan nimen on oltava väliltä 1-255 merkkiä!';
$_['error_meta_title']       = 'Meta otsikko on suurempi kuin 1 ja alle 255 merkkiä!';
$_['error_keyword']          = 'SEO URL jo käytössä!';
$_['error_unique']           = 'SEO URL on ainutlaatuinen!';
$_['error_parent']           = 'Pääluokan olet valinnut on lapsi nykyisen!';