<?php
// Heading
$_['heading_title']           = 'Maissa';

// Text
$_['text_success']            = 'Menestys: olet muuttanut maita!';
$_['text_list']               = 'Maaluettelo';
$_['text_add']                = 'Lisää maa';
$_['text_edit']               = 'Muokkaa maata';

// Column
$_['column_name']             = 'Maan nimi';
$_['column_iso_code_2']       = 'ISO-koodi (2)';
$_['column_iso_code_3']       = 'ISO-koodi (3)';
$_['column_action']           = 'Toiminta';

// Entry
$_['entry_name']              = 'Maan nimi';
$_['entry_iso_code_2']        = 'ISO-koodi (2)';
$_['entry_iso_code_3']        = 'ISO-koodi (3)';
$_['entry_address_format']    = 'Osoitteen muoto';
$_['entry_postcode_required'] = 'Posti numero vaaditaan';
$_['entry_status']            = 'Tila';

// Help
$_['help_address_format']     = 'Etunimi = {firstname}<br />Suku nimi = {lastname}<br />Company = {company}<br />Osoite 1 = {address_1}<br />Osoite 2 = {address_2}<br />City = {city}<br />Posti numero = {postcode}<br />Zone = {zone}<br />Zone Code = {zone_code}<br />Maa = {country}';

// Error
$_['error_permission']        = 'Varoitus: sinulla ei ole lupaa muokata maita!';
$_['error_name']              = 'Maan nimen on oltava väliltä 1-128 merkkiä!';
$_['error_default']           = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty oletusarvoiseksi tallennus maaksi.';
$_['error_store']             = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_address']           = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty %s Osoite kirja Entries!';
$_['error_affiliate']         = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty %s Tytäryhtiöiden!';
$_['error_zone']              = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty %s Alueet!';
$_['error_zone_to_geo_zone']  = 'Varoitus: tätä maata ei voi poistaa, koska se on tällä hetkellä määritetty %s vyöhykkeet Geo alueilla!';