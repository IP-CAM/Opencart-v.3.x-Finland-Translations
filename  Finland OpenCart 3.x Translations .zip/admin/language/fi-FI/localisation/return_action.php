<?php
// Heading
$_['heading_title']    = 'Palautus toimenpiteet';

// Text
$_['text_success']     = 'Onnistui: olet muokannut palautus toimia!';
$_['text_list']        = 'Palautuksen toimenpide luettelo';
$_['text_add']         = 'Lisää palautus toiminto';
$_['text_edit']        = 'Muokkaa palautus toimenpidettä';

// Column
$_['column_name']      = 'Palautus toiminnon nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Palautus toiminnon nimi';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata palautus toimintoja!';
$_['error_name']       = 'Palautus toiminnon nimen on oltava välillä 3-64 merkkiä!';
$_['error_return']     = 'Varoitus: tätä palautus toimintoa ei voi poistaa, koska se on tällä hetkellä määritetty %s palautetut tuotteet!';