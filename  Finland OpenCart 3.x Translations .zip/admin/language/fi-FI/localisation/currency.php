<?php
// Heading
$_['heading_title']        = 'Valuutat';

// Text
$_['text_success']         = 'Menestys: olet muuttanut valuuttoja!';
$_['text_list']            = 'Valuutta luettelo';
$_['text_add']             = 'Lisää valuutta';
$_['text_edit']            = 'Muokkaa valuuttaa';
$_['text_iso']             = 'Täydellisen iso-valuutta koodien ja-asetusten luettelo löytyy <a href="http://www.xe.com/iso4217.php" target="_blank" class="alert-link">Täällä</a>.';

// Column
$_['column_title']         = 'Valuutan nimi';
$_['column_code']          = 'Koodi';
$_['column_value']         = 'Arvo';
$_['column_date_modified'] = 'Päivitetty';
$_['column_action']        = 'Toiminta';

// Entry
$_['entry_title']          = 'Valuutan nimi';
$_['entry_code']           = 'Koodi';
$_['entry_value']          = 'Arvo';
$_['entry_symbol_left']    = 'Symboli vasemmalle';
$_['entry_symbol_right']   = 'Symboli oikea';
$_['entry_decimal_place']  = 'Desimaalin';
$_['entry_status']         = 'Tila';

// Help
$_['help_code']            = 'Älä muuta, jos tämä on oletus valuutta.';
$_['help_value']           = 'Aseta arvoksi 1,00000, jos tämä on oletus valuutta.';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole oikeuksia muuttaa valuuttoja!';
$_['error_title']          = 'Valuutta nimi on oltava välillä 3 ja 32 merkkiä!';
$_['error_code']           = 'Valuutta koodissa on oltava kolme merkkiä!';
$_['error_default']        = 'Varoitus: tätä valuuttaa ei voi poistaa, koska se on tällä hetkellä määritetty oletus tallennus valuutaksi.';
$_['error_store']          = 'Varoitus: tätä valuuttaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_order']          = 'Varoitus: tätä valuuttaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tilaukset!';