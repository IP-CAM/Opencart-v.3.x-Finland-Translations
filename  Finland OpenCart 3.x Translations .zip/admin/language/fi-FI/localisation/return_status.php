<?php
// Heading
$_['heading_title']    = 'Palautuksen tilat';

// Text
$_['text_success']     = 'Onnistui: olet muokannut palautus tiloja.';
$_['text_list']        = 'Palautuksen tila luettelo';
$_['text_add']         = 'Lisää palautuksen tila';
$_['text_edit']        = 'Muokkaa palautuksen tilaa';

// Column
$_['column_name']      = 'Palautuksen tilan nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Palautuksen tilan nimi';

// Error
$_['error_permission'] = 'Varoitus: oikeutesi eivät riitä palautus tilojen muokkaamiseen.';
$_['error_name']       = 'Palautus tilan nimen on oltava välillä 3-32 merkkiä!';
$_['error_default']    = 'Varoitus: tätä palautus tilaa ei voi poistaa, koska se on määritetty oletus palautus tilaksi.';
$_['error_return']     = 'Varoitus: tätä palautus tilaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Palauttaa!';