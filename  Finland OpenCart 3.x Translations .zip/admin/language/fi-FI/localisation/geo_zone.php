<?php
// Heading
$_['heading_title']      = 'Geo vyöhykkeet';

// Text
$_['text_success']       = 'Menestys: olet muuttanut Geo Zones!';
$_['text_list']          = 'Geo vyöhyke luettelo';
$_['text_add']           = 'Lisää Geo-vyöhyke';
$_['text_edit']          = 'Muokkaa Geo-vyöhykettä';
$_['text_geo_zone']      = 'Geo vyöhykkeet';

// Column
$_['column_name']        = 'Geo-vyöhykkeen nimi';
$_['column_description'] = 'Kuvaus';
$_['column_action']      = 'Toiminta';

// Entry
$_['entry_name']         = 'Geo-vyöhykkeen nimi';
$_['entry_description']  = 'Kuvaus';
$_['entry_country']      = 'Maa';
$_['entry_zone']         = 'Alue';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muokata Geo vyöhykkeitä!';
$_['error_name']         = 'Geo-vyöhykkeen nimen on oltava välillä 3-32 merkkiä!';
$_['error_description']  = 'Kuvaus nimen on oltava välillä 3-255 merkkiä!';
$_['error_tax_rate']     = 'Varoitus: tätä Geo-vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty yhteen tai useampaan vero prosenteille!';