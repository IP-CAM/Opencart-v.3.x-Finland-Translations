<?php
// Heading
$_['heading_title']          = 'Alueet';

// Text
$_['text_success']           = 'Menestys: olet muokannut vyöhykkeitä!';
$_['text_list']              = 'Vyöhyke luettelo';
$_['text_add']               = 'Lisää vyöhyke';
$_['text_edit']              = 'Muokkaa vyöhykettä';

// Column
$_['column_name']            = 'Vyöhykkeen nimi';
$_['column_code']            = 'Alueen koodi';
$_['column_country']         = 'Maa';
$_['column_action']          = 'Toiminta';

// Entry
$_['entry_name']             = 'Vyöhykkeen nimi';
$_['entry_code']             = 'Alueen koodi';
$_['entry_country']          = 'Maa';
$_['entry_status']           = 'Tila';

// Error
$_['error_permission']       = 'Varoitus: sinulla ei ole oikeuksia muuttaa vyöhykkeitä!';
$_['error_name']             = 'Vyöhykkeen nimen on oltava 1-128 merkkiä!';
$_['error_default']          = 'Varoitus: tätä vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty oletusarvoiseksi säilö vyöhykkeeksi!';
$_['error_store']            = 'Varoitus: tätä vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_address']          = 'Varoitus: tätä vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty %s Osoite kirja Entries!';
$_['error_affiliate']        = 'Varoitus: tätä vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tytäryhtiöiden!';
$_['error_zone_to_geo_zone'] = 'Varoitus: tätä vyöhykettä ei voi poistaa, koska se on tällä hetkellä määritetty %s vyöhykkeet Geo alueilla!';