<?php
// Heading
$_['heading_title']    = 'Pituus Luokat';

// Text
$_['text_success']     = 'Menestys: olet muokannut pituus luokkia!';
$_['text_list']        = 'Pituus luokka luettelo';
$_['text_add']         = 'Lisää pituus luokka';
$_['text_edit']        = 'Muokkaa pituus luokkaa';

// Column
$_['column_title']     = 'Pituus otsikko';
$_['column_unit']      = 'Pituus yksikkö';
$_['column_value']     = 'Arvo';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_title']      = 'Pituus otsikko';
$_['entry_unit']       = 'Pituus yksikkö';
$_['entry_value']      = 'Arvo';

// Help
$_['help_value']       = 'Aseta 1,00000, jos tämä on oletus pituus.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata pituus luokkia!';
$_['error_title']      = 'Pituus otsikko on välillä 3 ja 32 merkkiä!';
$_['error_unit']       = 'Pituus yksikön on oltava välillä 1 ja 4 merkkiä!';
$_['error_default']    = 'Varoitus: tätä pituus luokkaa ei voi poistaa, koska se on määritetty oletus säilön pituus luokituksella!';
$_['error_product']    = 'Varoitus: tätä pituus luokkaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';