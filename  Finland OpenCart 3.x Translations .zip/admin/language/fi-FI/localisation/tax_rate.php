<?php
// Heading
$_['heading_title']        = 'Vero kannat';

// Text
$_['text_success']         = 'Menestys: olet muuttanut vero kantoja!';
$_['text_list']            = 'Vero kannan luettelo';
$_['text_add']             = 'Lisää vero prosentti';
$_['text_edit']            = 'Muokkaa vero kantaa';
$_['text_percent']         = 'Prosenttiosuus';
$_['text_amount']          = 'Kiinteä summa';

// Column
$_['column_name']          = 'Veron nimi';
$_['column_rate']          = 'Vero prosentti';
$_['column_type']          = 'Tyyppi';
$_['column_geo_zone']      = 'Geo Zone';
$_['column_date_added']    = 'Päivä määrä lisätty';
$_['column_date_modified'] = 'Muokkaus päivämäärä';
$_['column_action']        = 'Toiminta';

// Entry
$_['entry_name']           = 'Veron nimi';
$_['entry_rate']           = 'Vero prosentti';
$_['entry_type']           = 'Tyyppi';
$_['entry_customer_group'] = 'Asiakas ryhmä';
$_['entry_geo_zone']       = 'Geo Zone';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole oikeutta muuttaa vero kantoja!';
$_['error_tax_rule']       = 'Varoitus: tätä vero kantaa ei voi poistaa, koska se on tällä hetkellä määritetty %s vero luokkia!';
$_['error_name']           = 'Vero nimen on oltava välillä 3 ja 32 merkkiä!';
$_['error_rate']           = 'Vero prosentti vaaditaan!';