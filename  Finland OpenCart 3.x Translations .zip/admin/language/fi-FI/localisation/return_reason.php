<?php
// Heading
$_['heading_title']    = 'Palautuksen syyt';

// Text
$_['text_success']     = 'Menestys: olet muuttanut paluu syistä!';
$_['text_list']        = 'Palautuksen syy-luettelo';
$_['text_add']         = 'Lisää palautuksen syy';
$_['text_edit']        = 'Muokkaa palautuksen syytä';

// Column
$_['column_name']      = 'Palautuksen syyn nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Palautuksen syyn nimi';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata palautuksen syitä!';
$_['error_name']       = 'Palautuksen syyn nimen on oltava välillä 3-128 merkkiä!';
$_['error_return']     = 'Varoitus: tätä palautus syytä ei voi poistaa, koska se on tällä hetkellä määritetty %s palautetut tuotteet!';