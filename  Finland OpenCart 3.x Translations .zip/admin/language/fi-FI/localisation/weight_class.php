<?php
// Heading
$_['heading_title']    = 'Paino Luokat';

// Text
$_['text_success']     = 'Menestys: olet muuttanut paino luokkia!';
$_['text_list']        = 'Paino luokka luettelo';
$_['text_add']         = 'Lisää paino luokka';
$_['text_edit']        = 'Muokkaa paino luokkaa';

// Column
$_['column_title']     = 'Paino arvo';
$_['column_unit']      = 'Paino yksikkö';
$_['column_value']     = 'Arvo';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_title']      = 'Paino arvo';
$_['entry_unit']       = 'Paino yksikkö';
$_['entry_value']      = 'Arvo';

// Help
$_['help_value']       = 'Aseta 1,00000, jos tämä on oletus paino.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata paino luokkia!';
$_['error_title']      = 'Paino otsikko on välillä 3 ja 32 merkkiä!';
$_['error_unit']       = 'Paino yksikön on oltava 1-4 merkkiä pitkä!';
$_['error_default']    = 'Varoitus: tätä paino luokkaa ei voi poistaa, koska se on tällä hetkellä määritetty oletusarvoiseksi säilön paino luokituksella!';
$_['error_product']    = 'Varoitus: tätä paino luokkaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';