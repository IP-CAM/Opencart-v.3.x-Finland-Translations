<?php
// Heading
$_['heading_title']     = 'Kielet';

// Text
$_['text_success']      = 'Menestys: olet muokannut kieliä!';
$_['text_list']         = 'Kieli luettelo';
$_['text_add']          = 'Lisää kieli';
$_['text_edit']         = 'Muokkaa kieltä';

// Column
$_['column_name']       = 'Kielen nimi';
$_['column_code']       = 'Koodi';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Kielen nimi';
$_['entry_code']        = 'Koodi';
$_['entry_locale']      = 'Locale';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Help
$_['help_locale']       = 'Esimerkki: en_US. UTF-8, en_US, en-GB, en_GB, englanti';
$_['help_status']       = 'Piilota/Näytä se kieli avattavasta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata kieliä!';
$_['error_exists']      = 'Varoitus: olet lisännyt ennen kieltä!';
$_['error_name']        = 'Kielen nimen on oltava välillä 3-32 merkkiä!';
$_['error_code']        = 'Kieli koodissa on oltava vähintään kaksi merkkiä!';
$_['error_locale']      = 'Locale tarvitaan!';
$_['error_default']     = 'Varoitus: tätä kieltä ei voi poistaa, koska se on tällä hetkellä määritetty oletus tallennus kieleksi.';
$_['error_admin']       = 'Varoitus: tätä kieltä ei voi poistaa, koska se on tällä hetkellä määritetty järjestelmänvalvojan kieleksi.';
$_['error_store']       = 'Varoitus: tätä kieltä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_order']       = 'Varoitus: tätä kieltä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tilaukset!';