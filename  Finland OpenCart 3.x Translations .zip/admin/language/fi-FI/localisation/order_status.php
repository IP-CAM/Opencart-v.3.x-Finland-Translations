<?php
// Heading
$_['heading_title']    = 'Tila uksen tilat';

// Text
$_['text_success']     = 'Onnistui: olet muokannut tila uksen tiloja!';
$_['text_list']        = 'Tila uksen tila-luettelo';
$_['text_add']         = 'Lisää tila uksen tila';
$_['text_edit']        = 'Muokkaa tila uksen tilaa';

// Column
$_['column_name']      = 'Tila uksen tilan nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Tila uksen tilan nimi';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata tila uksen tiloja!';
$_['error_name']       = 'Tila uksen tilan nimen on oltava välillä 3-32 merkkiä!';
$_['error_default']    = 'Varoitus: tätä tila uksen tilaa ei voi poistaa, koska se on tällä hetkellä määritetty oletusarvoiseksi säilö tilauksen tilaksi!';
$_['error_download']   = 'Varoitus: tätä tila uksen tilaa ei voi poistaa, koska se on määritetty oletus lataus tilaksi.';
$_['error_store']      = 'Varoitus: tätä tila uksen tilaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_order']      = 'Varoitus: tätä tila uksen tilaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tilaukset!';