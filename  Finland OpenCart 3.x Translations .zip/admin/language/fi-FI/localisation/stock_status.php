<?php
// Heading
$_['heading_title']    = 'Varaston tilat';

// Text
$_['text_success']     = 'Onnistui: olet muokannut varasto tiloja!';
$_['text_list']        = 'Varaston tila-luettelo';
$_['text_add']         = 'Lisää varaston tila';
$_['text_edit']        = 'Muokkaa varaston tilaa';

// Column
$_['column_name']      = 'Varaston tilan nimi';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Varaston tilan nimi';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata varaston tiloja!';
$_['error_name']       = 'Varasto tilan nimen on oltava välillä 3-32 merkkiä!';
$_['error_product']    = 'Varoitus: tätä varasto tilaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';