<?php
// Heading
$_['heading_title']    = 'Myymälän sijainnit';

// Text
$_['text_success']     = 'Onnistui: olet muokannut myymälän sijainteja!';
$_['text_list']        = 'Säilön sijainti luettelo';
$_['text_add']         = 'Lisää Säilön sijainti';
$_['text_edit']        = 'Muokkaa säilön sijaintia';
$_['text_default']     = 'Oletus';
$_['text_time']        = 'Aukioloajat';
$_['text_geocode']     = 'Geocode ei onnistunut seuraavasta syystä:';

// Column
$_['column_name']      = 'Myymälän nimi';
$_['column_address']   = 'Osoite';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_name']       = 'Myymälän nimi';
$_['entry_address']    = 'Osoite';
$_['entry_geocode']    = 'Geocode';
$_['entry_telephone']  = 'Puhelin';
$_['entry_fax']        = 'Faksi';
$_['entry_image']      = 'Kuva';
$_['entry_open']       = 'Aukioloajat';
$_['entry_comment']    = 'Kommentti';

// Help
$_['help_geocode']     = 'Anna säilön sijainnin geokoodi manuaalisesti.';
$_['help_open']        = 'Täytä tallentaa aukioloajat.';
$_['help_comment']     = 'Tämä kenttä on erityisiä muistiinpanoja haluat kertoa asiakkaalle eli myymälä ei hyväksy sekkejä.';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata säilön sijainteja!';
$_['error_name']       = 'Myymälän nimen on oltava välillä 3-32 merkkiä!';
$_['error_address']    = 'Osoitteen on oltava välillä 3 ja 128 merkkiä!';
$_['error_telephone']  = 'Puhelin on välillä 3 ja 32 merkkiä!';