<?php
// Heading
$_['heading_title']     = 'Vero luokkia';

// Text
$_['text_success']      = 'Menestys: olet muuttanut vero luokkia!';
$_['text_list']         = 'Vero luokka luettelo';
$_['text_add']          = 'Lisää vero luokka';
$_['text_edit']         = 'Muokkaa vero luokkaa';
$_['text_tax_class']    = 'Vero luokka';
$_['text_tax_rate']     = 'Vero kannat';
$_['text_shipping']     = 'Toimitus osoite';
$_['text_payment']      = 'Maksu osoite';
$_['text_store']        = 'Myymälän osoite';

// Column
$_['column_title']      = 'Vero luokan otsikko';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_title']       = 'Vero luokan otsikko';
$_['entry_description'] = 'Kuvaus';
$_['entry_rate']        = 'Vero prosentti';
$_['entry_based']       = 'Perustuu';
$_['entry_geo_zone']    = 'Geo Zone';
$_['entry_priority']    = 'Ensisijainen';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeuksia muokata vero luokkia!';
$_['error_title']       = 'Vero luokan otsikko on oltava välillä 3 ja 32 merkkiä!';
$_['error_description'] = 'Kuvaus on välillä 3 ja 255 merkkiä!';
$_['error_product']     = 'Varoitus: tätä vero luokkaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';