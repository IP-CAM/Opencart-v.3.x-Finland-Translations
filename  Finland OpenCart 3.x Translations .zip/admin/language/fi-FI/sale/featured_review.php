<?php
// Heading
$_['heading_title']     = 'Power Arvostelut-kiinnostavat arvostelut Dashboard';

// Tab
$_['tab_review'] = 'Arvion perusteella';
$_['tab_featured'] = 'Suositeltavat';

// Text
$_['text_success']      = 'Menestys: olet muokannut Power Arvostelut-kiinnostavat arviot!';
$_['text_list']         = 'Tarkista luettelo';
$_['text_add']          = 'Lisää arvostelu';
$_['text_edit']         = 'Muokkaa tarkistusta';

// Column
$_['column_product']    = 'Tuotteen';
$_['column_author']     = 'Kirjoittaja';
$_['column_rating']     = 'Arvostelun';
$_['column_status']     = 'Tila';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';
$_['column_language'] = 'Kieli';
$_['column_text'] = 'Teksti';
$_['column_featured'] = 'Suositeltavat';

// Entry
$_['entry_product']     = 'Tuotteen';
$_['entry_author']      = 'Kirjoittaja';
$_['entry_rating']      = 'Arvostelun';
$_['entry_status']      = 'Tila';
$_['entry_text']        = 'Teksti';
$_['entry_date_added']  = 'Päivä määrä lisätty';
$_['entry_language'] = 'Kieli';
$_['entry_featured'] = 'Suositeltavat';

// Button
$_['button_toggle'] = 'Vaihda';

// Warning
$_['warning_toggle'] = 'Toggle lisää/poistaa arvosteluja Featured-ryhmälle niiden senhetkisen tilan perusteella.';

// Help
$_['help_product']      = 'AUtomaattinen täydennys';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole lupaa muokata Power Arvostelut-kiinnostavat arviot!';