<?php
// Heading
$_['heading_title']        = 'Tuotteen palautukset';

// Text
$_['text_success']         = 'Menestys: olet muokannut palaa!';
$_['text_list']            = 'Tuotteen palautus luettelo';
$_['text_add']             = 'Lisää tuote palautus';
$_['text_edit']            = 'Muokkaa tuotteen palauttamista';
$_['text_opened']          = 'Avattu';
$_['text_unopened']        = 'Avaamaton';
$_['text_order']           = 'Tila uksen tiedot';
$_['text_product']         = 'Tuote tiedot &amp; Palautuksen syy';
$_['text_history']         = 'Historia';
$_['text_history_add']     = 'Lisää historiaa';

// Column
$_['column_return_id']     = 'Palautus tunnus';
$_['column_order_id']      = 'Tilauksen tunnus';
$_['column_customer']      = 'Asiakas';
$_['column_product']       = 'Tuotteen';
$_['column_model']         = 'Malli';
$_['column_status']        = 'Tila';
$_['column_date_added']    = 'Päivä määrä lisätty';
$_['column_date_modified'] = 'Muokkaus päivämäärä';
$_['column_comment']       = 'Kommentti';
$_['column_notify']        = 'Asiakkaan ilmoittama';
$_['column_action']        = 'Toiminta';

// Entry
$_['entry_customer']       = 'Asiakas';
$_['entry_order_id']       = 'Tilauksen tunnus';
$_['entry_date_ordered']   = 'Tilaus päivämäärän';
$_['entry_firstname']      = 'Etunimi';
$_['entry_lastname']       = 'Suku nimi';
$_['entry_email']          = 'Sähköposti';
$_['entry_telephone']      = 'Puhelin';
$_['entry_product']        = 'Tuotteen';
$_['entry_model']          = 'Malli';
$_['entry_quantity']       = 'Määrä';
$_['entry_opened']         = 'Avattu';
$_['entry_comment']        = 'Kommentti';
$_['entry_return_reason']  = 'Palautuksen syy';
$_['entry_return_action']  = 'Palautus toiminto';
$_['entry_return_status']  = 'Palautuksen tila';
$_['entry_notify']         = 'Ilmoita asiakkaalle';
$_['entry_return_id']      = 'Palautus tunnus';
$_['entry_date_added']     = 'Päivä määrä lisätty';
$_['entry_date_modified']  = 'Muokkaus päivämäärä';

// Help
$_['help_product']         = 'AUtomaattinen täydennys';

// Error
$_['error_warning']        = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']     = 'Varoitus: sinulla ei ole oikeutta muuttaa palautuksia!';
$_['error_order_id']       = 'Tilaus tunnus vaaditaan!';
$_['error_firstname']      = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']       = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']          = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']      = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_product']        = 'Tuotteen nimen on oltava suurempi kuin 3 ja alle 255 merkkiä!';
$_['error_model']          = 'Tuote mallin on oltava suurempi kuin 3 ja alle 64 merkkiä!';