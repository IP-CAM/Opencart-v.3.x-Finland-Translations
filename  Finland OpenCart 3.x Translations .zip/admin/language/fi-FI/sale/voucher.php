<?php
// Heading
$_['heading_title']     = 'Lahjakortit';

// Text
$_['text_success']      = 'Menestys: olet muokannut tositteita!';
$_['text_list']         = 'Lahja kortin luettelo';
$_['text_add']          = 'Lisää lahja kortti';
$_['text_edit']         = 'Muokkaa lahja korttia';
$_['text_sent']         = 'Menestys: lahja kortti e-mail on lähetetty!';

// Column
$_['column_name']       = 'Tositteen nimi';
$_['column_code']       = 'Koodi';
$_['column_from']       = 'Päässä';
$_['column_to']         = 'Jotta';
$_['column_theme']      = 'Teema';
$_['column_amount']     = 'Summa';
$_['column_status']     = 'Tila';
$_['column_order_id']   = 'Tilauksen tunnus';
$_['column_customer']   = 'Asiakas';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_code']        = 'Koodi';
$_['entry_from_name']   = 'Nimestä';
$_['entry_from_email']  = 'Sähkö postista';
$_['entry_to_name']     = 'Jotta maine';
$_['entry_to_email']    = 'Jotta sähkö posti';
$_['entry_theme']       = 'Teema';
$_['entry_message']     = 'Viesti';
$_['entry_amount']      = 'Summa';
$_['entry_status']      = 'Tila';

// Help
$_['help_code']         = 'Koodi, jonka asiakas kirjoittaa tositteen aktivoimiseksi.';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata tositteita!';
$_['error_exists']      = 'Varoitus: kuponki koodi on jo käytössä!';
$_['error_code']        = 'Koodin on oltava 3-10 merkkiä pitkä!';
$_['error_to_name']     = 'Vastaanottajan nimen on oltava 1-64 merkkiä!';
$_['error_from_name']   = 'Nimesi on oltava välillä 1 ja 64 merkkiä!';
$_['error_email']       = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_amount']      = 'Summan on oltava suurempi tai yhtä suuri kuin 1!';
$_['error_order']       = 'Varoitus: tätä tositetta ei voi poistaa, koska se on osa <a href="%s">Tilaa</a>!';