<?php
// Heading
$_['heading_title']     = 'Tosite Teemat';

// Text
$_['text_success']      = 'Menestys: olet muokannut kuponki teemoja!';
$_['text_list']         = 'Tosite-teeman luettelo';
$_['text_add']          = 'Lisää tosite teema';
$_['text_edit']         = 'Muokkaa tosite teemaa';

// Column
$_['column_name']       = 'Tosite teeman nimi';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Tosite teeman nimi';
$_['entry_description'] = 'Tosite-teeman kuvaus';
$_['entry_image']       = 'Kuva';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata tosite teemoja!';
$_['error_name']        = 'Tosite teeman nimen on oltava välillä 3-32 merkkiä!';
$_['error_image']       = 'Kuva tarvitaan!';
$_['error_voucher']     = 'Varoitus: tätä tosite teemaa ei voi poistaa, koska se on tällä hetkellä määritetty %s Tositteet!';