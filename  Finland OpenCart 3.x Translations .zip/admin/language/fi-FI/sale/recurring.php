<?php
// Heading
$_['heading_title']                        = 'Toistuvat tila ukset';

// Text
$_['text_success']                         = 'Onnistui: olet muokannut toistuvia profiileja!';
$_['text_list']                            = 'Toistuvien tilausten luettelo';
$_['text_filter']                          = 'Suodatin';
$_['text_recurring_detail']                = 'Toistuvat yksityiskohdat';
$_['text_order_detail']                    = 'Tilaus tiedot';
$_['text_product_detail']                  = 'Tuotteen tiedot';
$_['text_transaction']                     = 'Tapahtumat';
$_['text_order_recurring_id']              = 'Toistuvan tila uksen tunnus';
$_['text_reference']                       = 'Maksu viite';
$_['text_recurring_name']                  = 'Toistuva profiili';
$_['text_recurring_description']           = 'Kuvaus';
$_['text_recurring_status']                = 'Toistuva tila';
$_['text_payment_method']                  = 'Maksutapa';
$_['text_order_id']                        = 'Tilauksen tunnus';
$_['text_customer']                        = 'Asiakas';
$_['text_email']                           = 'Sähköposti';
$_['text_date_added']                      = 'Päivä määrä lisätty';
$_['text_order_status']                    = 'Tila uksen tila';
$_['text_type']                            = 'Tyyppi';
$_['text_action']                          = 'Toiminta';
$_['text_product']                         = 'Tuotteen';
$_['text_quantity']                        = 'Määrä';
$_['text_amount']                          = 'Summa';
$_['text_cancel_payment']                  = 'Maksun peruuttaminen';
$_['text_status_1']                        = 'Aktiivinen';
$_['text_status_2']                        = 'Passiivinen';
$_['text_status_3']                        = 'Peruutettu';
$_['text_status_4']                        = 'Keskeytetty';
$_['text_status_5']                        = 'Vanhentunut';
$_['text_status_6']                        = 'Odottavat';

$_['text_transactions']                    = 'Tapahtumat';
$_['text_cancel_confirm']                  = 'Profiilin peruuttamista ei voi perua! Haluatko varmasti tehdä tämän?';
$_['text_transaction_date_added']          = 'Päivä määrä lisätty';
$_['text_transaction_payment']             = 'Maksu';
$_['text_transaction_outstanding_payment'] = 'Maksamatta oleva maksu';
$_['text_transaction_skipped']             = 'Maksu ohitettu';
$_['text_transaction_failed']              = 'Maksu epäonnistui';
$_['text_transaction_cancelled']           = 'Peruutettu';
$_['text_transaction_suspended']           = 'Keskeytetty';
$_['text_transaction_suspended_failed']    = 'Keskeytetty epäonnistuneita maksuja';
$_['text_transaction_outstanding_failed']  = 'Maksamatta oleva maksu epäonnistui';
$_['text_transaction_expired']             = 'Vanhentunut';
$_['text_cancelled']                       = 'Toistuva maksu on peruutettu';

// Column
$_['column_order_recurring_id']             = 'Toistuva tunnus';
$_['column_order_id']                       = 'Tilauksen tunnus';
$_['column_reference']                      = 'Maksu viite';
$_['column_customer']                       = 'Asiakas';
$_['column_date_added']                     = 'Päivä määrä lisätty';
$_['column_status']                         = 'Tila';
$_['column_amount']                         = 'Summa';
$_['column_type']                           = 'Tyyppi';
$_['column_action']                         = 'Toiminta';

// Entry
$_['entry_order_recurring_id']             = 'Toistuva tunnus';
$_['entry_order_id']                       = 'Tilauksen tunnus';
$_['entry_reference']                      = 'Maksu viite';
$_['entry_customer']                       = 'Asiakas';
$_['entry_date_added']                     = 'Päivä määrä lisätty';
$_['entry_status']                         = 'Tila';
$_['entry_type']                           = 'Tyyppi';
$_['entry_action']                         = 'Toiminta';
$_['entry_email']                          = 'Sähköposti';
$_['entry_description']                    = 'Toistuvan profiilin kuvaus';
$_['entry_product']                        = 'Tuotteen';
$_['entry_quantity']                       = 'Määrä';
$_['entry_amount']                         = 'Summa';
$_['entry_recurring']                      = 'Toistuva profiili';
$_['entry_payment_method']                 = 'Maksutapa';
$_['entry_cancel_payment']                 = 'Maksun peruuttaminen';

// Error
$_['error_not_cancelled']                  = 'Virhe: %s';
$_['error_not_found']                      = 'Toistuvan profiilin peruuttaminen ei onnistunut';