<?php
// Heading
$_['heading_title']                = 'Tallentaa';

// Text
$_['text_settings']                = 'Asetukset';
$_['text_success']                 = 'Menestys: olet muokannut myymälöissä!';
$_['text_list']                    = 'Myymälän luettelo';
$_['text_add']                     = 'Lisää säilö';
$_['text_edit']                    = 'Muokkaa säilöä';
$_['text_items']                   = 'Kohteita';
$_['text_tax']                     = 'Veroja';
$_['text_account']                 = 'Tili';
$_['text_checkout']                = 'Kassalle';
$_['text_stock']                   = 'Stock';
$_['text_shipping']                = 'Toimitus osoite';
$_['text_payment']                 = 'Maksu osoite';

// Column
$_['column_name']                  = 'Myymälän nimi';
$_['column_url']	               = 'Säilön URL-osoite';
$_['column_action']                = 'Toiminta';

// Entry
$_['entry_url']                    = 'Säilön URL-osoite';
$_['entry_ssl']                    = 'SSL-URL';
$_['entry_meta_title']             = 'Meta-Otsikko';
$_['entry_meta_description']       = 'Meta-tunnisteen kuvaus';
$_['entry_meta_keyword']           = 'Metakoodin avain sanat';
$_['entry_layout']                 = 'Oletus asettelun';
$_['entry_theme']                  = 'Teema';
$_['entry_name']                   = 'Myymälän nimi';
$_['entry_owner']                  = 'Myymälän omistaja';
$_['entry_address']                = 'Osoite';
$_['entry_geocode']                = 'Geocode';
$_['entry_email']                  = 'Sähköposti';
$_['entry_telephone']              = 'Puhelin';
$_['entry_fax']                    = 'Faksi';
$_['entry_image']                  = 'Kuva';
$_['entry_open']                   = 'Aukioloajat';
$_['entry_comment']                = 'Kommentti';
$_['entry_location']               = 'Säilön sijainti';
$_['entry_country']                = 'Maa';
$_['entry_zone']                   = 'Alue/osavaltio';
$_['entry_language']               = 'Kieli';
$_['entry_currency']               = 'Valuutta';
$_['entry_tax']                    = 'Näytä hinnat verolla';
$_['entry_tax_default']            = 'Käytä myymälän vero osoitetta';
$_['entry_tax_customer']           = 'Käytä asiakkaan vero osoitetta';
$_['entry_customer_group']         = 'Asiakas ryhmä';
$_['entry_customer_group_display'] = 'Asiakas ryhmät';
$_['entry_customer_price']         = 'Kirjautumisnäytön hinnat';
$_['entry_account']                = 'Tilin ehdot';
$_['entry_cart_weight']            = 'Näytä paino ostos korissa';
$_['entry_checkout_guest']         = 'Vieras kassalle';
$_['entry_checkout']               = 'Kassalle ehdot';
$_['entry_order_status']           = 'Tila uksen tila';
$_['entry_stock_display']          = 'Näytä Stock';
$_['entry_stock_checkout']         = 'Stock Checkout';
$_['entry_logo']                   = 'Myymälän logo';
$_['entry_icon']                   = 'Kuvaketta';
$_['entry_secure']                 = 'Käytä SSL';

// Help
$_['help_url']                     = 'Sisällytä koko URL-osoite myymälään. Muista lisätä "/" lopussa. Esimerkki: http://www.yourdomain.com/path/<br /><br />Älä käytä hakemistoja uuden myymälän luomiseen. Sinun tulisi aina kohta toisen verkko tunnuksen tai osa verkko tunnuksen teidän hosting.';
$_['help_ssl']                     = 'SSL-URL-osoitteen myymälään. Muista lisätä "/" lopussa. Esimerkki: http://www.yourdomain.com/path/<br /><br />Älä käytä hakemistoja uuden myymälän luomiseen. Sinun tulisi aina kohta toisen verkko tunnuksen tai osa verkko tunnuksen teidän hosting.';
$_['help_geocode']                 = 'Anna säilön sijainnin geokoodi manuaalisesti.';
$_['help_open']                    = 'Täytä tallentaa aukioloajat.';
$_['help_comment']                 = 'Tämä kenttä on erityisiä muistiinpanoja haluat kertoa asiakkaalle eli myymälä ei hyväksy sekkejä.';
$_['help_location']                = 'Ne eri myymälän sijainnit, jotka haluat näkyvän ota yhteyttä-lomakkeessa.';
$_['help_currency']                = 'Muuta oletus valuuttaa. Tyhjennä selaimen väli muisti, jos haluat nähdä muutoksen ja palauttaa aiemmin luodun eväs teen.';
$_['help_tax_default']             = 'Käytä myymälän osoitetta verojen laskemiseen, jos asiakas ei ole kirjautunut sisään. Voit halutessasi käyttää asiakkaan toimitus-tai maksu osoitteen myymälän osoitetta.';
$_['help_tax_customer']            = 'Käytä asiakkaiden oletus osoitetta, kun he kirjautuessaan laskemaan veroja. Voit halutessasi käyttää asiakkaan toimitus-tai maksu osoitteen oletus osoitetta.';
$_['help_customer_group']          = 'Oletus asiakas ryhmä.';
$_['help_customer_group_display']  = 'Näytä asiakas ryhmät, joita uudet asiakkaat voivat käyttää, kuten tukku-ja liike toiminta rekisteröityessään.';
$_['help_customer_price']          = 'Näytä hinnat vain, kun asiakas on kirjautuneena.';
$_['help_account']                 = 'Pakottaa ihmiset hyväksymään ehdot, ennen kuin tili voidaan luoda.';
$_['help_checkout_guest']          = 'Salli asiakkaiden uloskuittaus luomatta tiliä. Tämä ei ole käytettävissä, kun ladattava tuote on ostos korissa.';
$_['help_checkout']                = 'Pakottaa ihmiset hyväksymään ehtoja, ennen kuin asiakas voi kassalle.';
$_['help_order_status']            = 'Määritä tila uksen oletus tila tilausta käsitellessäsi.';
$_['help_stock_display']           = 'Näytä varasto määrä tuote sivulla.';
$_['help_stock_checkout']          = 'Salli asiakkaiden edelleen kassalle, jos tuotteita ne tilaavat eivät ole varastossa.';
$_['help_icon']                    = 'Kuvakkeen pitäisi olla PNG, joka on 16px x 16px.';
$_['help_secure']                  = 'Jos haluat käyttää SSL-varmennetta, varmista, että SSL-varmenne on asennettuna.';

// Error
$_['error_warning']                = 'Varoitus: ole hyvä ja tarkista lomake huolellisesti virheiden varalta!';
$_['error_permission']             = 'Varoitus: sinulla ei ole oikeutta muokata kauppoja!';
$_['error_url']                    = 'Säilön URL-osoite vaaditaan!';
$_['error_meta_title']             = 'Otsikon on oltava välillä 3 ja 32 merkkiä!';
$_['error_name']                   = 'Myymälän nimen on oltava välillä 3-32 merkkiä!';
$_['error_owner']                  = 'Säilön omistajan on oltava 3-64 merkkiä pitkä!';
$_['error_address']                = 'Myymälän osoitteen on oltava 10-256 merkkiä!';
$_['error_email']                  = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']              = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_customer_group_display'] = 'Sinun on sisällytettävä oletus asiakas ryhmä, jos aiot käyttää tätä ominaisuutta!';
$_['error_default']                = 'Varoitus: et voi poistaa oletuksena Store!';
$_['error_store']                  = 'Varoitus: Tätä säilöä ei voi poistaa, koska se on tällä hetkellä määritetty %s Tilaukset!';