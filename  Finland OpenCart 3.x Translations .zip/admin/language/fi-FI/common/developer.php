<?php
// Heading
$_['heading_title']    = 'Kehittäjän asetukset';

// Text
$_['text_success']     = 'Onnistui: olet muokannut kehittäjän asetuksia!';
$_['text_theme']       = 'Teema';
$_['text_sass']        = 'Sass';
$_['text_cache']       = 'Onnistui: olet poistanut %s Välimuisti!';

// Column
$_['column_component'] = 'Komponentti';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_theme']      = 'Teema';
$_['entry_sass']       = 'Sass';
$_['entry_cache']      = 'Välimuisti';

// Button
$_['button_on']        = 'Kartalla';
$_['button_off']       = 'Pois';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata kehittäjän asetuksia!';