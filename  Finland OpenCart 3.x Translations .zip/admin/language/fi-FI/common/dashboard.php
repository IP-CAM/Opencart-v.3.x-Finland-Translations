<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install'] = 'Varoitus: Asenna kansio on edelleen olemassa ja se olisi poistettava turvallisuussyistä!';