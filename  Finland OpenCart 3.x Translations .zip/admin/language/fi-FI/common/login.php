<?php
// Heading
$_['heading_title']  = 'Hallinto';

// Text
$_['text_heading']   = 'Hallinto';
$_['text_login']     = 'Kirjoita kirjautumistietosi.';
$_['text_forgotten'] = 'Unohtunut sala sana';

// Entry
$_['entry_username'] = 'Käyttäjätunnus';
$_['entry_password'] = 'Salasana';

// Button
$_['button_login']   = 'Kirjaudu';

// Error
$_['error_login']    = 'Käyttäjä nimi ja/tai sala sana eivät täsmää.';
$_['error_token']    = 'Virheellinen Token-istunto. Ole hyvä ja kirjaudu uudelleen.';