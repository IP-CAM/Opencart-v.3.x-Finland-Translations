<?php
// Text
$_['text_footer']  = '<a href="http://www.opencart.com">Openpart</a> &copy; 2009-' . date('Y') . ' Kaikki oikeudet pidätetään.';
$_['text_version'] = 'Versio %s';