<?php
// Heading
$_['heading_title']    = 'Image Managerin';

// Text
$_['text_uploaded']    = 'Menestys: tiedosto on ladattu!';
$_['text_directory']   = 'Menestys: Directory luotu!';
$_['text_delete']      = 'Onnistui: tiedosto tai kansio on poistettu!';

// Entry
$_['entry_search']     = 'Etsi..';
$_['entry_folder']     = 'Kansion nimi';

// Error
$_['error_permission'] = 'Varoitus: käyttö estetty!';
$_['error_filename']   = 'Varoitus: tiedosto nimen on oltava välillä 3 ja 255!';
$_['error_folder']     = 'Varoitus: kansion nimen on oltava välillä 3 ja 255!';
$_['error_exists']     = 'Varoitus: samanniminen tiedosto tai kansio on jo olemassa!';
$_['error_directory']  = 'Varoitus: hakemistoa ei ole!';
$_['error_filesize']   = 'Varoitus: väärä tiedosto koko!';
$_['error_filetype']   = 'Varoitus: virheellinen tiedosto tyyppi!';
$_['error_upload']     = 'Varoitus: tiedostoa ei voitu ladata tuntemattomasta syystä!';
$_['error_delete']     = 'Varoitus: et voi poistaa tätä hakemistoa!';