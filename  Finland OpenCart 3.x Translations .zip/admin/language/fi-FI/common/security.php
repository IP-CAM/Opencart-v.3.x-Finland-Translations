<?php
// Heading
$_['heading_title']    = 'Tärkeä turvallisuus ilmoitus!';

// Text
$_['text_success']     = 'Menestys: olet muokannut varastointi kansio!';
$_['text_admin']       = 'Edit admin/config. php ja muutos';
$_['text_security']    = 'Se on erittäin imporant että te ehdottaa muisti osoite kalenteri ulkona-lta höyty osoite kalenteri (e.g. public_html, www eli htdocs).';
$_['text_choose']      = 'Tallennus hakemiston siirto tavan valitseminen';
$_['text_automatic']   = 'Automaattisesti siirtää';
$_['text_manual']      = 'Siirrä manuaalisesti';
$_['text_move']        = 'Siirtää';
$_['text_to']          = 'jotta';
$_['text_config']      = 'Muokkaa config. php muutos';
$_['text_admin']       = 'Edit admin/config. php ja muutos';

// Button
$_['button_move']      = 'Siirtää';
$_['button_manual']    = 'Manuaalinen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Storage Directory!';
$_['error_path']       = 'Varoitus: Virheellinen polku!';
$_['error_directory']  = 'Varoitus: Virheellinen hakemisto!';
$_['error_exists']     = 'Varoitus: hakemisto on jo olemassa!';
$_['error_writable']   = 'Varoitus: config. php ja admin/config. php on tehtävä kirjoitettava!';
