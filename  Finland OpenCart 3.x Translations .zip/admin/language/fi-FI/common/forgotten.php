<?php
// Heading
$_['heading_title']   = 'Unohditko salasanasi?';

// Text
$_['text_forgotten']  = 'Unohtunut sala sana';
$_['text_your_email'] = 'Sähkö posti osoitteesi';
$_['text_email']      = 'Kirjoita tiliisi liittyvä Sähkö posti osoite. Click alistaa jotta hankkia tunnus sana palauttaa kytkeä e-kirjain-panssaroitu jotta te.';
$_['text_success']    = 'Sähkö posti viestin vahvistus linkki on lähetetty admin Sähkö posti osoitteesi.';

// Entry
$_['entry_email']     = 'Sähköpostiosoite';
$_['entry_password']  = 'Uusi sala sana';
$_['entry_confirm']   = 'Vahvista';

// Error
$_['error_email']     = 'Varoitus: Sähkö posti osoitetta ei löytynyt meidän kirjaa, yritä uudelleen!';
$_['error_password']  = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']   = 'Sala sana ja sala sana vahvistus eivät täsmää!';