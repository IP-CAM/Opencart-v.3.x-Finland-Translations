<?php
// Heading
$_['heading_title']      = 'Openpart';

// Text
$_['text_profile']       = 'Profiilisi';
$_['text_store']         = 'Tallentaa';
$_['text_help']          = 'Apua';
$_['text_homepage']      = 'Opencart koti sivu';
$_['text_support']       = 'Support Forum';
$_['text_documentation'] = 'Asiakirjat';
$_['text_logout']        = 'Logout';