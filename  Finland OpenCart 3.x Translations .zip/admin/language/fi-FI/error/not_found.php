<?php
// Heading
$_['heading_title']  = 'Sivua ei löydy!';

// Text
$_['text_not_found'] = 'Etsimäsi sivu ei löytynyt! Jos ongelma toistuu, ota yhteyttä järjestelmänvalvojaan.';