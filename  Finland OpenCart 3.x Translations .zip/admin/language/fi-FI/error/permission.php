<?php
// Heading
$_['heading_title']   = 'Lupa estetty!';

// Text
$_['text_permission'] = 'Sinulla ei ole oikeuksia tämän sivun käyttö oikeus, Tutustu järjestelmänvalvojaan.';