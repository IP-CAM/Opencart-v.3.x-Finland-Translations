<?php
// Heading
$_['heading_title']     = 'Tapahtumia';

// Text
$_['text_success']      = 'Menestys: olet muokannut tapahtumia!';
$_['text_list']         = 'Tapahtuma luettelo';
$_['text_event']        = 'Laajennuksilla voidaan käyttää tapahtumia, jotka ohittavat myymälän oletus toiminnot. Jos sinulla on ongelmia, voit poistaa tai ottaa käyttöön tapahtumia täällä.';
$_['text_info']         = 'Tapahtuman tiedot';
$_['text_trigger']      = 'Laukaista';
$_['text_action']       = 'Toiminta';

// Column
$_['column_code']       = 'Tapahtuman koodi';
$_['column_status']     = 'Tila';
$_['column_sort_order'] = 'Lajittelujärjestyksen';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata laajennuksia!';
