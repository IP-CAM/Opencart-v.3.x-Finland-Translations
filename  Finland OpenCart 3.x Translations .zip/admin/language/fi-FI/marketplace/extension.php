<?php
// Heading
$_['heading_title'] = 'Tiedostopääte';

// Text
$_['text_success']  = 'Menestys: olet muokannut laajennuksia!';
$_['text_list']     = 'Laajennuksen luettelo';
$_['text_type']     = 'Valitse laajennus tyyppi';
$_['text_filter']   = 'Suodatin';