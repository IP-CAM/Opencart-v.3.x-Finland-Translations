<?php
// Heading
$_['heading_title']        				= 'Openbay Pro';

// Buttons
$_['button_retry']						= 'Yritä';
$_['button_update']						= 'Päivitys';
$_['button_patch']						= 'Laastari';
$_['button_faq']						= 'Näytä UKK aihe';

// Tab
$_['tab_setting']						= 'Asetukset';
$_['tab_update']						= 'Ohjelmisto päivitykset';
$_['tab_developer']						= 'Kehittäjä';

// Text
$_['text_dashboard']         			= 'Dashboard';
$_['text_success']         				= 'Onnistui: asetukset on tallennettu';
$_['text_products']          			= 'Kohteita';
$_['text_orders']          				= 'Tilaukset';
$_['text_manage']          				= 'Hallita';
$_['text_help']                     	= 'Apua';
$_['text_tutorials']                    = 'Tutorials';
$_['text_suggestions']                  = 'Ideoita';
$_['text_version_latest']               = 'Käytössäsi on uusin versio';
$_['text_version_check']     			= 'Ohjelmisto version tarkistaminen';
$_['text_version_installed']    		= 'Asennettu versio openbay Pro: v';
$_['text_version_current']        		= 'Sinun käännös on';
$_['text_version_available']        	= 'viimeistään on';
$_['text_language']             		= 'API-vastaus kieli';
$_['text_getting_messages']     		= 'Getting openbay Pro viestit';
$_['text_complete']     				= 'Täydellinen';
$_['text_patch_complete']           	= 'Korjaus tiedosto on otettu käyttöön';
$_['text_updated']						= 'Moduuli on päivitetty (v.%s)';
$_['text_update_description']			= 'Päivitys työkalu tekee muutoksia kauppa tiedosto järjestelmään. Varmista, että sinulla on täydellinen tiedoston ja tieto kannan varmuus kopiointi ennen päivittämistä.';
$_['text_patch_description']			= 'Jos latasi päivitys tiedostot manuaalisesti, viimeistele päivitys suorittamalla korjaus tiedosto.';
$_['text_clear_faq']                    = 'Tyhjennä piilotetut FAQ ponnahdus ikkunat';
$_['text_clear_faq_complete']           = 'Ilmoitukset näkyvät nyt uudelleen';
$_['text_install_success']              = 'Marketplace on asennettu';
$_['text_uninstall_success']            = 'Marketplace on poistettu';
$_['text_title_messages']               = 'Viestit &amp; Ilmoitukset';
$_['text_marketplace_shipped']			= 'Tila uksen tilaksi päivittyy toimitetuksi Marketplace';
$_['text_action_warning']				= 'Tämä toiminta on vaarallista niin on suojattu Sala sanalla.';
$_['text_check_new']					= 'Tarkistetaan uudempaa versiota';
$_['text_downloading']					= 'Ladataan päivitys tiedostoja';
$_['text_extracting']					= 'Puretaan tiedostoja';
$_['text_running_patch']				= 'Korjaus tiedostojen suorittaminen';
$_['text_fail_patch']					= 'Päivitys tiedostoja ei voi poimia';
$_['text_updated_ok']					= 'Päivitys valmis, asennettu versio on nyt ';
$_['text_check_server']					= 'Tarkistetaan palvelin vaatimuksia';
$_['text_version_ok']					= 'Ohjelmisto on jo ajan tasalla, asennettu versio on ';
$_['text_remove_files']					= 'Tiedostojen poistaminen ei enää tarvita';
$_['text_confirm_backup']				= 'Varmista, että sinulla on täysi varmuus kopio, ennen kuin jatkat';
$_['text_software_update']				= 'Openbay Pro ohjelmisto päivitys';
$_['text_patch_option']				    = 'Manuaalinen korjaaminen';

// Column
$_['column_name']          				= 'Laajennuksen nimi';
$_['column_status']        				= 'Tila';
$_['column_action']        				= 'Toiminta';

// Entry
$_['entry_patch']            			= 'Manuaalinen päivitys korjaus';
$_['entry_courier']						= 'Courier';
$_['entry_courier_other']           	= 'Muut kuriiri';
$_['entry_tracking']                	= 'Seuranta';
$_['entry_empty_data']					= 'Tyhjät säilön tiedot?';
$_['entry_password_prompt']				= 'Kirjoita tietojen pyyhintä sala sana';
$_['entry_update']						= 'Easy 1 Valitse Päivitä';
$_['entry_beta']						= 'Apu lähteä jhk käännös';

// Error
$_['error_admin']             			= 'Odotettiin admin-hakemistoa';
$_['error_failed']						= 'Lataaminen epäonnistui, yritä uudelleen?';
$_['error_tracking_id_format']			= 'Seuranta tunnuksesi ei voi sisältää merkkejä > tai';
$_['error_tracking_courier']			= 'Sinun on valittava kuriiri, jos haluat lisätä seuranta tunnuksen';
$_['error_tracking_custom']				= 'Jätä Courier kenttä tyhjäksi, jos haluat käyttää mukautettua kuriiri';
$_['error_permission']					= 'Sinulla ei ole oikeuksia muokata openbay Pro-laajennusta';
$_['error_file_delete']					= 'Näitä tiedostoja ei voi poistaa, ne on poistettava manuaalisesti';
$_['error_mkdir']						= 'PHP-toiminto "mkdir" on poistettu käytöstä, ota yhteyttä isäntä';
$_['error_openssl_encrypt']            	= 'PHP funktio "openssl_encrypt" ei ole käytössä. Ota yhteyttä palveluntarjoajaasi.';
$_['error_openssl_decrypt']            	= 'PHP funktio "openssl_decrypt" ei ole käytössä. Ota yhteyttä palveluntarjoajaasi.';
$_['error_fopen']             			= 'PHP toiminto "fopen" ei ole käytössä. Ota yhteyttä palveluntarjoajaasi.';
$_['error_url_fopen']             		= '"allow_url_fopen" direktiivi on poistettu käytöstä isäntä-et voi tuoda kuvia tuotaessa tuotteita eBay';
$_['error_curl']                        = 'PHP kirjasto "curl" ei ole käytössä. Ota yhteyttä palveluntarjoajaasi.';
$_['error_zip']                         = 'ZIP-laajennus on ladattava. Ota yhteyttä palveluntarjoajaasi.';
$_['error_mbstring']               		= 'PHP kirjasto "MB Strings" ei ole käytössä. Ota yhteyttä palveluntarjoajaasi.';
$_['error_oc_version']             		= 'Openclipart-versiosi ei ole testattu toimi tämän moduulin kanssa. Saatat kohdata ongelmia.';

// Help
$_['help_clear_faq']					= 'Näytä kaikki ohje ilmoitukset uudelleen';
$_['help_empty_data']					= 'Tämä voi aiheuttaa vakavaa vahinkoa, Älä käytä sitä, jos et tiedä mitä se tekee!';
$_['help_easy_update']					= 'Asenna openbay Pron uusin versio automaattisesti valitsemalla Päivitä.';
$_['help_patch']						= 'Suorita korjaus tiedostojen komento sarjat napsauttamalla';
$_['help_beta']							= 'Varoitus! Beta-versio on uusin kehitys versio. Se ei voi olla vakaa ja voi sisältää vikoja.';
