<?php
// Heading
$_['heading_title']    = 'Opencart Marketplace API';

// Text
$_['text_success']     = 'Onnistui: olet muokannut API-tietojasi!';
$_['text_signup']      = 'Anna opentart API tiedot, jotka voit saada <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">Täällä</a>.';

// Entry
$_['entry_username']   = 'Käyttäjätunnus';
$_['entry_secret']     = 'Salainen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata Marketplace API!';
$_['error_username']   = 'Käyttäjä tunnus vaaditaan!';
$_['error_secret']     = 'Salaisuus vaaditaan!';
