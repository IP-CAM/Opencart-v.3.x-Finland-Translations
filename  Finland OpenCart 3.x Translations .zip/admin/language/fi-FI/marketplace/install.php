<?php
// Text
$_['text_success']     = 'Menestys: olet muokannut laajennuksia!';
$_['text_unzip']       = 'Puretaan tiedostoja!';
$_['text_move']        = 'Kopioidaan tiedostoja!';
$_['text_xml']         = 'Hakeminen muutoksia!';
$_['text_remove']      = 'Väliaikaisten tiedostojen poistaminen!';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata laajennuksia!';
$_['error_install']    = 'Laajennus asennus tapahtuu odota muutama sekunti ennen kuin yrität asentaa!';
$_['error_unzip']      = 'Zip-tiedostoa ei voi avata!';
$_['error_file']       = 'Asennus tiedostoa ei löytynyt!';
$_['error_directory']  = 'Asenna hakemistoon ei löytynyt!';
$_['error_code']       = 'Yksilöllinen koodi tarvitaan muutos XML!';
$_['error_xml']        = 'Muutos %s on jo käytössä!';
$_['error_exists']     = 'Sen tiedoston %s jo olemassa!';
$_['error_allowed']    = 'Hakemiston %s ei saa kirjoittaa!';