<?php
// Heading
$_['heading_title']      = 'Extension Marketplace';

// Text
$_['text_success']       = 'Menestys: olet muokannut laajennuksia!';
$_['text_list']          = 'Laajennuksen luettelo';
$_['text_filter']        = 'Suodatin';
$_['text_search']        = 'Etsi laajennuksia ja teemoja';
$_['text_category']      = 'Luokat';
$_['text_all']           = 'Kaikki';
$_['text_theme']         = 'Teemoja';
$_['text_marketplace']   = 'Kauppapaikkoja';
$_['text_language']      = 'Kielet';
$_['text_payment']       = 'Maksu';
$_['text_shipping']      = 'Toimitus';
$_['text_module']        = 'Moduulit';
$_['text_total']         = 'Tilausten yhteissummat';
$_['text_feed']          = 'Syötteet';
$_['text_report']        = 'Raportit';
$_['text_other']         = 'Muut';
$_['text_free']          = 'Ilmainen';
$_['text_paid']          = 'Maksettu';
$_['text_purchased']     = 'Ostettu';
$_['text_date_modified'] = 'Muokkaus päivämäärä';
$_['text_date_added']    = 'Päivä määrä lisätty';
$_['text_rating']        = 'Arvostelun';
$_['text_reviews']       = 'Arvion perusteella';
$_['text_compatibility'] = 'Yhteensopivuus';
$_['text_downloaded']    = 'Ladata';
$_['text_member_since']  = 'Jäsen vuodesta:';
$_['text_price']         = 'Hinta';
$_['text_partner']       = 'Kehittämä opencart Partner';
$_['text_support']       = '12 kuukauden Ilmainen tuki';
$_['text_documentation'] = 'Dokumentaatio mukana';
$_['text_sales']         = 'Myynti';
$_['text_comment']       = 'Kommentit';
$_['text_download']      = 'Lataaminen';
$_['text_install']       = 'Asentaminen';
$_['text_comment_add']   = 'Jätä kommenttisi';
$_['text_write']         = 'Kirjoita kommenttisi tähän..';
$_['text_purchase']      = 'Ole hyvä ja vahvista kuka olet!';
$_['text_pin']           = 'Anna nelinumeroinen PIN-koodi. Tämä PIN-koodi on suojata tilisi.';
$_['text_secure']        = 'Älä anna PIN-koodi, joka sisältää kehittäjille. Tokko te edellyttää by ala myyjä jotta asettaa by ala ajaksi te niin muodoin te pitäisi email heidät tarvittaessa ala.';
$_['text_name']          = 'Lataa nimi';
$_['text_progress']      = 'Edistystä';
$_['text_available']     = 'Käytettävissä olevat asennukset';
$_['text_action']        = 'Toiminta';

// Entry
$_['entry_pin']          = 'Pin';

// Tab
$_['tab_description']    = 'Kuvaus';
$_['tab_documentation']  = 'Asiakirjat';
$_['tab_download']       = 'Lataa';
$_['tab_comment']        = 'Kommentti';

// Button
$_['button_opencart']    = 'Marketplace API';
$_['button_purchase']    = 'Ostaa';
$_['button_view_all']    = 'Näytä kaikki laajennukset';
$_['button_get_support'] = 'Hae tukea';
$_['button_comment']     = 'Kommentti';
$_['button_reply']       = 'Vastaus';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole oikeutta muokata laajennuksia!';
$_['error_opencart']     = 'Varoitus: sinun on annettava opencart API tiedot ennen kuin voit tehdä ostoksia!';
$_['error_install']      = 'Laajennus asennus tapahtuu odota muutama sekunti ennen kuin yrität asentaa!';
$_['error_purchase']     = 'Laajennusta ei voi ostaa!';
$_['error_download']     = 'Laajennusta ei voitu ladata!';
