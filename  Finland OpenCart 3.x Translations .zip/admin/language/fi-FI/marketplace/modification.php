<?php
// Heading
$_['heading_title']     = 'Muutokset';

// Text
$_['text_success']      = 'Menestys: olet muokannut muutoksia!';
$_['text_refresh']      = 'Aina kun otat käyttöön/poistaa tai poistaa muutoksia sinun täytyy klikata Päivitä-painiketta rakentaa oman muutoksen väli muisti!';
$_['text_list']         = 'Muutos luettelo';

// Column
$_['column_name']       = 'Muokkauksen nimi';
$_['column_author']     = 'Kirjoittaja';
$_['column_version']    = 'Versio';
$_['column_status']     = 'Tila';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata muutoksia!';