<?php
// Heading
$_['heading_title']     = 'Extension Installer';

// Text
$_['text_progress']     = 'Asennuksen edistyminen';
$_['text_upload']       = 'Lataa laajennukset';
$_['text_history']      = 'Asenna historia';
$_['text_success']      = 'Menestys: laajennus on asennettu!';
$_['text_install']      = 'Asentaminen';

// Column
$_['column_filename']   = 'Tiedostonimi';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_upload']      = 'Lataa tiedosto';
$_['entry_progress']    = 'Edistystä';

// Help
$_['help_upload']       = 'Edellyttää muutos tiedosto, jonka tunniste on. ocmod. zip.';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata laajennuksia!';
$_['error_install']     = 'Laajennus asennus tapahtuu odota muutama sekunti ennen kuin yrität asentaa!';
$_['error_upload']      = 'Tiedostoa ei voitu ladata palvelimeen!';
$_['error_filetype']    = 'Virheellinen tiedosto tyyppi!';
$_['error_file']        = 'Tiedostoa ei löytynyt!';