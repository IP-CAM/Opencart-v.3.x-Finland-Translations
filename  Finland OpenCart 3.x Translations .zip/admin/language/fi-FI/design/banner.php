<?php
// Heading
$_['heading_title']     = 'Bannerit';

// Text
$_['text_success']      = 'Menestys: olet muokannut bannereita!';
$_['text_list']         = 'Banner List';
$_['text_add']          = 'Lisää banneri';
$_['text_edit']         = 'Muokkaa banneria';
$_['text_default']      = 'Oletus';

// Column
$_['column_name']       = 'Bannerin nimi';
$_['column_status']     = 'Tila';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Bannerin nimi';
$_['entry_title']       = 'Otsikko';
$_['entry_link']        = 'Linkki';
$_['entry_image']       = 'Kuva';
$_['entry_status']      = 'Tila';
$_['entry_sort_order']  = 'Lajittelujärjestyksen';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muuttaa bannereita!';
$_['error_name']       = 'Banner nimi on välillä 3 ja 64 merkkiä!';
$_['error_title']      = 'Banner otsikko on välillä 2 ja 64 merkkiä!';