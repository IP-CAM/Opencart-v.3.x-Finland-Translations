<?php
// Heading
$_['heading_title']    = 'SEO URL';

// Text
$_['text_success']     = 'Menestys: olet muokannut SEO URL!';
$_['text_list']        = 'SEO URL-luettelo';
$_['text_add']         = 'Lisää SEO URL';
$_['text_edit']        = 'Edit SEO URL';
$_['text_filter']      = 'Suodatin';
$_['text_default']     = 'Oletus';

// Column
$_['column_query']     = 'Kyselyn';
$_['column_keyword']   = 'Avainsanan';
$_['column_store']     = 'Store';
$_['column_language']  = 'Kieli';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_query']      = 'Kyselyn';
$_['entry_keyword']    = 'Avainsanan';
$_['entry_store']      = 'Store';
$_['entry_language']   = 'Kieli';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa muokata SEO URL!';
$_['error_query']      = 'Kyselyn on oltava välillä 3 ja 64 merkkiä!';
$_['error_keyword']    = 'Avain sanan on oltava välillä 3 ja 64 merkkiä!';
$_['error_exists']     = 'Avain sana on jo käytössä!';
