<?php
// Heading
$_['heading_title']     = 'Theme Editor';

// Text
$_['text_success']      = 'Menestys: olet muokannut teemoja!';
$_['text_edit']         = 'Teeman muokkaaminen';
$_['text_store']        = 'Valitse myymäläsi';
$_['text_template']     = 'Valitse malli';
$_['text_default']      = 'Oletus';
$_['text_history']      = 'Teema historia';
$_['text_twig']         = 'Teema editori käyttää malli kielen oksa. Voit lukea <a href="http://twig.sensiolabs.org/documentation" target="_blank" class="alert-link">TWIG syntaksi täällä</a>.';

// Column
$_['column_store']      = 'Store';
$_['column_route']      = 'Reitti';
$_['column_theme']      = 'Teema';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata Theme Editor!';
$_['error_twig']        = 'Varoitus: voit tallentaa vain. twig-tiedostoja!';