<?php
// Heading
$_['heading_title']    = 'Kieli editori';

// Text
$_['text_success']     = 'Menestys: olet muokannut kieli editori!';
$_['text_list']        = 'Käännös luettelo';
$_['text_edit']        = 'Muokkaa käännöstä';
$_['text_add']         = 'Lisää käännös';
$_['text_default']     = 'Oletus';
$_['text_store']       = 'Store';
$_['text_language']    = 'Kieli';

// Column
$_['column_store']     = 'Store';
$_['column_language']  = 'Kieli';
$_['column_route']     = 'Reitti';
$_['column_key']       = 'Avain';
$_['column_value']     = 'Arvo';
$_['column_action']    = 'Toiminta';

// Entry
$_['entry_store']      = 'Store';
$_['entry_language']   = 'Kieli';
$_['entry_route']      = 'Reitti';
$_['entry_key']        = 'Avain';
$_['entry_default']    = 'Oletus';
$_['entry_value']      = 'Arvo';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeutta muokata kieli editoria!';
$_['error_key']        = 'Avaimen on oltava välillä 3 ja 64 merkkiä!';
