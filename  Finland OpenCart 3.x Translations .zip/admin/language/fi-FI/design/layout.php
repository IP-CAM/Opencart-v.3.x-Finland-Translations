<?php
// Heading
$_['heading_title']       = 'Asettelujen';

// Text
$_['text_success']        = 'Menestys: olet muokannut ulkoasuja!';
$_['text_list']           = 'Asettelu luettelo';
$_['text_add']            = 'Lisää asettelu';
$_['text_edit']           = 'Muokkaa asettelua';
$_['text_remove']         = 'Poistaa';
$_['text_route']          = 'Valitse myymälä ja reitit, joita käytetään tämän asettelun kanssa';
$_['text_module']         = 'Valitse moduulien sijainti';
$_['text_default']        = 'Oletus';
$_['text_content_top']    = 'Sisältö ylhäällä';
$_['text_content_bottom'] = 'Sisällön pohja';
$_['text_column_left']    = 'Sarake vasemmalle';
$_['text_column_right']   = 'Sarake oikealle';

// Column
$_['column_name']         = 'Asettelun nimi';
$_['column_action']       = 'Toiminta';

// Entry
$_['entry_name']          = 'Asettelun nimi';
$_['entry_store']         = 'Store';
$_['entry_route']         = 'Reitti';
$_['entry_module']        = 'Moduuli';

// Error
$_['error_permission']    = 'Varoitus: sinulla ei ole oikeuksia muokata asetteluja!';
$_['error_name']          = 'Asettelun nimen on oltava välillä 3-64 merkkiä!';
$_['error_default']       = 'Varoitus: tätä asettelua ei voi poistaa, koska se on tällä hetkellä määritetty oletus säilön asetteluksi!';
$_['error_store']         = 'Varoitus: tätä asettelua ei voi poistaa, koska se on tällä hetkellä määritetty %s Tallentaa!';
$_['error_product']       = 'Varoitus: tätä asettelua ei voi poistaa, koska se on tällä hetkellä määritetty %s Tuotteet!';
$_['error_category']      = 'Varoitus: tätä asettelua ei voi poistaa, koska se on tällä hetkellä määritetty %s Luokat!';
$_['error_information']   = 'Varoitus: tätä asettelua ei voi poistaa, koska se on tällä hetkellä määritetty %s Tietoa sivuille!';