<?php
// Heading
$_['heading_title']       = 'Kupongit';

// Text
$_['text_success']        = 'Menestys: olet muokannut kuponkeja!';
$_['text_list']           = 'Kuponki luettelo';
$_['text_add']            = 'Lisää kuponki';
$_['text_edit']           = 'Muokkaa kuponkia';
$_['text_percent']        = 'Prosenttiosuus';
$_['text_amount']         = 'Kiinteä summa';
$_['text_coupon']         = 'Kupongin historia';

// Column
$_['column_name']         = 'Kupongin nimi';
$_['column_code']         = 'Koodi';
$_['column_discount']     = 'Alennus';
$_['column_date_start']   = 'Alkamis päivä';
$_['column_date_end']     = 'Päättymis päivä';
$_['column_status']       = 'Tila';
$_['column_order_id']     = 'Tilauksen tunnus';
$_['column_customer']     = 'Asiakas';
$_['column_amount']       = 'Summa';
$_['column_date_added']   = 'Päivä määrä lisätty';
$_['column_action']       = 'Toiminta';

// Entry
$_['entry_name']          = 'Kupongin nimi';
$_['entry_code']          = 'Koodi';
$_['entry_type']          = 'Tyyppi';
$_['entry_discount']      = 'Alennus';
$_['entry_logged']        = 'Asiakas login';
$_['entry_shipping']      = 'Ilmainen toimitus';
$_['entry_total']         = 'Kokonaissumma';
$_['entry_category']      = 'Luokka';
$_['entry_product']       = 'Tuotteet';
$_['entry_date_start']    = 'Alkamis päivä';
$_['entry_date_end']      = 'Päättymis päivä';
$_['entry_uses_total']    = 'Käyttää per kuponki';
$_['entry_uses_customer'] = 'Käyttää asiakasta kohden';
$_['entry_status']        = 'Tila';

// Help
$_['help_code']           = 'Koodi, jonka asiakas syöttää alennuksen saadakseen.';
$_['help_type']           = 'Prosentti osuus tai kiinteä summa.';
$_['help_logged']         = 'Asiakkaan on oltava kirjautuneena, jotta voit käyttää kuponkia.';
$_['help_total']          = 'Kokonaissumma, joka täytyy saavuttaa ennen kupongin voimassa olevaa summaa.';
$_['help_category']       = 'Valitse kaikki valitun luokan tuotteet.';
$_['help_product']        = 'Valitse tietyt tuotteet kuponki sovelletaan. Valitse ei tuotteita, jos haluat käyttää kuponkia koko kärryyn.';
$_['help_uses_total']     = 'Niiden kertojen enimmäismäärä, jolloin asiakas voi käyttää kuponkia. Jätä tyhjäksi rajoittamaton';
$_['help_uses_customer']  = 'Enimmäismäärä kertoja, jolloin yksittäinen asiakas voi käyttää kuponkia. Jätä tyhjäksi rajoittamaton';

// Error
$_['error_permission']    = 'Varoitus: sinulla ei ole oikeutta muokata kuponkeja!';
$_['error_exists']        = 'Varoitus: kuponki koodi on jo käytössä!';
$_['error_name']          = 'Kupongin nimi on välillä 3 ja 128 merkkiä!';
$_['error_code']          = 'Koodin on oltava 3-10 merkkiä pitkä!';