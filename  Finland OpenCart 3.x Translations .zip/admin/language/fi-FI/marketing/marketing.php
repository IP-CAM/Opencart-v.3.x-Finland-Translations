<?php
// Heading
$_['heading_title']     = 'Markkinoinnin seuranta';

// Text
$_['text_success']      = 'Menestys: olet muuttanut markkinoinnin seuranta!';
$_['text_list']         = 'Markkinoinnin seuranta luettelo';
$_['text_add']          = 'Lisää markkinointi seuranta';
$_['text_edit']         = 'Muokkaa markkinointi seurantaa';
$_['text_filter']       = 'Suodatin';
		
// Column
$_['column_name']       = 'Kampanjan nimi';
$_['column_code']       = 'Koodi';
$_['column_clicks']     = 'Napsautuksia';
$_['column_orders']     = 'Tilaukset';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Kampanjan nimi';
$_['entry_description'] = 'Kampanjan kuvaus';
$_['entry_code']        = 'Seurantakoodin';
$_['entry_example']     = 'Esimerkkejä';
$_['entry_date_added']  = 'Päivä määrä lisätty';

// Help
$_['help_code']         = 'Seuranta koodi, jota käytetään markkinointi kampanjoiden seurantaan.';
$_['help_example']      = 'Joten järjestelmä voi seurata viitta uksia sinun täytyy lisätä seuranta koodin loppuun URL linkin sivustoosi.';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata markkinoinnin seurantaa!';
$_['error_name']        = 'Kampanjan on oltava väliltä 1-32 merkkiä!';
$_['error_code']        = 'Seuranta koodi vaaditaan!';
$_['error_exists']      = 'Seuranta koodi on toisen kampanjan käytössä!';