<?php
// Heading
$_['heading_title']        = 'Mail';

// Text
$_['text_success']         = 'Viestisi on lähetetty onnistuneesti!';
$_['text_sent']            = 'Viestisi on lähetetty onnistuneesti %s ja %s Vastaanottajat!';
$_['text_list']            = 'Postitus lista';
$_['text_default']         = 'Oletus';
$_['text_newsletter']      = 'Kaikki uutis kirjeen tilaajille';
$_['text_customer_all']    = 'Kaikki asiakkaat';
$_['text_customer_group']  = 'Asiakas ryhmä';
$_['text_customer']        = 'Asiakkaat';
$_['text_affiliate_all']   = 'Kaikki kumppanit';
$_['text_affiliate']       = 'Tytäryhtiöiden';
$_['text_product']         = 'Tuotteet';

// Entry
$_['entry_store']          = 'Päässä';
$_['entry_to']             = 'Jotta';
$_['entry_customer_group'] = 'Asiakas ryhmä';
$_['entry_customer']       = 'Asiakas';
$_['entry_affiliate']      = 'Affiliate';
$_['entry_product']        = 'Tuotteet';
$_['entry_subject']        = 'Aihe';
$_['entry_message']        = 'Viesti';

// Help
$_['help_customer']        = 'AUtomaattinen täydennys';
$_['help_affiliate']       = 'AUtomaattinen täydennys';
$_['help_product']         = 'Lähetä vain asiakkaille, jotka ovat tilanneet tuotteita luettelossa. AUtomaattinen täydennys';

// Error
$_['error_permission']     = 'Varoitus: sinulla ei ole lupaa lähettää sähkö postia!';
$_['error_subject']        = 'E-Mail aihe tarvitaan!';
$_['error_message']        = 'E-Mail viesti tarvitaan!';