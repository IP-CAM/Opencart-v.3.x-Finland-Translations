<?php
// Heading
$_['heading_title']    = 'Varmuuskopiointi &amp; Palauttaa';

// Text
$_['text_success']     = 'Onnistui: tieto kanta on tuotu onnistuneesti.';

// Entry
$_['entry_progress']   = 'Edistystä';
$_['entry_export']     = 'Vienti';

// Tab
$_['tab_backup']       = 'Varmuuskopiointi';
$_['tab_restore']      = 'Palauttaa';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole oikeuksia muokata varmuus kopiota &amp; Palauttaa!';
$_['error_export']     = 'Varoitus: sinun on valittava vähintään yksi vietävä taulukko!';
$_['error_file']       = 'Tiedostoa ei löytynyt!';
