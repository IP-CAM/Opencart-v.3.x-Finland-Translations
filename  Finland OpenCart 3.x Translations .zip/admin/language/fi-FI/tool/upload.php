<?php
// Heading
$_['heading_title']     = 'Lisätty';

// Text
$_['text_success']      = 'Menestys: olet muokannut lisätty!';
$_['text_list']         = 'Lataa luettelo';

// Column
$_['column_name']       = 'Lataa nimi';
$_['column_filename']   = 'Tiedostonimi';
$_['column_date_added'] = 'Päivä määrä lisätty';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_name']        = 'Lataa nimi';
$_['entry_filename']    = 'Tiedostonimi';
$_['entry_date_added']  = 'Päivä määrä lisätty';

// Error
$_['error_permission']  = 'Varoitus: sinulla ei ole oikeutta muokata uploads!';