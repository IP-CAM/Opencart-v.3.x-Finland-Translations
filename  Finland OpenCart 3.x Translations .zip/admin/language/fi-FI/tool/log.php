<?php
// Heading
$_['heading_title']    = 'Virhe lokin';

// Text
$_['text_success']     = 'Onnistui: olet onnistuneesti poistanut virhe lokin!';
$_['text_list']        = 'Virheet List';

// Error
$_['error_warning']    = 'Varoitus: virhe loki tiedostosi %s On %s!';
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa tyhjentää virhe lokin!';