<?php
// Text
$_['text_subject']  = '%s -Palkinto pistettä';
$_['text_received'] = 'Olet saanut %s Palkintopisteitä!';
$_['text_total']    = 'Palkinto pisteiden kokonaismäärä on nyt %s.';