<?php
// Text
$_['text_subject']       = '%s -Paluu päivitys %s';
$_['text_return_id']     = 'Paluu tunnus:';
$_['text_date_added']    = 'Paluu päivä:';
$_['text_return_status'] = 'Palautus on päivitetty seuraavaan tilaan:';
$_['text_comment']       = 'Kommentit paluu ovat:';
$_['text_footer']        = 'Ole hyvä ja vastaa tähän viestiin, jos sinulla on kysyttävää.';