<?php
// Text
$_['text_subject']  = '%s -Affiliate-tili on aktivoitu!';
$_['text_welcome']  = 'Tervetuloa ja Kiitos rekisteröitymisestä %s!';
$_['text_login']    = 'Tilisi on nyt hyväksytty ja voit kirja utua sisään käyttämällä Sähkö posti osoitettasi ja Sala sanaasi vierailemalla sivuillamme tai seuraavassa osoitteessa:';
$_['text_services'] = 'Sisäänkirjautumisen yhteydessä voit luoda seuranta koodeja, seurata provisio maksuja ja muokata tili tietojasi.';
$_['text_thanks']   = 'Kiitos';