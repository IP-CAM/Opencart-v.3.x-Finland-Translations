<?php
// Text
$_['text_success']  = 'Menestys: olet muokannut tositteita!';
$_['text_subject']  = 'Sinulle on lähetetty lahja kortti %s';
$_['text_greeting'] = 'Onnittelut, olet saanut lahja kortti arvoinen %s';
$_['text_from']     = 'Tämä lahja kortti on lähetetty sinulle %s';
$_['text_message']  = 'Avulla asia lausahtaen';
$_['text_redeem']   = 'Lunastaaksesi tämän lahja kortin, kirjoita lunastus koodi, joka on <b>%s</b> sitten klikkaa alla olevaa linkkiä ja ostaa tuote, jota haluat käyttää tätä lahja kortti. Voit syöttää lahja kortin koodin ostos koriin, ennen kuin klikkaat kassalle.';
$_['text_footer']   = 'Ole hyvä ja vastaa tähän viestiin, jos sinulla on kysyttävää.';