<?php
// Text
$_['text_subject']  = '%s -Affiliate Credit';
$_['text_received'] = 'Olet saanut %s Luotto!';
$_['text_total']    = 'Sinun luoton kokonaismäärä on nyt %s.';
$_['text_credit']   = 'Tilisi saldo voidaan vähentää seuraavasta ostosaldosta.';