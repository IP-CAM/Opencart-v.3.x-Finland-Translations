<?php
// Text
$_['text_subject'] = '%s -Tilisi on aktivoitu!';
$_['text_welcome'] = 'Tervetuloa ja Kiitos rekisteröitymisestä %s!';
$_['text_login']   = 'Tilisi on nyt luotu, ja voit kirja utua sisään käyttämällä Sähkö posti osoitettasi ja Sala sanaasi vierailemalla Web-sivuillamme tai seuraavassa osoitteessa:';
$_['text_service'] = 'Sisäänkirjautumisen yhteydessä voit käyttää muita palveluita, kuten aiempien tilausten tarkistamista, laskujen tulostamista ja tili tietojen muokkaamista.';
$_['text_thanks']  = 'Kiitos';