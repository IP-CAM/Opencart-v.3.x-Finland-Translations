<?php
// Text
$_['text_subject'] = '%s -Tilisi on evätty!';
$_['text_welcome'] = 'Tervetuloa ja Kiitos rekisteröitymisestä %s!';
$_['text_denied']  = 'Valitettavasti pyyntösi on evätty. Lisä tietoja voit ottaa yhteyttä kaupan omistaja tässä:';
$_['text_thanks']  = 'Kiitos';
