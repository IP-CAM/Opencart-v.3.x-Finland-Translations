<?php
// Text
$_['text_subject'] = '%s -Affiliate-tili on estetty!';
$_['text_welcome'] = 'Tervetuloa ja Kiitos rekisteröitymisestä %s!';
$_['text_denied']  = 'Valitettavasti pyyntösi on evätty. Lisä tietoja voit ottaa yhteyttä kaupan omistaja tässä:';
$_['text_thanks']  = 'Kiitos';