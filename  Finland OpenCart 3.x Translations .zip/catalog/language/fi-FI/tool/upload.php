<?php
// Text
$_['text_upload']    = 'Tiedoston lataaminen onnistui!';

// Error
$_['error_filename'] = 'Tiedosto nimen on oltava välillä 3-64 merkkiä!';
$_['error_filetype'] = 'Virheellinen tiedosto tyyppi!';
$_['error_upload']   = 'Upload tarvitaan!';