<?php

/**
 * @author Nayden
 * @copyright 2017
 */

$_['heading_title'] = 'Lisätty ostos koriin';