<?php
// Heading
$_['heading_title'] = 'Pyytämäsi sivu ei löydy!';

// Text
$_['text_error']    = 'Pyytämäsi sivun ei löydy.';