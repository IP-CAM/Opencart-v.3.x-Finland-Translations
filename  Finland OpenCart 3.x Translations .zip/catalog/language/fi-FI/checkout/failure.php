<?php
// Heading
$_['heading_title'] = 'Epäonnistunut maksu!';

// Text
$_['text_basket']   = 'Ostoskori';
$_['text_checkout'] = 'Kassalle';
$_['text_failure']  = 'Epäonnistunut maksu';
$_['text_message']  = '<p>Maksusi käsittelyssä oli ongelma, ja tilausta ei suoritettu loppuun.</p>

<p>Mahdollisia syitä ovat:</p>
<ul>
  <li>Riittämättömät varat</li>
  <li>Tarkistus epäonnistui</li>
</ul>

<p>Yritä tilata uudelleen käyttämällä toista maksu tapaa.</p>

<p>Jos ongelma toistuu, ota <a href="%s">Ota yhteyttä meihin</a> Kun tiedot tila uksen yrität sijoittaa.</p>
';