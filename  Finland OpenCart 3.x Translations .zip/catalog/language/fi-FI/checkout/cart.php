<?php
// Heading
$_['heading_title']            = 'Ostoskori';

// Text
$_['text_success']             = 'Onnistui: olet lisännyt <a href="%s">%s</a> tieto <a href="%s">Ostoskori</a>!';
$_['text_remove']              = 'Menestys: olet muokannut ostos koriisi!';
$_['text_login']               = 'Huomio: sinun on <a href="%s">Kirjaudu</a> Tai <a href="%s">Luo tili</a> nähdäksesi hinnat!';
$_['text_items']               = '%s tuote (t)- %s';
$_['text_points']              = 'Palkintopisteitä: %s';
$_['text_next']                = 'Mitä haluaisit tehdä seuraavaksi?';
$_['text_next_choice']         = 'Valitse, jos sinulla on alennus koodi tai palkinto pisteitä haluat käyttää tai haluat arvioida toimitus kulut.';
$_['text_empty']               = 'Ostos Korisi on tyhjä!';
$_['text_day']                 = 'Päivä';
$_['text_week']                = 'Viikolla';
$_['text_semi_month']          = 'puolen kuukauden';
$_['text_month']               = 'Kuukausi';
$_['text_year']                = 'Vuoden';
$_['text_trial']               = '%s Joka %s %s varten %s maksut sitten ';
$_['text_recurring']           = '%s Joka %s %s';
$_['text_payment_cancel']      = 'kunnes peruutettu';
$_['text_recurring_item']      = 'Toistuva nimike';
$_['text_payment_recurring']   = 'Maksu profiilia';
$_['text_trial_description']   = '%s Joka %d %s(t) %d Maksu (t) sitten';
$_['text_payment_description'] = '%s Joka %d %s(t) %d Maksu (t)';
$_['text_payment_cancel']      = '%s Joka %d %s(s) kunnes peruutettu';

// Column
$_['column_image']             = 'Kuva';
$_['column_name']              = 'Tuotteen nimi';
$_['column_model']             = 'Malli';
$_['column_quantity']          = 'Määrä';
$_['column_price']             = 'Yksikkö hinta';
$_['column_total']             = 'Yhteensä';

// Error
$_['error_stock']              = 'Tähdellä * * * merkityt tuotteet eivät ole saatavilla haluttuun määrään tai niitä ei ole varastossa!';
$_['error_minimum']            = 'Minimi tilaus summa %s On %s!';
$_['error_required']           = '%s Tarvitaan!';
$_['error_product']            = 'Varoitus: Ostoskorissasi ei ole tuotteita!';
$_['error_recurring_required'] = 'Valitse maksu toistuva!';