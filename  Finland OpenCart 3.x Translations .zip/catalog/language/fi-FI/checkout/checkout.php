<?php
// Heading
$_['heading_title']                  = 'Kassalle';

// Text
$_['text_cart']                      = 'Ostoskori';
$_['text_checkout_option']           = 'Vaihe %s: Checkout-asetukset';
$_['text_checkout_account']          = 'Vaihe %s: Tili &amp; Laskutus tiedot';
$_['text_checkout_payment_address']  = 'Vaihe %s: Laskutus tiedot';
$_['text_checkout_shipping_address'] = 'Vaihe %s: Toimituksen tiedot';
$_['text_checkout_shipping_method']  = 'Vaihe %s: Toimitus tapa';
$_['text_checkout_payment_method']   = 'Vaihe %s: Maksu tapa';
$_['text_checkout_confirm']          = 'Vaihe %s: Vahvista tilaus';
$_['text_modify']                    = 'Muokata &raquo;';
$_['text_new_customer']              = 'Uusi asiakas';
$_['text_returning_customer']        = 'Palaava asiakas';
$_['text_checkout']                  = 'Checkout-asetukset:';
$_['text_i_am_returning_customer']   = 'Olen palaava asiakas';
$_['text_register']                  = 'Rekisteröi tili';
$_['text_guest']                     = 'Vieras kassalle';
$_['text_register_account']          = 'Luomalla tilin voit tehdä ostoksia nopeammin, olla ajan tasalla tila uksen tilasta ja seurata aiemmin tehtyjä tila uksia.';
$_['text_forgotten']                 = 'Unohtunut sala sana';
$_['text_your_details']              = 'Henkilökohtaiset tietosi';
$_['text_your_address']              = 'Osoitteesi';
$_['text_your_password']             = 'Sala sanasi';
$_['text_agree']                     = 'Olen lukenut ja hyväksyn <a href="%s" class="agree"><b>%s</b></a>';
$_['text_address_new']               = 'Haluan käyttää uutta osoitetta';
$_['text_address_existing']          = 'Haluan käyttää aiemmin luotua osoitetta';
$_['text_shipping_method']           = 'Valitse tässä järjestyksessä käytettävä ensisijainen toimitus tapa.';
$_['text_payment_method']            = 'Valitse ensisijainen maksu tapa, jota käytetään tässä tila uksen yhteydessä.';
$_['text_comments']                  = 'Kommenttien lisääminen tila ukseen';
$_['text_recurring_item']            = 'Toistuva nimike';
$_['text_payment_recurring']         = 'Maksu profiilia';
$_['text_trial_description']         = '%s Joka %d %s(t) %d Maksu (t) sitten';
$_['text_payment_description']       = '%s Joka %d %s(t) %d Maksu (t)';
$_['text_payment_cancel']            = '%s Joka %d %s(s) kunnes peruutettu';
$_['text_day']                       = 'Päivä';
$_['text_week']                      = 'Viikolla';
$_['text_semi_month']                = 'puolen kuukauden';
$_['text_month']                     = 'Kuukausi';
$_['text_year']                      = 'Vuoden';

// Column
$_['column_name']                    = 'Tuotteen nimi';
$_['column_model']                   = 'Malli';
$_['column_quantity']                = 'Määrä';
$_['column_price']                   = 'Yksikkö hinta';
$_['column_total']                   = 'Yhteensä';

// Entry
$_['entry_email_address']            = 'Sähköpostiosoite';
$_['entry_email']                    = 'Sähköposti';
$_['entry_password']                 = 'Salasana';
$_['entry_confirm']                  = 'Sala sana Vahvista';
$_['entry_firstname']                = 'Etunimi';
$_['entry_lastname']                 = 'Suku nimi';
$_['entry_telephone']                = 'Puhelin';
$_['entry_address']                  = 'Valitse osoite';
$_['entry_company']                  = 'Yritys';
$_['entry_customer_group']           = 'Asiakas ryhmä';
$_['entry_address_1']                = 'Osoite 1';
$_['entry_address_2']                = 'Osoite 2';
$_['entry_postcode']                 = 'Posti numero';
$_['entry_city']                     = 'City';
$_['entry_country']                  = 'Maa';
$_['entry_zone']                     = 'Alue/osavaltio';
$_['entry_newsletter']               = 'Haluan allekirjoittaa %s Uutiskirje.';
$_['entry_shipping']                 = 'Toimitus-ja laskutus osoitteeni ovat samat.';

// Error
$_['error_warning']                  = 'Oli ongelma, kun yrittää käsitellä tilauksesi! Jos ongelma toistuu, kokeile valita toinen maksu tapa tai voit ottaa yhteyttä kaupan omistajaan <a href="%s">klikkaamalla tästä</a>.';
$_['error_login']                    = 'Varoitus: ei täsmää Sähkö posti osoite ja/tai sala sana.';
$_['error_attempts']                 = 'Varoitus: tilisi on ylittänyt sallitun kirjautumisyritysten määrän. Yritä uudelleen 1 tunnissa.';
$_['error_approved']                 = 'Varoitus: tilisi edellyttää hyväksyntää, ennen kuin voit kirja utua.';
$_['error_exists']                   = 'Varoitus: Sähkö posti osoite on jo rekisteröity!';
$_['error_firstname']                = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']                 = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']                    = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']                = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_password']                 = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']                  = 'Sala sanan vahvistus ei vastaa Sala sanaa!';
$_['error_address_1']                = 'Osoitteen 1 on oltava välillä 3 ja 128 merkkiä!';
$_['error_city']                     = 'Kaupungin on oltava välillä 2 ja 128 merkkiä!';
$_['error_postcode']                 = 'Posti numeron on oltava 2-10 merkkiä pitkä!';
$_['error_country']                  = 'Ole hyvä ja valitse maa!';
$_['error_zone']                     = 'Valitse alue/osavaltio!';
$_['error_agree']                    = 'Varoitus: sinun on hyväksyttävä %s!';
$_['error_address']                  = 'Varoitus: sinun on valittava osoite!';
$_['error_shipping']                 = 'Varoitus: toimitus tapa vaaditaan!';
$_['error_no_shipping']              = 'Varoitus: toimitus vaihtoehdot eivät ole käytettävissä. Ole hyvä <a href="%s">Ota yhteyttä meihin</a> apua!';
$_['error_payment']                  = 'Varoitus: maksu tapa vaaditaan!';
$_['error_no_payment']               = 'Varoitus: maksu vaihtoehtoja ei ole käytettävissä. Ole hyvä <a href="%s">Ota yhteyttä meihin</a> apua!';
$_['error_custom_field']             = '%s Tarvitaan!';