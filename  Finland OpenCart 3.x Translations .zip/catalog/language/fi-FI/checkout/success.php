<?php
// Heading
$_['heading_title']        = 'Tilauksesi on asetettu!';

// Text
$_['text_basket']          = 'Ostoskori';
$_['text_checkout']        = 'Kassalle';
$_['text_success']         = 'Menestys';
$_['text_customer']        = '<p>Tilauksesi on käsitelty onnistuneesti!</p><p>Voit tarkastella tilaus historiaa siirtymällä <a href="%s">Oma tilini</a> sivu ja klikkaamalla <a href="%s">Historia</a>.</p><p>Jos ostosi liittyy lataus, voit siirtyä tilin <a href="%s">Lataukset</a> -sivulla.</p><p>Ole hyvä ja suoraan kysyttävää sinulla on <a href="%s">myymälän omistaja</a>.</p><p>Kiitos ostoksia kanssamme online!</p>';
$_['text_guest']           = '<p>Tilauksesi on käsitelty onnistuneesti!</p><p>Ole hyvä ja suoraan kysyttävää sinulla on <a href="%s">myymälän omistaja</a>.</p><p>Kiitos ostoksia kanssamme online!</p>';