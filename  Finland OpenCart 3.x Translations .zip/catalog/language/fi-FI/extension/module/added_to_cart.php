<?php

/**
 * @author Nayden
 * @copyright 2017
 */

$_['text_sub_total'] = 'Ostos korin väli summa';
$_['text_total_items'] = '(%s kohteita';
$_['text_cart'] = 'Cart';
$_['text_checkout'] = 'Siirry kassalle (%s kohteita';
$_['text_added_to_cart'] = 'Lisätty ostos koriin';
$_['text_rating'] = 'Arvostelun';
$_['text_price'] = 'Hinta';
$_['text_model'] = 'Malli';
$_['text_name'] = 'Nimi';
$_['text_tax'] = 'Ex vero';