<?php
// Heading
$_['heading_title'] = 'Asiakkaat, jotka ostivat <a href="%s">%s</a> myös ostaneet';

// Text
$_['text_tax']      = 'Ex Tax:';