<?php
// Calculator
$_['text_checkout_title']      = 'Maksu erissä';
$_['text_choose_plan']         = 'Valitse suunnitelma';
$_['text_choose_deposit']      = 'Valitse talletus';
$_['text_monthly_payments']    = 'kuukausi maksut';
$_['text_months']              = 'Kuukautta';
$_['text_term']                = 'Termi';
$_['text_deposit']             = 'Talletus';
$_['text_credit_amount']       = 'Kustannukset luotto';
$_['text_amount_payable']      = 'Maksettavat velat yhteensä';
$_['text_total_interest']      = 'Korko yhteensä';
$_['text_monthly_installment'] = 'Kuukausittainen maksuerä';
$_['text_redirection']         = 'Sinut ohjataan divido suorittaa tämän rahoituksen hakemuksen, kun vahvistat tilauksesi';