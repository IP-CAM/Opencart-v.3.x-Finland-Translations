<?php
// Text
$_['text_estimate']    = 'Odotettu toimitus päivä:';
$_['text_estimate_note'] = 'Odotettu toimitus päivä on vain tiedoksi. Monet tekijät, jotka eivät ole meidän hallinnassa, voivat vaikuttaa todelliseen toimitus päivämäärään.';
?>