<?php
// Heading
$_['heading_title'] = 'Usein ostaneet yhdessä';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_this']     = 'Tämä kohde:';
$_['text_total_price'] = 'Kokonaishinta:';

// Button
$_['button_add_to_cart'] = 'Lisää kaikki ostos koriin';
$_['button_add_to_wishlist'] = 'Lisää kaikki toive listaan';