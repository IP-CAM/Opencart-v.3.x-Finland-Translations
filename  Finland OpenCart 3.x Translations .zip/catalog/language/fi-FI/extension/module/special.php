<?php
// Heading
$_['heading_title'] = 'Tarjoukset';

// Text
$_['text_tax']      = 'Ex Tax:';