<?php
// Heading
$_['heading_title'] = 'Huoneesta';

// Text
$_['text_contact']  = 'Ota yhteyttä meihin';
$_['text_sitemap']  = 'Sivu kartta';