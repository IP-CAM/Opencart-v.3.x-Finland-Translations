<?php
// Heading
$_['heading_title']    = 'Tili';

// Text
$_['text_register']    = 'Rekisteröidy';
$_['text_login']       = 'Kirjaudu';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Unohtunut sala sana';
$_['text_account']     = 'Oma tilini';
$_['text_edit']        = 'Muokkaa tiliä';
$_['text_password']    = 'Salasana';
$_['text_address']     = 'Osoite kirja';
$_['text_wishlist']    = 'Toivelista';
$_['text_order']       = 'Tilaus historia';
$_['text_download']    = 'Lataukset';
$_['text_reward']      = 'Palkintopisteitä';
$_['text_return']      = 'Palauttaa';
$_['text_transaction'] = 'Tapahtumat';
$_['text_newsletter']  = 'Uutiskirje';
$_['text_recurring']   = 'Toistuvat maksut';