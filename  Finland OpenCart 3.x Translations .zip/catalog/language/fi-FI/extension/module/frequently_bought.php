<?php
// Heading
$_['heading_title'] = 'Usein ostettu <a href="%s">%s</a>';

// Text
$_['text_tax']      = 'Ex Tax:';