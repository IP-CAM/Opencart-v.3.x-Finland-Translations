<?php
// Heading
$_['heading_title'] = 'Viimeksi katsottu';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_more'] = 'Katso lisää';