<?php
// Heading
$_['heading_title'] = 'Parhaimmiksi arvio idut';
// Text
$_['text_tax']      = 'Ex Tax:';

$_['text_received'] = '<span class="toprated">Olemme saaneet <span class="topratedtotalreviews">%d</span> arvosteluja, joiden keskimääräinen luokitus on <span class="topratedavgrating">%s</span>';
$_['text_view_all'] = 'Näytä kaikki';