<?php
// Heading
$_['heading_title'] = 'Viimeisin';

// Text
$_['text_tax']      = 'Ex Tax:';