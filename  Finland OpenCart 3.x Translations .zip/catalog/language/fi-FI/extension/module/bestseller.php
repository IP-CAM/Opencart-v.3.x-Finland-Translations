<?php
// Heading
$_['heading_title'] = 'Bestsellerit';

// Text
$_['text_tax']      = 'Ex Tax:';