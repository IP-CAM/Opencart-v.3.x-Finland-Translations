<?php
// Heading
$_['heading_title'] = 'Tarkenna hakua';