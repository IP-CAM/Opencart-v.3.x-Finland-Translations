<?php
// Heading
$_['heading_title'] = 'Suositella sinulle perustuu <a href="%s">%s</a>';

// Text
$_['text_tax']      = 'Ex Tax:';