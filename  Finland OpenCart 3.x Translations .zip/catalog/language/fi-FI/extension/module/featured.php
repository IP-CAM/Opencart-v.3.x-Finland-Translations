<?php
// Heading
$_['heading_title'] = 'Suositeltavat';

// Text
$_['text_tax']      = 'Ex Tax:';