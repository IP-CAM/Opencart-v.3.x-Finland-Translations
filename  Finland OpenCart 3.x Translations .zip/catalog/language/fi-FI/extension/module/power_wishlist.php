<?php
// Heading
$_['heading_title'] = 'Toivelista';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_more'] = 'Katso lisää';