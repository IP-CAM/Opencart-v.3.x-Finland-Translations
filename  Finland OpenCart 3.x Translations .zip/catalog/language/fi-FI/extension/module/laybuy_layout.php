<?php
// Heading
$_['heading_title']            = 'Myy-Osta Tietoa';

// Text
$_['text_reference_info']      = 'Viite tiedot';
$_['text_laybuy_ref_no']       = 'Myy-Osta viite tunnus:';
$_['text_paypal_profile_id']   = 'PayPal-profiilin tunnus:';
$_['text_payment_plan']        = 'Maksu suunnitelma';
$_['text_status']              = 'Tila:';
$_['text_amount']              = 'Summa:';
$_['text_downpayment_percent'] = 'Maksu prosentti:';
$_['text_months']              = 'Kuukautta:';
$_['text_downpayment_amount']  = 'Maksun määrä:';
$_['text_payment_amounts']     = 'Maksujen summat:';
$_['text_first_payment_due']   = 'Ensimmäinen maksu erääntyy:';
$_['text_last_payment_due']    = 'Viimeinen erääntyy maksu:';
$_['text_downpayment']         = 'Alas maksu';
$_['text_month']               = 'Kuukausi';

// Column
$_['column_instalment']        = 'Erä';
$_['column_amount']            = 'Summa';
$_['column_date']              = 'Päivämäärä';
$_['column_pp_trans_id']       = 'PayPal tapahtuma ID';
$_['column_status']            = 'Tila';