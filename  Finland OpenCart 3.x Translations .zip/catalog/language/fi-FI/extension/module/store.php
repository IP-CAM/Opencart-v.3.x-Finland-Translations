<?php
// Heading
$_['heading_title'] = 'Valitse myymälä';

// Text
$_['text_default']  = 'Oletus';
$_['text_store']    = 'Ole hyvä ja valitse myymälä, jonka haluat käydä.';