<?php



// Heading



$_['heading_title'] = 'Arvion perusteella';



$_['text_average'] = 'Keskiarvo';



$_['text_author'] = '';



$_['text_rating'] = 'Arvostelun';



$_['text_view_all'] = 'Lue lisää arvosteluja';