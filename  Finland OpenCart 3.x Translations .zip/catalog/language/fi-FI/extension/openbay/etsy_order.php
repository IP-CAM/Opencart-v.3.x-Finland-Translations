<?php
// Text
$_['text_total_shipping'] = 'Toimitus';
$_['text_total_discount'] = 'Alennus';
$_['text_total_tax']      = 'Vero';
$_['text_total_sub']      = 'Väli summa';
$_['text_total']          = 'Yhteensä';