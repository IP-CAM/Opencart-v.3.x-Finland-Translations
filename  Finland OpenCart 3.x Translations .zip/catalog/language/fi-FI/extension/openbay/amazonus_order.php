<?php
// Text
$_['text_paid_amazon'] 			= 'Maksettu Amazon';
$_['text_total_shipping'] 		= 'Toimitus';
$_['text_total_shipping_tax'] 	= 'Toimitus vero';
$_['text_total_giftwrap'] 		= 'Lahja paperia';
$_['text_total_giftwrap_tax'] 	= 'Lahja paperia vero';
$_['text_total_sub'] 			= 'Väli summa';
$_['text_tax'] 					= 'Vero';
$_['text_total'] 				= 'Yhteensä';
$_['text_gift_message'] 		= 'Lahja viestejä';
