<?php
// Text
$_['text_title']                = 'Square';
$_['text_canceled']             = 'Menestys: olet onnistuneesti peruuttanut tämän maksun! Lähetimme sinulle vahvistus Sähkö posti viestin.';
$_['text_confirm_cancel']       = 'Haluatko varmasti peruuttaa toistuvat maksut?';
$_['text_order_history_cancel'] = 'Olet peruuttanut toistuvan profiilisi. Korttiasi ei enää veloiteta.';

// Button
$_['button_cancel']             = 'Peruuta toistuva maksu';

// Error
$_['error_not_cancelled']       = 'Virhe: %s';
$_['error_not_found']           = 'Toistuvan profiilin peruuttaminen ei onnistunut';