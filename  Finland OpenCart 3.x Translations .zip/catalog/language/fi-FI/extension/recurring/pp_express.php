<?php
// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Menestys: olet onnistuneesti kanaon tämä maksu!';

// Button
$_['button_cancel']       = 'Peruuta toistuva maksu';

// Error
$_['error_not_cancelled'] = 'Virhe: %s';
$_['error_not_found']     = 'Toistuvan profiilin peruuttaminen ei onnistunut';