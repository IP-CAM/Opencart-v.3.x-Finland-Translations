<?php
// Heading
$_['heading_title']         = 'Sazepay suorat kortit';

// Text
$_['text_empty']		    = 'Sinulla ei ole tallennettuja kortteja';
$_['text_account']          = 'Tili';
$_['text_card']			    = 'Sazepay suora kortin hallinta';
$_['text_fail_card']	    = 'Oli kysymys poistamalla sazepay kortin, ota yhteyttä Shop Administrator apua.';
$_['text_success_card']     = 'Sazepay kortti onnistuneesti poistettu';
$_['text_success_add_card'] = 'Sazepay-kortti lisättiin onnistuneesti';

// Column
$_['column_type']		    = 'Kortin tyyppi';
$_['column_digits']	        = 'Viimeiset numerot';
$_['column_expiry']		    = 'Sovittaa';

// Entry
$_['entry_cc_owner']        = 'Kortin omistaja';
$_['entry_cc_type']         = 'Kortin tyyppi';
$_['entry_cc_number']       = 'Kortin numero';
$_['entry_cc_expire_date']  = 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']         = 'Kortin turva koodi (CVV2)';
$_['entry_cc_choice']       = 'Valitse olemassa oleva kortti';

// Button
$_['button_add_card']       = 'Lisää kortti';
$_['button_new_card']       = 'Lisää uusi kortti';



