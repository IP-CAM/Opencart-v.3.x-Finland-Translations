<?php

$_['heading_title'] = 'Square luotto kortit';

$_['text_account'] = 'Tili';
$_['text_back'] = 'Bck';
$_['text_delete'] = 'Poista';
$_['text_no_cards'] = 'Tieto kantaan ei ole tallennettu yhtään korttia.';
$_['text_card_ends_in'] = '%s kortti päättyy &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card'] = 'Vahvistatko, että haluat poistaa tämän kortin? Voit lisätä sen myöhemmin uudelleen seuraavaan kassalle.';
$_['text_success_card_delete'] = 'Menestys! Tämä kortti on poistettu.';