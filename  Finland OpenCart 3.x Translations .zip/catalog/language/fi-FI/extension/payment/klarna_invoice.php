<?php
// Text
$_['text_title']				= 'Klarna lasku-maksa 14 päivän sisällä';
$_['text_terms_fee']			= '<span id="klarna_invoice_toc"></span> (+%s)<script type="text/javascript">var ehdot = uusi Klarna. terms. Invoice ({El: \' klarna_invoice_toc \', Eid: \'%s", maa:"%s\', Charge: %s});</script>';
$_['text_terms_no_fee']			= '<span id="klarna_invoice_toc"></span><script type="text/javascript">var ehdot = uusi Klarna. terms. Invoice ({El: \' klarna_invoice_toc \', Eid: \'%s", maa:"%s\'});</script>';
$_['text_additional']			= 'Klarna lasku vaatii joitakin lisä tietoja ennen kuin he voivat Process tilauksesi.';
$_['text_male']					= 'Mies';
$_['text_female']				= 'Naisten';
$_['text_year']					= 'Vuoden';
$_['text_month']				= 'Kuukausi';
$_['text_day']					= 'Päivä';
$_['text_comment']				= 'Klarna laskun tunnus: %s. ' . "\n" . '%s/%s: %.4f';

// Entry
$_['entry_gender']				= 'Sukupuoli';
$_['entry_pno']					= 'Henkilökohtainen numero';
$_['entry_dob']					= 'Syntymäpäivämäärä';
$_['entry_phone_no']			= 'Puhelinnumero';
$_['entry_street']				= 'Street';
$_['entry_house_no']			= 'House No.';
$_['entry_house_ext']			= 'House ext.';
$_['entry_company']				= 'Yrityksen rekisteri numero';

// Help
$_['help_pno']					= 'Kirjoita sosiaaliturvatunnus tähän.';
$_['help_phone_no']				= 'Anna Puhelin numerosi.';
$_['help_street']				= 'Huomaathan, että toimitus voidaan tehdä vain rekisteröityyn osoitteeseen, kun maksat Klarna-puhelimellasi.';
$_['help_house_no']				= 'Kirjoita talo numerosi.';
$_['help_house_ext']			= 'Ole hyvä ja lähetä talo laajennus täällä. Esimerkiksi A, B, C, punainen, sininen ect.';
$_['help_company']				= 'Anna yrityksesi rekisteri numero';

// Error
$_['error_deu_terms']			= 'Sinun on hyväksyttävä Klarna tieto suoja käytäntö (datenschutz)';
$_['error_address_match']		= 'Laskutus-ja toimitus osoitteiden on vastattava toisiaan, jos haluat käyttää Klarna-laskua';
$_['error_network']				= 'Virhe muodostettaessa yhteyttä Klarna-kohteeseen. Yritä myöhemmin uudelleen.';