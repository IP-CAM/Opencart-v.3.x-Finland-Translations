<?php
// Text
$_['text_title']				= 'Luotto-tai pankki kortilla';
$_['text_credit_card']			= 'Luottokorttitiedot';
$_['text_wait']					= 'Ole hyvä ja odota!';

// Entry
$_['entry_cc_number']			= 'Kortin numero';
$_['entry_cc_name']				= 'Kortin haltijan nimi';
$_['entry_cc_expire_date']		= 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']				= 'Kortin turva koodi (CVV2)';

// Help
$_['help_start_date']			= '(jos saatavilla)';
$_['help_issue']				= '(vain Maestro ja Solo-kortit)';

// Text
$_['text_result']				= 'Tulos: ';
$_['text_approval_code']		= 'Hyväksymis koodi: ';
$_['text_reference_number']		= 'Viite: ';
$_['text_card_number_ref']		= 'Kortti viimeiset 4 numeroa: xxxx ';
$_['text_card_brand']			= 'Kortin merkki: ';
$_['text_response_code']		= 'Vastaus koodi: ';
$_['text_fault']				= 'Virhe sanoma: ';
$_['text_error']				= 'Virhesanoma: ';
$_['text_avs']					= 'Osoitteen varmistus: ';
$_['text_address_ppx']			= 'Ei osoite tietoja tai osoite ei tarkastaa kortin myöntäjä';
$_['text_address_yyy']			= 'Kortin myöntäjä vahvisti, että katu-ja posti numero vastaavat heidän ennätyksiä';
$_['text_address_yna']			= 'Kortin myöntäjä vahvisti, että katu ottelut tietueensa kanssa, mutta posti numero ei täsmää';
$_['text_address_nyz']			= 'Kortin myöntäjä vahvisti, että posti numero vastaa niiden tietueita, mutta katu ei vastaa';
$_['text_address_nnn']			= 'Sekä katu-että posti numero eivät täsmää kortin myöntäjän tietueiden kanssa';
$_['text_address_ypx']			= 'Kortin myöntäjä vahvisti, että katu ottelut niiden kirjaa. Myöntäjä ei tarkista posti numeroa';
$_['text_address_pyx']			= 'Kortin myöntäjä vahvisti, että posti numero vastaa heidän tietueitaan. Liikkeeseenlaskija ei tarkista kadun';
$_['text_address_xxu']			= 'Kortin myöntäjä ei tarkista AVS-tietoja';
$_['text_card_code_verify']		= 'Suoja koodi: ';
$_['text_card_code_m']			= 'Kortin suoja koodi täsmää';
$_['text_card_code_n']			= 'Kortin suoja koodi ei täsmää';
$_['text_card_code_p']			= 'Ei käsitelty';
$_['text_card_code_s']			= 'Kauppias on ilmoittanut, että kortin turva koodi ei ole läsnä kortilla';
$_['text_card_code_u']			= 'Liikkeeseenlaskija ei ole sertifioitu ja/tai ei ole toimittanut salaus avaimia';
$_['text_card_code_x']			= 'Luotto kortti yhdistykselle ei saatu vastausta';
$_['text_card_code_blank']		= 'Tyhjän vasta uksen tulee osoittaa, että koodia ei ole lähetetty ja että ei ollut viitteitä siitä, että koodia ei ollut kortissa.';
$_['text_card_accepted']		= 'Hyväksytyt kortit: ';
$_['text_card_type_m']			= 'Mastercard';
$_['text_card_type_v']			= 'Visa (luotto/pankki/Electron/Delta)';
$_['text_card_type_c']			= 'Diners';
$_['text_card_type_a']			= 'American Express';
$_['text_card_type_ma']			= 'Maestro';
$_['text_card_new']				= 'Uusi kortti';
$_['text_response_proc_code']	= 'Suorittimen koodi: ';
$_['text_response_ref']			= 'Viite numero: ';

// Error
$_['error_card_number']			= 'Tarkista korttisi numero on voimassa';
$_['error_card_name']			= 'Tarkista, että kortin haltijan nimi on voimassa';
$_['error_card_cvv']			= 'Tarkista CVV2 on voimassa';
$_['error_failed']				= 'Voi käsitellä maksusi, ota yhteyttä kauppias';