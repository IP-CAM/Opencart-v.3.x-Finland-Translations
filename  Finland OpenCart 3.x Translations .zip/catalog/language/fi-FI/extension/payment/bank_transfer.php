<?php
// Text
$_['text_title']       = 'Pankkisiirto';
$_['text_instruction'] = 'Pankki siirto-ohjeet';
$_['text_description'] = 'Siirrä kokonaissumma seuraavalle pankki tilille.';
$_['text_payment']     = 'Tilauksesi ei toimita ennen kuin olemme saaneet maksun.';