<?php
// Text
$_['text_title'] = 'Luotto kortti/pankki kortti (payza)';