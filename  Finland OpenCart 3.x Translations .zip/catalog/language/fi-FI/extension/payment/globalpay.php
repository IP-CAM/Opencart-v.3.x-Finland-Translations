<?php
// Heading
$_['text_title']				= 'Luotto-/Pankkikortti (globalpay)';

// Button
$_['button_confirm']			= 'Vahvista';

// Entry
$_['entry_cc_type']				= 'Kortin tyyppi';

// Text
$_['text_success']				= 'Maksusi on hyväksytty.';
$_['text_decline']				= 'Maksusi epäonnistui';
$_['text_bank_error']			= 'Virhe käsiteltäessä pyyntöä pankin kanssa.';
$_['text_generic_error']		= 'Pyyntösi käsittelyssä tapahtui virhe.';
$_['text_hash_failed']			= 'Hajautus tarkistus epäonnistui. Älä yritä maksua uudelleen, koska maksun tila on tuntematon. Otathan yhteyttä myyjään.';
$_['text_link']					= 'Ole hyvä ja klikkaa <a href="%s">Täällä</a> jatkamaan';
$_['text_select_card']			= 'Valitse korttisi tyyppi';
$_['text_result']				= 'Todennus tulos';
$_['text_message']				= 'Viesti';
$_['text_cvn_result']			= 'CVN-tulos';
$_['text_avs_postcode']			= 'AVS posti numero';
$_['text_avs_address']			= 'AVS osoite';
$_['text_eci']					= 'ECI-tulos (3D Secure)';
$_['text_tss']					= 'TSS:n tulos';
$_['text_order_ref']			= 'Tilaa REF';
$_['text_timestamp']			= 'Aikaleima';
$_['text_card_type']			= 'Kortin tyyppi';
$_['text_card_digits']			= 'Kortin numero';
$_['text_card_exp']				= 'Kortti vanhenee';
$_['text_card_name']			= 'Kortin nimi';
$_['text_3d_s1']				= 'Kortin haltija ei ilmoittautunut, vastuu muutos';
$_['text_3d_s2']				= 'Ei voi tarkistaa ilmoittautumista, ei vastuu vuoroa';
$_['text_3d_s3']				= 'Virheellinen vasta uksen rekisteröinti palvelimesta, ei vastuu siirtymistä';
$_['text_3d_s4']				= 'Kirjoilla, mutta virheellinen vastaus ACS (Access Control Server), ei vastuuta siirtyminen';
$_['text_3d_s5']				= 'Onnistunut todennus, vastuu muutos';
$_['text_3d_s6']				= 'Todennus yritys tunnusti, vastuu muutos';
$_['text_3d_s7']				= 'Virheellinen sala sana annettu, ei vastuuta Shift';
$_['text_3d_s8']				= 'Todennus ei ole käytettävissä, ei vastuu siirtymistä';
$_['text_3d_s9']				= 'Virheellinen ACS:n vastaus, ei vastuu siirtymistä';
$_['text_3d_s10']				= 'Realmpi kohtalokas virhe, ei vastuuta Shift';
$_['text_3d_liability']     	= 'Ei vastuuta Shift';
$_['text_card_visa']			= 'Visa';
$_['text_card_mc']				= 'Mastercard';
$_['text_card_amex']			= 'American Express';
$_['text_card_switch']			= 'Kytkin';
$_['text_card_laser']			= 'Laser';
$_['text_card_diners']			= 'Diners';