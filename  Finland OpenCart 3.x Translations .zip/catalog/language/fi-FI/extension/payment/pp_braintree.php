<?php
// Text
$_['text_title']						= 'Kortteja tai PayPal';
$_['text_express_title']      			= 'Vahvista tilaus';
$_['text_vaulted_payment_method_name']	= '%s päättyen %sPäättyy %s';
$_['text_remember']						= 'Tallennetaanko seuraavan kerran?';
$_['text_remove']						= 'Poistaa';
$_['text_remove_confirm']				= 'Haluatko varmasti poistaa tallennetun maksu tavan?';
$_['text_month']						= 'Kuukausi';
$_['text_year']							= 'Vuoden';
$_['text_loading']						= 'Lastaus...';
$_['text_new_method']					= 'Uusi maksu tapa';
$_['text_saved_method']					= 'Valitse tallennettu maksu tapa';
$_['text_paypal']						= 'Paypal';
$_['text_pay_by_paypal']				= 'Maksaa PayPal';
$_['text_method_removed']				= 'Maksu tapa on poistettu';
$_['text_method_not_removed']			= 'Maksu tapaa ei voi poistaa';
$_['text_authentication']				= 'Todennus';
$_['text_cart']               			= 'Ostoskori';
$_['text_shipping_updated']   			= 'Lähetys palvelu päivitetty';

// Entry
$_['entry_new']							= 'Uusi maksu tapa';
$_['entry_saved_methods']				= 'Tallennettu maksu tapa';
$_['entry_card']						= 'Kortin numero';
$_['entry_expires']						= 'Vanhenee';
$_['entry_cvv']							= 'Cvv';
$_['entry_remember_card_method']		= 'Muista kortti?';
$_['entry_remember_paypal_method']		= 'Muista PayPal-tili?';
$_['entry_card_placeholder']			= 'Kortin numero';
$_['entry_month_placeholder']			= 'Kuukausi (mm)';
$_['entry_year_placeholder']			= 'Vuosi (vvvv)';
$_['entry_cvv_placeholder']				= 'CVV2';

// Error
$_['error_process_order']				= 'Tila uksen käsittelyssä tapahtui virhe. Pyydä apua kaupan ylläpitäjältä.';
$_['error_alert_fields_empty']			= 'Kaikki kentät ovat tyhjiä! Ole hyvä ja täytä lomake';
$_['error_alert_fields_invalid']		= 'Jotkin kentät eivät kelpaa, tarkista tietosi';
$_['error_alert_failed_token']			= 'Maksupalveluntarjoaja ei tunnista korttia. Onko kortti voimassa?';
$_['error_alert_failed_network']		= 'Tapahtui verkko virhe, yritä uudelleen';
$_['error_alert_unknown']				= 'Tapahtui tuntematon virhe, jos ongelma jatkuu, ota yhteyttä tukeen';
$_['error_unavailable'] 	  			= 'Käyttäkää koko kassalle tämän tila uksen';
$_['error_no_shipping']    				= 'Varoitus: toimitus vaihtoehdot eivät ole käytettävissä.';

// Button
$_['button_confirm']					= 'Maksa nyt';
$_['button_express_confirm']  			= 'Vahvista';
$_['button_express_shipping'] 			= 'Päivitä lähetys';
