<?php
$_['text_title'] = 'Luotto-tai maksu kortti';
$_['text_card_details'] = 'Kortin tiedot';
$_['text_wait'] = 'Maksun käsittely';
$_['text_auth_code'] = 'Lupa koodi: %s';
$_['text_postcode_check'] = 'Posti numeron tarkistus: %s';
$_['text_security_code_check'] = 'CVV2 Tarkista: %s';
$_['text_address_check'] = 'Osoitteen tarkistus: %s';
$_['text_3d_secure_check'] = '3D Secure: %s';
$_['text_not_given'] = 'Ole annettu';
$_['text_not_checked'] = 'Ei tarkastettu';
$_['text_match'] = 'Hyväksytty';
$_['text_not_match'] = 'Ei hyväksytty';
$_['text_authenticated'] = 'Todennettu';
$_['text_not_authenticated'] = 'Ei todennettu';
$_['text_authentication_not_completed'] = 'Yritetty, mutta ei valmistunut';
$_['text_unable_to_perform'] = 'Pysty suorittamaan';
$_['text_transaction_declined'] = 'Pankkisi on hylännyt tapahtuman. Käytä toista maksu tapaa.';
$_['text_transaction_failed'] = 'Maksua ei voitu käsitellä. Ole hyvä ja Tarkista tiedot olet antanut.';
$_['text_connection_error'] = 'Yritä myöhemmin uudelleen tai käytä toista maksu tapaa.';

$_['entry_type'] = 'Kortin tyyppi';
$_['entry_number'] = 'Kortin numero';
$_['entry_expire_date'] = 'Päättymispäivä';
$_['entry_cvv2'] = 'Suoja koodi (CVV2)';

$_['button_confirm'] = 'Vahvista';

$_['error_failure'] = 'Tapahtumaa ei voitu suorittaa loppuun. Yritä myöhemmin uudelleen tai käytä toista maksu tapaa.';