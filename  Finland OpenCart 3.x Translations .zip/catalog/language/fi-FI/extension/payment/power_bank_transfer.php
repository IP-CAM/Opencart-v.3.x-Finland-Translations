<?php
// Text
$_['text_title']       = 'Power pankki siirto';
$_['text_instruction'] = 'Power pankki siirto ohjeet';
$_['text_description'] = 'Siirrä kokonaissumma seuraavalle pankki tilille.';
$_['text_payment']     = 'Tilauksesi ei toimita ennen kuin olemme saaneet maksun.';