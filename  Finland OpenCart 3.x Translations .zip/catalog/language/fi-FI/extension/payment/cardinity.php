<?php
// Text
$_['text_title']						= 'Luotto kortti/pankki kortti (cardinity)';
$_['text_payment_success']				= 'Maksaminen onnistui, tiedot alla';
$_['text_payment_failed']				= 'Maksu epäonnistui, tiedot alla';

// Entry
$_['entry_holder']						= 'Kortin haltijan nimi';
$_['entry_pan']							= 'Kortin numero';
$_['entry_expires']						= 'Päättyy';
$_['entry_exp_month']					= 'Kuukausi';
$_['entry_exp_year']					= 'Vuoden';
$_['entry_cvc']							= 'Cvc';

// Error
$_['error_process_order']				= 'Tila uksen käsittelyssä tapahtui virhe. Pyydä apua kaupan ylläpitäjältä.';
$_['error_invalid_currency']			= 'Käytä kelvollista valuuttaa.';
$_['error_finalizing_payment']			= 'Virhe viimeistellään maksua.';
$_['error_unknown_order_id']			= 'Kardinity-maksua ei löytynyt tällä order_id.';
$_['error_invalid_hash']				= 'Hajautus arvo ei kelpaa.';
$_['error_payment_declined']			= 'Maksu hylättiin myöntäneen pankin toimesta.';

// Button
$_['button_confirm']					= 'Maksa nyt';