<?php
// Text
$_['text_title']            = 'Luotto kortti/pankki kortti';
$_['text_card_details']     = 'Kortin tiedot';
$_['text_echeck_details']   = 'eCheck-tiedot';
$_['text_card']             = 'Kortti';
$_['text_echeck']           = 'Echeck';
$_['text_wait']             = 'Ole hyvä ja odota!';
$_['text_confirm_delete']   = 'Haluatko varmasti poistaa kortin?';
$_['text_no_cards']         = 'Ei vielä tallennettuja kortteja';
$_['text_select_card']      = 'Valitse kortti';

// Entry
$_['entry_method']          = 'Menetelmä';
$_['entry_card_new_or_old'] = 'Uusi/nykyinen kortti';
$_['entry_card_new']        = 'Uusi';
$_['entry_card_old']        = 'Olemassa oleva';
$_['entry_card_type']       = 'Kortin tyyppi';
$_['entry_card_number']     = 'Kortin numero';
$_['entry_card_expiry']     = 'Sovittaa';
$_['entry_card_cvv2']       = 'CVV2';
$_['entry_card_save']       = 'Tallenna kortti';
$_['entry_card_choice']     = 'Valitse korttisi';
$_['entry_account_number']  = 'Tili numero';
$_['entry_routing_number']  = 'Reititys numeron';

// Button
$_['button_confirm']        = 'Vahvista tilaus';
$_['button_delete']         = 'Poista valittu kortti';

// Error
$_['error_card_number']     = 'Kortin numeron on oltava 1-19 merkkiä pitkä!';
$_['error_card_type']       = 'Kortti tyyppi ei ole kelvollinen valinta!';
$_['error_card_cvv2']       = 'CVV2 on oltava välillä 1 ja 4 merkkiä!';
$_['error_data_missing']    = 'Puuttuvat tiedot!';
$_['error_not_logged_in']   = 'Ei kirjautuneena sisään!';
$_['error_no_order']        = 'Ei vastaavaa järjestystä!';
$_['error_no_post_data']    = 'Ei $_POST Tietoja';
$_['error_select_card']     = 'Ole hyvä ja valitse kortti!';
$_['error_no_card']         = 'Tällaista korttia ei löytynyt!';
$_['error_no_echeck']       = 'eCheck-valmistetta ei tueta!';
$_['error_account_number']  = 'Tili numeron on oltava 1-19 merkkiä pitkä!';
$_['error_routing_number']  = 'Reititys numeron on oltava 1-9 merkkiä pitkä.';
$_['error_not_enabled']     = 'Moduulia ei ole otettu käyttöön';