<?php
// Text
$_['text_title']				= 'Luotto-tai pankki kortilla';
$_['text_secure_connection']	= 'Luodaan suojattua yhteyttä...';

// Error
$_['error_connection']			= 'Ei voitu yhdistää PayPal. Pyydä apua liikkeen järjestelmänvalvojalta tai valitse toinen maksu tapa.';