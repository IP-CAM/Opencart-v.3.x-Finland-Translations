<?php
// Heading
$_['heading_title']				= 'Kiitos ostoksia %s.... ';

// Text
$_['text_title']				= 'Luotto kortti/pankki kortti (PayPoint)';
$_['text_response']				= 'Vastaus PayPoint:';
$_['text_success']				= '... maksusi saatiin onnistuneesti.';
$_['text_success_wait']			= '<b><span style="color: #FF0000">Ole hyvä ja odota...</span></b> Kun päätämme tilauksesi käsittelyn.<br>Jos et ole automaattisesti suunnattu uudelleen 10 sekunnissa, klikkaa <a href="%s">Täällä</a>.';
$_['text_failure']				= '... Maksusi on peruutettu!';
$_['text_failure_wait']			= '<b><span style="color: #FF0000">Ole hyvä ja odota...</span></b><br>Jos et ole automaattisesti suunnattu uudelleen 10 sekunnissa, klikkaa <a href="%s">Täällä</a>.';