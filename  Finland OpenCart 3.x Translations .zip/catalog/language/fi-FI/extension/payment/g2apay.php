<?php
// Text
$_['text_title'] = 'Luotto-/Pankkikortti/PayPal/lompakko (G2APay)';