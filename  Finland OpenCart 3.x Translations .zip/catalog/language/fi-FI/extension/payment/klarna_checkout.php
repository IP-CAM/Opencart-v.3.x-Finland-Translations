<?php
// Heading
$_['heading_title']				   = 'Klarna kassalle';
$_['heading_title_success']		   = 'Klarna Checkout-tilauksesi on asetettu!';

// Text
$_['text_title']				   = 'Klarna kassalle';
$_['text_basket']				   = 'Ostoskori';
$_['text_checkout']				   = 'Kassalle';
$_['text_success']				   = 'Menestys';
$_['text_choose_shipping_method']  = 'Valitse toimitus tapa';
$_['text_sales_tax']			   = 'Arvonlisäveron';
$_['text_newsletter']			   = 'Tilaa uutiskirjeemme';