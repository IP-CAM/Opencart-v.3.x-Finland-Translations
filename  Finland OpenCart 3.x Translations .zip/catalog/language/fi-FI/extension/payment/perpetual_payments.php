<?php
// Text
$_['text_title']				= 'Luotto-tai debit-kortti (käsitellään turvallisesti pysyvien maksujen avulla)';
$_['text_credit_card']			= 'Luottokorttitiedot';
$_['text_transaction']			= 'Tapahtuman tunnus:';
$_['text_avs']					= 'AVS/CVV:';
$_['text_avs_full_match']		= 'Täysi vastaavuus';
$_['text_avs_not_match']		= 'Ei hyväksytty';
$_['text_authorisation']		= 'Lupa koodi:';

// Entry
$_['entry_cc_number']			= 'Kortin numero';
$_['entry_cc_start_date']		= 'Kortti voimassa päivä määrästä';
$_['entry_cc_expire_date']		= 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']				= 'Kortin turva koodi (CVV2)';
$_['entry_cc_issue']			= 'Kortin myöntämis numero';

// Help
$_['help_start_date']			= '(jos saatavilla)';
$_['help_issue']				= '(vain Maestro ja Solo-kortit)';