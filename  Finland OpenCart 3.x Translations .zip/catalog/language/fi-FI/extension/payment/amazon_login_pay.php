<?php
// Heading
$_['heading_title']				= 'Amazon pay';
$_['heading_address']			= 'Ole hyvä ja valitse toimitus osoite';
$_['heading_payment']			= 'Valitse maksu tapa';
$_['heading_confirm']			= 'Tila uksen Yhteenveto';
// Text
$_['text_back']					= 'Bck';
$_['text_cart']					= 'Cart';
$_['text_confirm']				= 'Vahvista';
$_['text_continue']				= 'Jatkaa';
$_['text_lpa']					= 'Amazon pay';
$_['text_enter_coupon']			= 'Kirjoita kuponki koodi tähän. Jos sinulla ei ole sellaista, jätä se tyhjäksi.';
$_['text_coupon']				= 'Kupongin';
$_['text_tax_other']			= 'Verot/muut käsittely kulut';
$_['text_success_title']		= 'Tilauksesi on asetettu!';
$_['text_payment_success']		= 'Tilauksesi oli onnistuneesti sijoitettu. Tilaus tiedot ovat alla';
// Error
$_['error_payment_method']		= 'Valitse maksu tapa';
$_['error_shipping']			= 'Valitse toimitus tapa';
$_['error_shipping_address']	= 'Valitse toimitus osoite';
$_['error_shipping_methods']	= 'Virhe noudettaessa osoitetta Amazonista. Pyydä apua kaupan ylläpitäjältä.';
$_['error_no_shipping_methods'] = 'Valitulle osoitteelle ei ole toimitus asetuksia. Valitse toinen toimitus osoite.';
$_['error_process_order']		= 'Tila uksen käsittelyssä tapahtui virhe. Pyydä apua kaupan ylläpitäjältä.';
$_['error_login']				= 'Kirjautuminen epäonnistui';
$_['error_login_email']			= 'Kirjautuminen epäonnistui: %s tilin Sähkö posti osoite ei täsmää Amazon tilin Sähkö posti osoite';
$_['error_minimum']             = 'Minimi tilaus määrä Amazon Pay on %s!';
