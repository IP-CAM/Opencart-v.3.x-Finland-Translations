<?php
// Text
$_['text_title']       = 'Sekki/maksu määräys';
$_['text_instruction'] = 'Shekki-/maksu määräys ohjeet';
$_['text_payable']     = 'Tee maksettava: ';
$_['text_address']     = 'Lähetä: ';
$_['text_payment']     = 'Tilauksesi ei toimita ennen kuin olemme saaneet maksun.';