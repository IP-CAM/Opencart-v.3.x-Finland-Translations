<?php
// Text
$_['text_new_card']                     = '+ Lisää uusi kortti';
$_['text_loading']                      = 'Lastaus... Ole hyvä ja odota...';
$_['text_card_details']                 = 'Kortin tiedot';
$_['text_saved_card']                   = 'Käytä tallennettua korttia:';
$_['text_card_ends_in']                 = 'Maksa olemassa olevien %s kortti, joka päättyy xxxx xxxx xxxx %s';
$_['text_card_number']                  = 'Kortin numero:';
$_['text_card_expiry']                  = 'Kortin vanhenemis aika (kk/vv):';
$_['text_card_cvc']                     = 'Kortin suoja koodi (CVC):';
$_['text_card_zip']                     = 'Kortin posti numero:';
$_['text_card_save']                    = 'Tallennetaanko kortti myöhempää käyttöä varten?';
$_['text_trial']                        = '%s Joka %s %s varten %s maksut sitten ';
$_['text_recurring']                    = '%s Joka %s %s';
$_['text_length']                       = ' varten %s Maksut';
$_['text_cron_subject']                 = 'Square cron työn Yhteenveto';
$_['text_cron_message']                 = 'Tässä on luettelo kaikista cron tehtäviä suorittaa oman neliön laajennus:';
$_['text_squareup_profile_suspended']   = ' Toistuvat maksasi on keskeytetty. Ota meihin yhteyttä saadaksesi lisä tietoja.';
$_['text_squareup_trial_expired']       = ' Kokeilu jakso on vanhentunut.';
$_['text_squareup_recurring_expired']   = ' Toistuvat maksasi ovat vanhentuneet. Tämä oli viimeinen maksu.';
$_['text_cron_summary_token_heading']   = 'Access-tunnus sanoman päivitys:';
$_['text_cron_summary_token_updated']   = 'Käyttö tunnus sanoma päivitettiin onnistuneesti!';
$_['text_cron_summary_error_heading']   = 'Tapahtuma virheet:';
$_['text_cron_summary_fail_heading']    = 'Epäonnistuneet tapahtumat (profiilit keskeytettiin):';
$_['text_cron_summary_success_heading'] = 'Onnistuneet tapahtumat:';
$_['text_cron_fail_charge']             = 'Profiili <strong>#%s</strong> ei voitu ladata <strong>%s</strong>';
$_['text_cron_success_charge']          = 'Profiili <strong>#%s</strong> syytettiin <strong>%s</strong>';
$_['text_card_placeholder']             = 'Xxxx xxxx xxxx xxxx';
$_['text_cvv']                          = 'Cvv';
$_['text_expiry']                       = 'Kk/vv';
$_['text_default_squareup_name']        = 'Luotto-tai maksu kortti';
$_['text_token_issue_customer_error']   = 'Olemme kokeneet teknisen katkoksen meidän maksu järjestelmä. Yritä myöhemmin uudelleen.';
$_['text_token_revoked_subject']        = 'Neliömäinen käyttö tunnus on kumottu!';
$_['text_token_revoked_message']        = "Square maksu laajentaminen n pääsy neliön tili on kumottu kautta Square Dashboard. Sinun on tarkistettava sovelluksen tunniste tiedot laajennus asetuksissa ja muodostettava yhteys uudelleen.";
$_['text_token_expired_subject']        = 'Sinun Square Access Token on vanhentunut!';
$_['text_token_expired_message']        = "Neliönmuotoinen maksu laajennuksen käyttö tunnus, joka yhdistää sen neliö tiliin, on vanhentunut. Sinun täytyy tarkistaa sovelluksen tunniste tiedot ja cron Job on laajennus asetukset ja kytke uudelleen.";

// Error
$_['error_browser_not_supported']       = 'Virhe: maksu järjestelmä ei enää tue Web-selainta. Haluta ajantasaistaa eli apu eri ainoa.';
$_['error_card_invalid']                = 'Virhe: kortti ei kelpaa!';
$_['error_squareup_cron_token']         = 'Virhe: käyttö tunnus sanomaa ei voitu päivittää. Liitä neliön maksu laajennus kautta opencart admin paneeli.';

// Warning
$_['warning_test_mode']                 = 'Varoitus: eristetty tila on käytössä! Liike toimet näyttävät läpi, mutta mitään maksuja ei tehdä.';

// Statuses
$_['squareup_status_comment_authorized']    = 'Kortti tapahtuma on hyväksytty, mutta sitä ei ole vielä otettu.';
$_['squareup_status_comment_captured']      = 'Kortti tapahtuma valtuutettiin ja sittemmin vangittiin (eli valmistui).';
$_['squareup_status_comment_voided']        = 'Kortti tapahtuma oli valtuutettu ja myöhemmin mitätöity (eli peruutettu).   ';
$_['squareup_status_comment_failed']        = 'Kortti tapahtuma epäonnistui.';

// Override errors
$_['squareup_override_error_billing_address.country']       = 'Maksu osoitteen maa ei kelpaa. Muokkaa sitä ja yritä uudelleen.';
$_['squareup_override_error_shipping_address.country']      = 'Toimitus osoitteen maa ei kelpaa. Muokkaa sitä ja yritä uudelleen.';
$_['squareup_override_error_email_address']                 = 'Asiakkaan Sähkö posti osoite ei kelpaa. Muokkaa sitä ja yritä uudelleen.';
$_['squareup_override_error_phone_number']                  = 'Asiakkaan Puhelin numero ei kelpaa. Muokkaa sitä ja yritä uudelleen.';
$_['squareup_error_field']                                  = ' Kenttä: %s';