<?php
// Text
$_['text_title']				= 'Luotto kortti/debit-kortti (sazepay)';
$_['text_credit_card']			= 'Kortin tiedot';
$_['text_card_type']			= 'Kortin tyyppi: ';
$_['text_card_name']			= 'Kortin nimi: ';
$_['text_card_digits']			= 'Viimeiset numerot: ';
$_['text_card_expiry']			= 'Sovittaa: ';
$_['text_trial']				= '%s Joka %s %s varten %s maksut sitten ';
$_['text_recurring']			= '%s Joka %s %s';
$_['text_length']				= ' varten %s Maksut';
$_['text_fail_card']			= 'Oli kysymys poistamalla sazepay kortin, ota yhteyttä Shop Administrator apua.';
$_['text_confirm_delete']		= 'Haluatko varmasti poistaa kortin?';

// Entry
$_['entry_card']				= 'Uusi tai olemassa oleva kortti: ';
$_['entry_card_existing']		= 'Olemassa oleva';
$_['entry_card_new']			= 'Uusi';
$_['entry_card_save']			= 'Muista kortin tiedot';
$_['entry_cc_owner']			= 'Kortin omistaja';
$_['entry_cc_type']				= 'Kortin tyyppi';
$_['entry_cc_number']			= 'Kortin numero';
$_['entry_cc_expire_date']		= 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']				= 'Kortin turva koodi (CVV2)';
$_['entry_cc_choice']			= 'Valitse olemassa oleva kortti';

// Button
$_['button_delete_card']		= 'Poista valittu kortti';