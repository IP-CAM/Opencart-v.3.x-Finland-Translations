<?php
// Text
$_['text_title']	= 'Pankki kortti (MasterCard, Maestro, Visa, Visa Electron, American Express)';
$_['text_testmode']	= 'Varoitus: maksuyhdyskäytävä on eristetyssä tilassa. Tiliäsi ei veloiteta.';
$_['text_total']	= 'Toimitus, käsittely, alennukset & verot';