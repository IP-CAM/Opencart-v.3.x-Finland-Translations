<?php
// Heading
$_['text_title']				= 'Luotto-/Pankkikortti (ensimmäiset tiedot)';

// Button
$_['button_confirm']			= 'Jatkaa';

// Text
$_['text_new_card']				= 'Uusi kortti';
$_['text_store_card']			= 'Muista kortin tiedot';
$_['text_address_response']		= 'Osoitteen varmistus: ';
$_['text_address_ppx']			= 'Ei osoite tietoja tai osoite ei tarkastaa kortin myöntäjä';
$_['text_address_yyy']			= 'Kortin myöntäjä vahvisti, että katu-ja posti numero vastaavat heidän ennätyksiä';
$_['text_address_yna']			= 'Kortin myöntäjä vahvisti, että katu ottelut tietueensa kanssa, mutta posti numero ei täsmää';
$_['text_address_nyz']			= 'Kortin myöntäjä vahvisti, että posti numero vastaa niiden tietueita, mutta katu ei vastaa';
$_['text_address_nnn']			= 'Sekä katu-että posti numero eivät täsmää kortin myöntäjän tietueiden kanssa';
$_['text_address_ypx']			= 'Kortin myöntäjä vahvisti, että katu ottelut niiden kirjaa. Myöntäjä ei tarkista posti numeroa';
$_['text_address_pyx']			= 'Kortin myöntäjä vahvisti, että posti numero vastaa heidän tietueitaan. Liikkeeseenlaskija ei tarkista kadun';
$_['text_address_xxu']			= 'Kortin myöntäjä ei tarkista AVS-tietoja';
$_['text_card_code_verify']		= 'Suoja koodi: ';
$_['text_card_code_m']			= 'Kortin suoja koodi täsmää';
$_['text_card_code_n']			= 'Kortin suoja koodi ei täsmää';
$_['text_card_code_p']			= 'Ei käsitelty';
$_['text_card_code_s']			= 'Kauppias on ilmoittanut, että kortin turva koodi ei ole läsnä kortilla';
$_['text_card_code_u']			= 'Liikkeeseenlaskija ei ole sertifioitu ja/tai ei ole toimittanut salaus avaimia';
$_['text_card_code_x']			= 'Luotto kortti yhdistykselle ei saatu vastausta';
$_['text_card_code_blank']		= 'Tyhjän vasta uksen tulee osoittaa, että koodia ei ole lähetetty ja että ei ollut viitteitä siitä, että koodia ei ollut kortissa.';
$_['text_card_type_m']			= 'Mastercard';
$_['text_card_type_v']			= 'Visa (luotto/pankki/Electron/Delta)';
$_['text_card_type_c']			= 'Diners';
$_['text_card_type_a']			= 'American Express';
$_['text_card_type_ma']			= 'Maestro';
$_['text_card_type_mauk']		= 'Maestro Iso-Britannia/Solo';
$_['text_response_code_full']	= 'Hyväksymis koodi: ';
$_['text_response_code']		= 'Täydellinen vastaus koodi: ';
$_['text_response_card']		= 'Käytetty kortti: ';
$_['text_response_card_type']	= 'Kortin tyyppi: ';
$_['text_response_proc_code']	= 'Suorittimen koodi: ';
$_['text_response_ref']			= 'Viite numero: ';

// Error
$_['error_failed']				= 'Maksua ei voi käsitellä, yritä uudelleen';