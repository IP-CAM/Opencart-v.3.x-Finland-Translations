<?php

$_['text_title'] = 'Luotto-tai maksu kortti';
$_['button_confirm'] = 'Vahvista';

$_['text_postcode_check'] = 'Posti numeron tarkistus: %s';
$_['text_security_code_check'] = 'CVV2 Tarkista: %s';
$_['text_address_check'] = 'Osoitteen tarkistus: %s';
$_['text_not_given'] = 'Ole annettu';
$_['text_not_checked'] = 'Ei tarkastettu';
$_['text_match'] = 'Hyväksytty';
$_['text_not_match'] = 'Ei hyväksytty';
$_['text_payment_details'] = 'Maksu tiedot';

$_['entry_card_type'] = 'Kortin tyyppi';