<?php
// Text
$_['text_title']				= 'Luotto kortti/debit-kortti (sazepay)';
$_['text_credit_card']			= 'Kortin tiedot';
$_['text_description']			= 'Nimikkeitä %s Järjestys numero: %s';
$_['text_card_type']			= 'Kortin tyyppi: ';
$_['text_card_name']			= 'Kortin nimi: ';
$_['text_card_digits']			= 'Viimeiset numerot: ';
$_['text_card_expiry']			= 'Sovittaa: ';
$_['text_trial']				= '%s Joka %s %s varten %s maksut sitten ';
$_['text_recurring']			= '%s Joka %s %s';
$_['text_length']				= ' varten %s Maksut';
$_['text_success']				= 'Maksusi on hyväksytty.';
$_['text_decline']				= 'Maksusi on hylätty.';
$_['text_bank_error']			= 'Virhe käsiteltäessä pyyntöä pankin kanssa.';
$_['text_transaction_error']	= 'Tapahtumaa käsiteltäessä tapahtui virhe.';
$_['text_generic_error']		= 'Pyyntösi käsittelyssä tapahtui virhe.';
$_['text_hash_failed']			= 'Hajautus tarkistus epäonnistui. Älä yritä maksua uudelleen, koska maksun tila on tuntematon. Otathan yhteyttä myyjään.';
$_['text_link']					= 'Ole hyvä ja klikkaa <a href="%s">Täällä</a> jatkamaan';
$_['text_confirm_delete']		= 'Haluatko varmasti poistaa kortin?';

// Entry
$_['entry_card']				= 'Uusi tai olemassa oleva kortti: ';
$_['entry_card_existing']		= 'Olemassa oleva';
$_['entry_card_new']			= 'Uusi';
$_['entry_card_save']			= 'Muista kortin tiedot myöhempää käyttöä varten';
$_['entry_cc_choice']			= 'Valitse olemassa oleva kortti';

// Button
$_['button_delete_card']		= 'Poista valittu kortti';