<?php
// Text
$_['text_title']				= 'Luotto-tai pankki kortilla';
$_['text_credit_card']			= 'Luottokorttitiedot';
$_['text_wait']					= 'Ole hyvä ja odota!';
$_['text_result']				= 'Tulos';
$_['text_message']				= 'Viesti';
$_['text_cvn_result']			= 'CVN-tulos';
$_['text_avs_postcode']			= 'AVS posti numero';
$_['text_avs_address']			= 'AVS osoite';
$_['text_eci']					= 'ECI-tulos (3D Secure)';
$_['text_tss']					= 'TSS:n tulos';
$_['text_card_bank']			= 'Kortti Issue pankki';
$_['text_card_country']			= 'Kortin maa';
$_['text_card_region']			= 'Kortin alue';
$_['text_last_digits']			= 'Viimeiset 4 numeroa';
$_['text_order_ref']			= 'Tilaa REF';
$_['text_timestamp']			= 'Aikaleima';
$_['text_card_visa']			= 'Visa';
$_['text_card_mc']				= 'Mastercard';
$_['text_card_amex']			= 'American Express';
$_['text_card_switch']			= 'Kytkin';
$_['text_card_laser']			= 'Laser';
$_['text_card_diners']			= 'Diners';
$_['text_auth_code']			= 'Auth-koodi';
$_['text_3d_s1']				= 'Kortin haltija ei ilmoittautunut, vastuu muutos';
$_['text_3d_s2']				= 'Ei voi tarkistaa ilmoittautumista, ei vastuu vuoroa';
$_['text_3d_s3']				= 'Virheellinen vasta uksen rekisteröinti palvelimesta, ei vastuu siirtymistä';
$_['text_3d_s4']				= 'Kirjoilla, mutta virheellinen vastaus ACS (Access Control Server), ei vastuuta siirtyminen';
$_['text_3d_s5']				= 'Onnistunut todennus, vastuu muutos';
$_['text_3d_s6']				= 'Todennus yritys tunnusti, vastuu muutos';
$_['text_3d_s7']				= 'Virheellinen sala sana annettu, ei vastuuta Shift';
$_['text_3d_s8']				= 'Todennus ei ole käytettävissä, ei vastuu siirtymistä';
$_['text_3d_s9']				= 'Virheellinen ACS:n vastaus, ei vastuu siirtymistä';
$_['text_3d_s10']				= 'Realmpi kohtalokas virhe, ei vastuuta Shift';

// Entry
$_['entry_cc_type']				= 'Kortin tyyppi';
$_['entry_cc_number']			= 'Kortin numero';
$_['entry_cc_name']				= 'Kortin haltijan nimi';
$_['entry_cc_expire_date']		= 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']				= 'Kortin turva koodi (CVV2)';
$_['entry_cc_issue']			= 'Kortin myöntämis numero';

// Help
$_['help_start_date']			= '(jos saatavilla)';
$_['help_issue']				= '(vain Maestro ja Solo-kortit)';

// Error
$_['error_card_number']			= 'Tarkista korttisi numero on voimassa';
$_['error_card_name']			= 'Tarkista, että kortin haltijan nimi on voimassa';
$_['error_card_cvv']			= 'Tarkista CVV2 on voimassa';
$_['error_3d_unable']			= 'Kauppias vaatii 3D Secure mutta ei voi tarkistaa pankin kanssa, yritä myöhemmin';
$_['error_3d_500_response_no_payment'] = 'Kortin käsittelijällä vastaanotettiin virheellinen vastaus, maksua ei ole suoritettu';
$_['error_3d_unsuccessful']		= '3D Secure-valtuutus epäonnistui';