<?php
// Heading
$_['express_text_title']      = 'Vahvista tilaus';

// Text
$_['text_title']              = 'PayPal Express Checkout';
$_['text_cart']               = 'Ostoskori';
$_['text_shipping_updated']   = 'Lähetys palvelu päivitetty';
$_['text_trial']              = '%s Joka %s %s varten %s maksut sitten ';
$_['text_recurring']          = '%s Joka %s %s';
$_['text_recurring_item']     = 'Toistuva nimike';
$_['text_length']             = ' varten %s Maksut';

// Entry
$_['express_entry_coupon']    = 'Kirjoita kuponki tässä:';

// Button
$_['button_express_coupon']   = 'Lisää';
$_['button_express_confirm']  = 'Vahvista';
$_['button_express_login']    = 'Jatka PayPal';
$_['button_express_shipping'] = 'Päivitä lähetys';

// Error
$_['error_heading_title']	  = 'Virhe';
$_['error_too_many_failures'] = 'Maksusi on epäonnistunut liian monta kertaa';
$_['error_unavailable'] 	  = 'Käyttäkää koko kassalle tämän tila uksen';
$_['error_no_shipping']    	  = 'Varoitus: toimitus vaihtoehdot eivät ole käytettävissä. Ole hyvä <a href="%s">Ota yhteyttä meihin</a> apua!';
