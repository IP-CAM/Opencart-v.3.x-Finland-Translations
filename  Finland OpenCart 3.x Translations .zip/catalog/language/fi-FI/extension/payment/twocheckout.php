<?php
// Text
$_['text_title'] = 'Luotto kortti/debit-kortti (2checkout)';