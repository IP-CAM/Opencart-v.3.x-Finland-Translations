<?php
// Heading
$_['heading_title']			= 'Ole hyvä ja valitse maksu suunnitelma';

// Text
$_['text_title']			= 'Laita se Lay-Osta powered by PayPal';
$_['text_plan_preview']		= 'Suunnitelman esikatselu';
$_['text_payment']			= 'Maksu';
$_['text_due_date']			= 'Eräpäivä';
$_['text_amount']			= 'Summa';
$_['text_downpayment']		= 'Alas maksu';
$_['text_today']			= 'Tänään';
$_['text_delivery_msg']		= 'Sinun tavarat/huolto jälki säädös olla antaa aikoinaan sinun finaali lunastus has maksettu.';
$_['text_fee_msg']			= '0,9% admin maksu on maksettava Lay-Buys.com.';
$_['text_month']			= 'Kuukausi';
$_['text_months']			= 'Kuukautta';
$_['text_status_1']			= 'Odottavat';
$_['text_status_5']			= 'Valmis';
$_['text_status_7']			= 'Peruutettu';
$_['text_status_50']		= 'Tarkistamis pyyntö';
$_['text_status_51']		= 'Tarkistettu';
$_['text_comment']			= 'Päivitetty Lay-Osta';

// Entry
$_['entry_initial']			= 'Alkuperäinen maksu';
$_['entry_months']			= 'Kuukautta';

// Button
$_['button_confirm']		= 'Vahvista tilaus';