<?php
// Text
$_['text_title']	= 'Paypal';
$_['text_testmode']	= 'Varoitus: maksuyhdyskäytävä on eristetyssä tilassa. Tiliäsi ei veloiteta.';
$_['text_total']	= 'Toimitus, käsittely, alennukset & verot';