<?php
// Text
$_['text_title']           = 'Luotto kortti/pankki kortti (Authorize.net)';
$_['text_credit_card']     = 'Luottokorttitiedot';

// Entry
$_['entry_cc_owner']       = 'Kortin omistaja';
$_['entry_cc_number']      = 'Kortin numero';
$_['entry_cc_expire_date'] = 'Kortin viimeinen voimassaolo päivä';
$_['entry_cc_cvv2']        = 'Kortin turva koodi (CVV2)';