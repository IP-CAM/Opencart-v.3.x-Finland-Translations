<?php
// Text
$_['text_title']				= 'Luotto kortti/pankki kortti (Paymate)';
$_['text_unable']				= 'Tila uksen tilaa ei löydy tai sitä ei voi päivittää';
$_['text_declined']				= 'Maksu hylättiin Paymate';
$_['text_failed']				= 'Paymate-tapahtuma epäonnistui';
$_['text_failed_message']		= '<p>Ikävä kyllä paikalla by erehdys käsittely sinun Paymate kauppa.</p><p><b>Varoitus: </b>%s</p><p>Tarkista Paymate tilin saldo ennen kuin yrität uudelleen käsitellä tätä tilausta</p><p> Jos uskot, että tämä toimenpide on suoritettu onnistuneesti, tai näkyy vähennyksenä Paymate tilille, ota <a href="%s">Ota yhteyttä meihin</a> tilauksesi tiedot.</p>';
$_['text_basket']				= 'Kori';
$_['text_checkout']				= 'Kassalle';
$_['text_success']				= 'Menestys';