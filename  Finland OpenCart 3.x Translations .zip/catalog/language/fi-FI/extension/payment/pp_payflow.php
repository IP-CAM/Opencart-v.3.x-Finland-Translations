<?php
// Text
$_['text_title']				= 'Luotto-tai debit-kortti (käsitellään turvallisesti PayPal)';
$_['text_credit_card']			= 'Luottokorttitiedot';
$_['text_start_date']			= '(jos saatavilla)';
$_['text_issue']				= '(vain Maestro ja Solo-kortit)';
$_['text_wait']					= 'Ole hyvä ja odota!';

// Entry
$_['entry_cc_owner']			= 'Kortin omistaja:';
$_['entry_cc_type']				= 'Kortin tyyppi:';
$_['entry_cc_number']			= 'Kortin numero:';
$_['entry_cc_start_date']		= 'Kortti voimassa alkaen:';
$_['entry_cc_expire_date']		= 'Kortin viimeinen voimassaolo päivä:';
$_['entry_cc_cvv2']				= 'Kortin turva koodi (CVV2):';
$_['entry_cc_issue']			= 'Kortin myöntämis numero:';

// Error
$_['error_required']			= 'Varoitus: kaikki maksu tieto kentät ovat pakollisia.';
$_['error_general']				= 'Varoitus: tapahtuman yhteydessä on ilmennyt yleinen ongelma. Haluta koetus jälleen.';
$_['error_config']				= 'Varoitus: maksu moduulin määritys virhe. Tarkista kirjautumistunnukset.';
$_['error_address']				= 'Varoitus: maksu osoitteen kaupunki, osavaltio ja posti numero eivät täsmää. Haluta koetus jälleen.';
$_['error_declined']			= 'Varoitus: Tämä tapahtuma on hylätty. Haluta koetus jälleen.';
$_['error_invalid']				= 'Varoitus: annettu luotto kortti tiedot eivät kelpaa. Haluta koetus jälleen.';