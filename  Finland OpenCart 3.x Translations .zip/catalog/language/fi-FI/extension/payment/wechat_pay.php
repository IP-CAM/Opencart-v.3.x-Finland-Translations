<?php
/**
 * @package		OpenCart
 * @author		Meng Wenbin
 * @copyright	Copyright (c) 2010 - 2017, Chengdu Guangda Network Technology Co. Ltd. (https://www.opencart.cn/)
 * @license		https://opensource.org/licenses/GPL-3.0
 * @link		https://www.opencart.cn
 */

// Heading
$_['heading_title']              = 'WeChat QR Code maksu';

// Text
$_['text_title']                 = 'WeChat maksaa';
$_['text_checkout']              = 'Kassalle';
$_['text_qrcode']                = 'Qmcode';
$_['text_qrcode_description']    = 'Tarkista QR-koodi WeChat-sovelluksessa ja maksa tilauksesi!';
