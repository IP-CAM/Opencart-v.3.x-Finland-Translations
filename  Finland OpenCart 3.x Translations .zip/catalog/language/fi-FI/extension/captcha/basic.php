<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Kirjoita koodi alla olevaan kenttään';

// Error
$_['error_captcha'] = 'Vahvistus koodi ei vastaa kuvaa!';