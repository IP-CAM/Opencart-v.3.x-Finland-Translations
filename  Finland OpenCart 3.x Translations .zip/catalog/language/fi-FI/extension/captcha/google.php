<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Täytä captcha validointi alla';

// Error
$_['error_captcha'] = 'Todentaminen ei ole oikein!';