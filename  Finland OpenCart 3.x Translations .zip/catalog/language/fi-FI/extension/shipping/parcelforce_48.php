<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Paino:';
$_['text_insurance']   = 'Vakuutettu enintään:';
$_['text_time']        = 'Arvioitu aika: 48 tunnin kuluessa';