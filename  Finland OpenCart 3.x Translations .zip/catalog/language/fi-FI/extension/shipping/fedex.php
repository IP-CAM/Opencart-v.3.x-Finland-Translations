<?php
// Text
$_['text_title']                               = 'Fedex';
$_['text_weight']                              = 'Paino:';
$_['text_eta']                                 = 'Arvioitu aika:';
$_['text_europe_first_international_priority'] = 'Euroopan ensimmäinen kansainvälinen prioriteetti';
$_['text_fedex_1_day_freight']                 = 'FedEx 1 päivä rahti';
$_['text_fedex_2_day']                         = 'FedEx 2 päivää';
$_['text_fedex_2_day_am']                      = 'FedEx 2 päivää am';
$_['text_fedex_2_day_freight']                 = 'FedEx 2 päivän rahti';
$_['text_fedex_3_day_freight']                 = 'FedEx 3 päivän rahti';
$_['text_fedex_express_saver']                 = 'FedEx Express Saver';
$_['text_fedex_first_freight']                 = 'FedExin ensimmäinen rahti';
$_['text_fedex_freight_economy']               = 'FedEx Freight Economy';
$_['text_fedex_freight_priority']              = 'FedEx Freight-prioriteetti';
$_['text_fedex_ground']                        = 'FedEx Ground';
$_['text_first_overnight']                     = 'Ensimmäinen yön yli';
$_['text_ground_home_delivery']                = 'Ground kotiinkuljetus';
$_['text_international_economy']               = 'Kansainvälinen talous';
$_['text_international_economy_freight']       = 'Kansainvälinen talous rahti';
$_['text_international_first']                 = 'International First';
$_['text_international_priority']              = 'Kansainvälinen paino piste';
$_['text_international_priority_freight']      = 'Kansainvälinen paino piste rahti';
$_['text_priority_overnight']                  = 'Prioriteetti yössä';
$_['text_smart_post']                          = 'Smart post';
$_['text_standard_overnight']                  = 'Standard yön yli';