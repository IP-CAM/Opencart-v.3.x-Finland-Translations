<?php
// Text
$_['text_title']  = 'Yhdysvaltain posti laitos';
$_['text_weight'] = 'Paino:';
$_['text_eta']    = 'Arvioitu aika:';