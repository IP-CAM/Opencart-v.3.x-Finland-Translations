<?php
// Text
$_['text_title']       = 'Kiinteämääräinen';
$_['text_description'] = 'Tasainen toimitus hinta';