<?php
// Text
$_['text_title']       = 'Nimikettä kohti';
$_['text_description'] = 'Per nimike toimitus hinta';