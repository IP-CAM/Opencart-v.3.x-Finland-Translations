<?php
// Text
$_['text_title']       = 'Pickup';
$_['text_description'] = 'Nouto myymälästä';