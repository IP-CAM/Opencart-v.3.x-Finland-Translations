<?php
// Text
$_['text_title']                               = 'EY-aluksen';
$_['text_weight']                              = 'Paino:';
$_['text_air_registered_mail']                 = 'Air kirjattuna kirjenä';
$_['text_air_parcel']                          = 'Air paketti';
$_['text_e_express_service_to_us']             = 'e-Express-palvelu meille';
$_['text_e_express_service_to_canada']         = 'e-Express-palvelu Kanadaan';
$_['text_e_express_service_to_united_kingdom'] = 'e-Express-palvelu Yhdistyneeseen kuningas kuntaan';
$_['text_e_express_service_to_russia']         = 'e-Express-palvelu Venäjälle';
$_['text_e_express_service_one']               = 'e-Express-palvelu';
$_['text_e_express_service_two']               = 'e-Express-palvelu';
$_['text_speed_post']                          = 'Speedpost (vakio palvelu)';
$_['text_smart_post']                          = 'Smart post';
$_['text_local_courier_post']                  = 'Paikallinen Courier post (laskuri kokoelma)';
$_['text_local_parcel']                        = 'Paikallinen paketti';

//error
$_['text_unavailable']                         = 'Ei lähetys palvelua saatavilla';
