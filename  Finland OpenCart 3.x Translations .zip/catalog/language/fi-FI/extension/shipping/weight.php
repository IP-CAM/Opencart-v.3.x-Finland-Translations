<?php
// Text
$_['text_title']  = 'Paino perustuu Shipping';
$_['text_weight'] = 'Paino:';