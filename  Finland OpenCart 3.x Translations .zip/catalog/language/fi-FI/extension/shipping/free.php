<?php
// Text
$_['text_title']       = 'Ilmainen toimitus';
$_['text_description'] = 'Ilmainen toimitus';