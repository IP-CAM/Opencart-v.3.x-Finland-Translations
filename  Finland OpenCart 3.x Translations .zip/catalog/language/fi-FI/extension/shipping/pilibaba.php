<?php
// Text
$_['text_title']       = 'Piliexpress';
$_['text_description'] = 'Piliexpress (仅限霹雳爸爸支付, vain pilibaba kassalle)';