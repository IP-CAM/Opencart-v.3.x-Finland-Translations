<?php
// Text
$_['text_title']                        = 'Royal Mail';
$_['text_weight']                       = 'Paino:';
$_['text_insurance']                    = 'Vakuutettu enintään:';
$_['text_special_delivery']             = 'Special toimitus seuraavana päivänä';
$_['text_1st_class_signed']             = 'Ensimmäisen luokan allekirjoitettu viesti';
$_['text_2nd_class_signed']             = 'Toisen luokan allekirjoitettu viesti';
$_['text_1st_class_standard']           = 'Ensimmäisen luokan Standard post';
$_['text_2nd_class_standard']           = 'Toisen luokan Standard post';
$_['text_international_standard']       = 'Kansainvälinen standardi';
$_['text_international_tracked_signed'] = 'Kansainvälinen seurataan & allekirjoitettu';
$_['text_international_tracked']        = 'Kansainväliset seuratut';
$_['text_international_signed']         = 'Kansainvälinen allekirjoitettu';
$_['text_international_economy']        = 'Kansainvälinen talous';