<?php
// Text
$_['text_handling'] = 'Käsittely maksu';