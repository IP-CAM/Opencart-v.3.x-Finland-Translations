<?php
// Text
$_['text_credit']   = 'Säilytä luotto';
$_['text_order_id'] = 'Tila uksen tunnus: #%s';