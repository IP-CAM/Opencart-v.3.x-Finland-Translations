<?php
// Heading
$_['heading_title']        = 'Arvioi toimitus &amp; Veroja';

// Text
$_['text_success']         = 'Menestys: sinun Shipping arvio on sovellettu!';
$_['text_shipping']        = 'Anna määränpää saada meren kulun arvio.';
$_['text_shipping_method'] = 'Valitse tässä järjestyksessä käytettävä ensisijainen toimitus tapa.';

// Entry
$_['entry_country']        = 'Maa';
$_['entry_zone']           = 'Alue/osavaltio';
$_['entry_postcode']       = 'Posti numero';

// Error
$_['error_postcode']       = 'Posti numeron on oltava 2-10 merkkiä pitkä!';
$_['error_country']        = 'Ole hyvä ja valitse maa!';
$_['error_zone']           = 'Valitse alue/osavaltio!';
$_['error_shipping']       = 'Varoitus: toimitus tapa vaaditaan!';
$_['error_no_shipping']    = 'Varoitus: toimitus vaihtoehdot eivät ole käytettävissä. Ole hyvä <a href="%s">Ota yhteyttä meihin</a> apua!';