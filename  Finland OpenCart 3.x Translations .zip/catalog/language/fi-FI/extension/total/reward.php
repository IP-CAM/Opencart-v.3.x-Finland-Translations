<?php
// Heading
$_['heading_title'] = 'Käytä palkinto pisteitä (käytettävissä %s)';

// Text
$_['text_reward']   = 'Palkita pistettä (%s)';
$_['text_order_id'] = 'Tila uksen tunnus: #%s';
$_['text_success']  = 'Menestys: sinun palkita pistettä alennus on sovellettu!';

// Entry
$_['entry_reward']  = 'Points käyttää (max %s)';

// Error
$_['error_reward']  = 'Varoitus: Anna määrä palkita pistettä käyttää!';
$_['error_points']  = 'Varoitus: sinulla ei ole %s Palkintopisteitä!';
$_['error_maximum'] = 'Varoitus: maksimi piste määrä, jota voidaan käyttää, on %s!';