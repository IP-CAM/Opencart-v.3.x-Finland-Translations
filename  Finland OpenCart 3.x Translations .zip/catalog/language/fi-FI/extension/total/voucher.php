<?php
// Heading
$_['heading_title'] = 'Käytä lahja kortti';

// Text
$_['text_voucher']  = 'Lahja kortti (%s)';
$_['text_success']  = 'Menestys: lahja kortti alennus on sovellettu!';

// Entry
$_['entry_voucher'] = 'Anna lahja kortin koodi tähän';

// Error
$_['error_voucher'] = 'Varoitus: lahja kortti on joko virheellinen tai saldo on käytetty!';
$_['error_empty']   = 'Varoitus: Anna lahja kortin koodi!';