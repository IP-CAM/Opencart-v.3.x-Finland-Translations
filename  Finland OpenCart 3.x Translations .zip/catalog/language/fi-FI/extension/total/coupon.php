<?php
// Heading
$_['heading_title'] = 'Käytä kuponki koodi';

// Text
$_['text_coupon']   = 'Kuponki%s)';
$_['text_success']  = 'Menestys: sinun kuponki alennus on sovellettu!';

// Entry
$_['entry_coupon']  = 'Anna kuponki täällä';

// Error
$_['error_coupon']  = 'Varoittava kaappaus on jompikumpi invalidi, hengittää eli ehtiä sen kielen käyttö kaventaa!';
$_['error_empty']   = 'Varoitus: Anna kuponki koodi!';