<?php
// Heading
$_['heading_title']  = 'Ota yhteyttä meihin';

// Text
$_['text_location']  = 'Sijaintimme';
$_['text_store']     = 'Myymälöidemme';
$_['text_contact']   = 'Yhteyden Otto lomake';
$_['text_address']   = 'Osoite';
$_['text_telephone'] = 'Puhelin';
$_['text_fax']       = 'Faksi';
$_['text_open']      = 'Aukioloajat';
$_['text_comment']   = 'Kommentit';
$_['text_success']   = '<p>Kyselysi on lähetetty onnistuneesti myymälän omistajalle!</p>';

// Entry
$_['entry_name']     = 'Nimesi';
$_['entry_email']    = 'Sähköpostiosoite';
$_['entry_enquiry']  = 'Tiedustelu';

// Email
$_['email_subject']  = 'Tiedustelu %s';

// Errors
$_['error_name']     = 'Nimen on oltava välillä 3 ja 32 merkkiä!';
$_['error_email']    = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_enquiry']  = 'Tiedustelu on välillä 10 ja 3000 merkkiä!';