<?php
// Heading
$_['heading_title']    = 'Sivu kartta';

// Text
$_['text_special']     = 'Erikoistarjoukset';
$_['text_account']     = 'Oma tilini';
$_['text_edit']        = 'Tilin tiedot';
$_['text_password']    = 'Salasana';
$_['text_address']     = 'Osoite kirja';
$_['text_history']     = 'Tilaus historia';
$_['text_download']    = 'Lataukset';
$_['text_cart']        = 'Ostoskori';
$_['text_checkout']    = 'Kassalle';
$_['text_search']      = 'Etsi';
$_['text_information'] = 'Huoneesta';
$_['text_contact']     = 'Ota yhteyttä meihin';