<?php
//text
$_['text_total_reviews'] = 'Yhteensä arviot:';
$_['text_month_reviews'] = 'Lisätään tässä kuussa:';
$_['text_empty'] = 'Ei arvosteluja näyttää!';
$_['heading_title'] = 'Tuote arviot';
$_['button_continue'] = 'Jatkaa';
$_['text_author'] = 'Kirjoittaja:';
$_['text_location'] = 'Sijainti:';
$_['text_date'] = 'Päivämäärä:';
$_['text_average'] = 'Olemme saaneet <span class="totalreviews">%d</span> arvosteluja, joiden keskimääräinen luokitus on <span class="avgrating">%s</span>';
$_['text_email_review'] = 'Arvostelu henkilöltä';

$_['store_review_heading_title'] = 'Tutustu myymälään';
$_['store_review_text'] = 'Ole hyvä ja arvostele kokemuksia myymälään alla:';
$_['store_review_max'] = 'Mahtavaa! Me rakastamme sinäkin. Se oikeastaan auttaa objekti muoto rikki tokko te ajaa pienen pieni jotta kirjailla arvostella ajaksi objekti muoto model after:';
$_['store_review_submit'] = 'Lähetä';
$_['store_review_text_'] = 'Jaa kokemuksesi';
$_['store_review_text_error'] = 'Ole hyvä, kirjoita arvostelu!';
$_['store_review_success'] = 'Arvostelisi toimitettiin!';
?>