<?php
// Text
$_['text_error'] = 'Tietoja sivua ei löydy!';