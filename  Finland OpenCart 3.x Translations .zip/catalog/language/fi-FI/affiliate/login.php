<?php
// Heading
$_['heading_title']                 = 'Kumppaniohjelmaan';

// Text
$_['text_account']                  = 'Tili';
$_['text_login']                    = 'Kirjaudu';
$_['text_description']              = '<p>%s Affiliate Program on ilmainen ja mahdollistaa jäsenten ansaita tuloja asettamalla linkin tai linkkejä niiden koti sivuilta, joka mainostaa %s tai tiettyjä tuotteita sitä. Kaikki myynnit asiakkaille, jotka ovat napsauttaneet näitä linkkejä, ansaitsevat affiliate-komission. Komission vakio hinta on tällä hetkellä %s.</p><p>Lisä tietoja saat tutustumalla FAQ-sivullemme tai tutustumalla affiliate-ehtoihin &amp; Edellytykset.</p>';
$_['text_new_affiliate']            = 'Uusi affiliate';
$_['text_register_account']         = '<p>En ole tällä hetkellä kumppaniksi.</p><p>Luo uusi kumppani tili valitsemalla Jatka. Huomaa, että tämä ei ole kytketty millään tavalla asiakkaan tilille.</p>';
$_['text_returning_affiliate']      = 'Affiliate Kirjaudu';
$_['text_i_am_returning_affiliate'] = 'Olen palaava yhteistyökumppani.';
$_['text_forgotten']                = 'Unohtunut sala sana';

// Entry
$_['entry_email']                   = 'Affiliate Sähkö posti';
$_['entry_password']                = 'Salasana';

// Error
$_['error_login']                   = 'Varoitus: ei täsmää Sähkö posti osoite ja/tai sala sana.';
$_['error_attempts']                = 'Varoitus: tilisi on ylittänyt sallitun kirjautumisyritysten määrän. Yritä uudelleen 1 tunnissa.';
$_['error_approved']                = 'Varoitus: tilisi edellyttää hyväksyntää, ennen kuin voit kirja utua.';