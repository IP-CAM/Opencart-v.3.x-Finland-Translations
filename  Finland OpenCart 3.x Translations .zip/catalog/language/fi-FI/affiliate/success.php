<?php
// Heading
$_['heading_title'] = 'Affiliate-tili on luotu!';

// Text
$_['text_message']  = '<p>Onnittelen! Uusi tilisi on luotu onnistuneesti!</p> <p>Olet nyt jäsenenä %s Tytäryhtiöiden.</p> <p>Jos sinulla on kysyttävää tämän affiliate-järjestelmän toiminnasta, Lähetä sähkö postia myymälän omistajalle.</p> <p>Annettuun Sähkö posti osoitteeseen on lähetetty vahvistus. Jos et ole saanut sitä tunnin kuluessa, ota <a href="%s">Ota yhteyttä meihin</a>.</p>';
$_['text_approval'] = '<p>Kiitos rekisteröitymisestä affiliate-tilille %s!</p><p>Saat ilmoituksen sähköpostitse, kun tilisi on aktivoitu kaupan omistaja.</p><p>Jos sinulla on kysyttävää tämän affiliate-järjestelmän toiminnasta, ota <a href="%s">Ota yhteyttä kaupan omistajaan</a>.</p>';
$_['text_account']  = 'Tili';
$_['text_success']  = 'Menestys';