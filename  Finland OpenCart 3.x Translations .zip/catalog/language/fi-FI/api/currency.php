<?php
// Text
$_['text_success']     = 'Menestys: sinun valuutta on muuttunut!';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_currency']   = 'Varoitus: valuutta koodi ei kelpaa!';