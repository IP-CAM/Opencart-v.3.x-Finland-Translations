<?php
// Text
$_['text_success']     = 'Menestys: lahja kortin alennus on sovellettu!';
$_['text_cart']        = 'Menestys: olet muokannut ostos koriisi!';
$_['text_for']         = '%s Lahja kortti %s';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_voucher']    = 'Varoitus: lahja kortti on joko virheellinen tai saldo on käytetty!';
$_['error_to_name']    = 'Vastaanottajan nimen on oltava 1-64 merkkiä!';
$_['error_from_name']  = 'Nimesi on oltava välillä 1 ja 64 merkkiä!';
$_['error_email']      = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_theme']      = 'Sinun on valittava teema!';
$_['error_amount']     = 'Summan on oltava %s Ja %s!';