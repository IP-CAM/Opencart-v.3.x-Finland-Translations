<?php
// Text
$_['text_success']     = 'Menestys: sinun kuponki alennus on sovellettu!';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_coupon']     = 'Varoittava kaappaus on jompikumpi invalidi, hengittää eli ehtiä sen \' kielen käyttö kaventaa!';