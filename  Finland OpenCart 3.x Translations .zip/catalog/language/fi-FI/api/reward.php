<?php
// Text
$_['text_success']     = 'Menestys: sinun palkita pistettä alennus on sovellettu!';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_reward']     = 'Varoitus: Anna määrä palkita pistettä käyttää!';
$_['error_points']     = 'Varoitus: sinulla ei ole %s Palkintopisteitä!';
$_['error_maximum']    = 'Varoitus: maksimi piste määrä, jota voidaan käyttää, on %s!';