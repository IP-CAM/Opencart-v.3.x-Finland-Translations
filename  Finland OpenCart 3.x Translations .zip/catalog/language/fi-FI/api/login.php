<?php
// Text
$_['text_success'] = 'Onnistui: API-istunto käynnistyi onnistuneesti!';

// Error
$_['error_key']    = 'Varoitus: Virheellinen API-avain!';
$_['error_ip']     = 'Varoitus: IP %s ei saa käyttää tätä API!';