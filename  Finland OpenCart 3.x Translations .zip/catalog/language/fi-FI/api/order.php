<?php
// Text
$_['text_success']           = 'Menestys: olet muokannut tila uksia!';

// Error
$_['error_permission']       = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_customer']         = 'Varoitus: asiakkaan tiedot on asetettava!';
$_['error_payment_address']  = 'Varoitus: maksu osoite vaaditaan!';
$_['error_payment_method']   = 'Varoitus: maksu tapa vaaditaan!';
$_['error_no_payment']       = 'Varoitus: maksu vaihtoehtoja ei ole saatavilla!';
$_['error_shipping_address'] = 'Varoitus: toimitus osoite vaaditaan!';
$_['error_shipping_method']  = 'Varoitus: toimitus tapa vaaditaan!';
$_['error_no_shipping']      = 'Varoitus: ei toimitus vaihtoehdot ovat saatavilla!';
$_['error_stock']            = 'Varoitus: tähdellä * * * merkityt tuotteet eivät ole saatavilla haluttuun määrään tai niitä ei ole varastossa!';
$_['error_minimum']          = 'Varoitus: minimi tilaus summa %s On %s!';
$_['error_not_found']        = 'Varoitus: tilausta ei löytynyt!';