<?php
// Text
$_['text_success']     = 'Menestys: olet muokannut ostos koriisi!';

// Error
$_['error_permission'] = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_stock']      = 'Tähdellä * * * merkityt tuotteet eivät ole saatavilla haluttuun määrään tai niitä ei ole varastossa!';
$_['error_minimum']    = 'Minimi tilaus summa %s On %s!';
$_['error_store']      = 'Tuotetta ei voi ostaa kaupasta olet valinnut!';
$_['error_required']   = '%s Tarvitaan!';