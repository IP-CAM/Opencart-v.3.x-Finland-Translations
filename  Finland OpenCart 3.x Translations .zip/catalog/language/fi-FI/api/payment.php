<?php
// Text
$_['text_address']       = 'Onnistui: maksu osoite on asetettu!';
$_['text_method']        = 'Onnistui: maksu tapa on asetettu!';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_firstname']    = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']     = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_address_1']    = 'Osoitteen 1 on oltava välillä 3 ja 128 merkkiä!';
$_['error_city']         = 'Kaupungin on oltava välillä 3 ja 128 merkkiä!';
$_['error_postcode']     = 'Posti numeron on oltava 2-10 merkkiä tässä maassa!';
$_['error_country']      = 'Ole hyvä ja valitse maa!';
$_['error_zone']         = 'Valitse alue/osavaltio!';
$_['error_custom_field'] = '%s Tarvitaan!';
$_['error_address']      = 'Varoitus: maksu osoite vaaditaan!';
$_['error_method']       = 'Varoitus: maksu tapa vaaditaan!';
$_['error_no_payment']   = 'Varoitus: maksu vaihtoehtoja ei ole saatavilla!';