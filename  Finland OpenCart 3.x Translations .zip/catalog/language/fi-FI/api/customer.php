<?php
// Text
$_['text_success']       = 'Olet muokannut asiakkaita onnistuneesti';

// Error
$_['error_permission']   = 'Varoitus: sinulla ei ole lupaa käyttää API!';
$_['error_customer']     = 'Sinun täytyy valita asiakas!';
$_['error_firstname']    = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']     = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']        = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']    = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_custom_field'] = '%s Tarvitaan!';