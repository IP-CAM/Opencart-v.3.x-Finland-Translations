<?php
// Heading
$_['heading_title']      = 'Tuotteen palautukset';

// Text
$_['text_account']       = 'Tili';
$_['text_return']        = 'Palautus tiedot';
$_['text_return_detail'] = 'Paluu tiedot';
$_['text_description']   = 'Täytä alla oleva lomake ja pyydä RMA-numero.';
$_['text_order']         = 'Tila uksen tiedot';
$_['text_product']       = 'Tuote tiedot';
$_['text_reason']        = 'Palautuksen syy';
$_['text_message']       = '<p>Kiitos, että läheit palautus pyyntösi. Pyyntösi on lähetetty asian omaisen osaston käsiteltäväksi.</p><p> Sinulle ilmoitetaan pyyntösi tilasta sähköpostitse.</p>';
$_['text_return_id']     = 'Paluu tunnus:';
$_['text_order_id']      = 'Tila uksen tunnus:';
$_['text_date_ordered']  = 'Tilaus päivämäärä:';
$_['text_status']        = 'Tila:';
$_['text_date_added']    = 'Lisäys päivä:';
$_['text_comment']       = 'Paluu kommentit';
$_['text_history']       = 'Paluu historia';
$_['text_empty']         = 'Et ole tehnyt mitään aiempia tuottoja!';
$_['text_agree']         = 'Olen lukenut ja hyväksyn <a href="%s" class="agree"><b>%s</b></a>';

// Column
$_['column_return_id']   = 'Palautus tunnus';
$_['column_order_id']    = 'Tilauksen tunnus';
$_['column_status']      = 'Tila';
$_['column_date_added']  = 'Päivä määrä lisätty';
$_['column_customer']    = 'Asiakas';
$_['column_product']     = 'Tuotteen nimi';
$_['column_model']       = 'Malli';
$_['column_quantity']    = 'Määrä';
$_['column_price']       = 'Hinta';
$_['column_opened']      = 'Avattu';
$_['column_comment']     = 'Kommentti';
$_['column_reason']      = 'Syy';
$_['column_action']      = 'Toiminta';

// Entry
$_['entry_order_id']     = 'Tilauksen tunnus';
$_['entry_date_ordered'] = 'Tilaus päivämäärän';
$_['entry_firstname']    = 'Etunimi';
$_['entry_lastname']     = 'Suku nimi';
$_['entry_email']        = 'Sähköposti';
$_['entry_telephone']    = 'Puhelin';
$_['entry_product']      = 'Tuotteen nimi';
$_['entry_model']        = 'Tuote koodi';
$_['entry_quantity']     = 'Määrä';
$_['entry_reason']       = 'Palautuksen syy';
$_['entry_opened']       = 'Tuote on avattu';
$_['entry_fault_detail'] = 'Viallinen tai muita tietoja';

// Error
$_['text_error']         = 'Palautuksia pyytämäsi ei löytynyt!';
$_['error_order_id']     = 'Tilaus tunnus vaaditaan!';
$_['error_firstname']    = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']     = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']        = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']    = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_product']      = 'Tuotteen nimen on oltava suurempi kuin 3 ja alle 255 merkkiä!';
$_['error_model']        = 'Tuote mallin on oltava suurempi kuin 3 ja alle 64 merkkiä!';
$_['error_reason']       = 'Sinun täytyy valita palautuksen tuotteen syy!';
$_['error_agree']        = 'Varoitus: sinun on hyväksyttävä %s!';