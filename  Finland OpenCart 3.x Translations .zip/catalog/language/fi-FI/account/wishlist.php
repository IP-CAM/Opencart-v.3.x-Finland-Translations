<?php
// Heading
$_['heading_title'] = 'Toive lista';

// Text
$_['text_account']  = 'Tili';
$_['text_instock']  = 'Varastossa';
$_['text_wishlist'] = 'Toive lista (%s)';
$_['text_login']    = 'Sinun on <a href="%s">Kirjaudu</a> Tai <a href="%s">Luo tili</a> Jos haluat tallentaa <a href="%s">%s</a> tieto <a href="%s">Toivelista</a>!';
$_['text_success']  = 'Onnistui: olet lisännyt <a href="%s">%s</a> tieto <a href="%s">Toivelista</a>!';
$_['text_remove']   = 'Menestys: olet muuttanut toive listasi!';
$_['text_empty']    = 'Toive listasi on tyhjä.';

// Column
$_['column_image']  = 'Kuva';
$_['column_name']   = 'Tuotteen nimi';
$_['column_model']  = 'Malli';
$_['column_stock']  = 'Stock';
$_['column_price']  = 'Yksikkö hinta';
$_['column_action'] = 'Toiminta';