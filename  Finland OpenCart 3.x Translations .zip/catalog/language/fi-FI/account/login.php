<?php
// Heading
$_['heading_title']                = 'Tilin kirjautuminen';

// Text
$_['text_account']                 = 'Tili';
$_['text_login']                   = 'Kirjaudu';
$_['text_new_customer']            = 'Uusi asiakas';
$_['text_register']                = 'Rekisteröi tili';
$_['text_register_account']        = 'Luomalla tilin voit tehdä ostoksia nopeammin, olla ajan tasalla tila uksen tilasta ja seurata aiemmin tehtyjä tila uksia.';
$_['text_returning_customer']      = 'Palaava asiakas';
$_['text_i_am_returning_customer'] = 'Olen palaava asiakas';
$_['text_forgotten']               = 'Unohtunut sala sana';

// Entry
$_['entry_email']                  = 'Sähköpostiosoite';
$_['entry_password']               = 'Salasana';

// Error
$_['error_login']                  = 'Varoitus: ei täsmää Sähkö posti osoite ja/tai sala sana.';
$_['error_attempts']               = 'Varoitus: tilisi on ylittänyt sallitun kirjautumisyritysten määrän. Yritä uudelleen 1 tunnissa.';
$_['error_approved']               = 'Varoitus: tilisi edellyttää hyväksyntää, ennen kuin voit kirja utua.';