<?php
// Heading
$_['heading_title']      = 'Sinun palkita pistettä';

// Column
$_['column_date_added']  = 'Päivä määrä lisätty';
$_['column_description'] = 'Kuvaus';
$_['column_points']      = 'Pistettä';

// Text
$_['text_account']       = 'Tili';
$_['text_reward']        = 'Palkintopisteitä';
$_['text_total']         = 'Palkinto pisteiden kokonaismäärä on:';
$_['text_empty']         = 'Sinulla ei ole mitään palkita pistettä!';