<?php
// Heading
$_['heading_title']      = 'Tilini tiedot';

// Text
$_['text_account']       = 'Tili';
$_['text_edit']          = 'Muokkaa tietoja';
$_['text_your_details']  = 'Henkilökohtaiset tietosi';
$_['text_success']       = 'Onnistui: tilisi on päivitetty onnistuneesti.';

// Entry
$_['entry_firstname']    = 'Etunimi';
$_['entry_lastname']     = 'Suku nimi';
$_['entry_email']        = 'Sähköposti';
$_['entry_telephone']    = 'Puhelin';

// Error
$_['error_exists']       = 'Varoitus: Sähkö posti osoite on jo rekisteröity!';
$_['error_firstname']    = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']     = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']        = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']    = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_custom_field'] = '%s Tarvitaan!';