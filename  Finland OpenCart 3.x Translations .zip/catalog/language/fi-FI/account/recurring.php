<?php
// Heading
$_['heading_title']                        = 'Toistuvat maksut';

// Text
$_['text_account']                         = 'Tili';
$_['text_recurring']                       = 'Toistuvat maksu tiedot';
$_['text_recurring_detail']                = 'Toistuvat maksu tiedot';
$_['text_order_recurring_id']              = 'Toistuva tunnus:';
$_['text_date_added']                      = 'Lisäys päivä:';
$_['text_status']                          = 'Tila:';
$_['text_payment_method']                  = 'Maksutapa:';
$_['text_order_id']                        = 'Tila uksen tunnus:';
$_['text_product']                         = 'Tuotteen:';
$_['text_quantity']                        = 'Määrä:';
$_['text_description']                     = 'Kuvaus';
$_['text_reference']                       = 'Viite';
$_['text_transaction']                     = 'Tapahtumat';
$_['text_status_1']                        = 'Aktiivinen';
$_['text_status_2']                        = 'Passiivinen';
$_['text_status_3']                        = 'Peruutettu';
$_['text_status_4']                        = 'Keskeytetty';
$_['text_status_5']                        = 'Vanhentunut';
$_['text_status_6']                        = 'Odottavat';
$_['text_transaction_date_added']          = 'Luotu';
$_['text_transaction_payment']             = 'Maksu';
$_['text_transaction_outstanding_payment'] = 'Maksamatta oleva maksu';
$_['text_transaction_skipped']             = 'Maksu ohitettu';
$_['text_transaction_failed']              = 'Maksu epäonnistui';
$_['text_transaction_cancelled']           = 'Peruutettu';
$_['text_transaction_suspended']           = 'Keskeytetty';
$_['text_transaction_suspended_failed']    = 'Keskeytetty epäonnistuneita maksuja';
$_['text_transaction_outstanding_failed']  = 'Maksamatta oleva maksu epäonnistui';
$_['text_transaction_expired']             = 'Vanhentunut';
$_['text_empty']                           = 'Ei toistuvia maksuja löytynyt!';
$_['text_error']                           = 'Pyytämäsi Toistuva tilaus ei löytynyt!';
$_['text_cancelled']                       = 'Toistuva maksu on peruutettu';

// Column
$_['column_date_added']                    = 'Päivä määrä lisätty';
$_['column_type']                          = 'Tyyppi';
$_['column_amount']                        = 'Summa';
$_['column_status']                        = 'Tila';
$_['column_product']                       = 'Tuotteen';
$_['column_order_recurring_id']            = 'Toistuva tunnus';

// Error
$_['error_not_cancelled']                  = 'Virhe: %s';
$_['error_not_found']                      = 'Toistuvien kirjausten peruuttaminen ei onnistunut';

// Button
$_['button_return']                        = 'Palauttaa';