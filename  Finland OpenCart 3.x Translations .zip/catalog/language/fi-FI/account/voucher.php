<?php
// Heading
$_['heading_title']    = 'Lahja kortin ostaminen';

// Text
$_['text_account']     = 'Tili';
$_['text_voucher']     = 'Lahjakortti';
$_['text_description'] = 'Tämä lahja kortti lähetetään vastaanottajalle, kun tilauksesi on maksettu.';
$_['text_agree']       = 'Ymmärrän, että lahja kortteja ei palauteta.';
$_['text_message']     = '<p>Kiitos, että ostit lahja kortin! Kun olet suorittanut tilauksesi, lahja kortin vastaanottajalle lähetetään Sähkö posti viesti, jossa on tietoja siitä, miten lahja kortti lunastetaan.</p>';
$_['text_for']         = '%s Lahja kortti %s';

// Entry
$_['entry_to_name']    = 'Vastaanottajan nimi';
$_['entry_to_email']   = 'Vastaanottajan Sähkö posti osoite';
$_['entry_from_name']  = 'Nimesi';
$_['entry_from_email'] = 'Sähkö posti';
$_['entry_theme']      = 'Lahja kortti-teema';
$_['entry_message']    = 'Viesti';
$_['entry_amount']     = 'Summa';

// Help
$_['help_message']     = 'Valinnainen';
$_['help_amount']      = 'Arvon on oltava %s Ja %s';

// Error
$_['error_to_name']    = 'Vastaanottajan nimen on oltava 1-64 merkkiä!';
$_['error_from_name']  = 'Nimesi on oltava välillä 1 ja 64 merkkiä!';
$_['error_email']      = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_theme']      = 'Sinun on valittava teema!';
$_['error_amount']     = 'Summan on oltava %s Ja %s!';
$_['error_agree']      = 'Varoitus: sinun on hyväksyttävä, että lahja kortteja ei palauteta!';