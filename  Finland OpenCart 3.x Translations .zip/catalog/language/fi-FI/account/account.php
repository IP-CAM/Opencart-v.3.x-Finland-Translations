<?php
// Heading
$_['heading_title']       = 'Oma tilini';

// Text
$_['text_account']        = 'Tili';
$_['text_my_account']     = 'Oma tilini';
$_['text_my_orders']      = 'Omat tila ukset';
$_['text_my_affiliate']   = 'Oma affiliate-tili';
$_['text_my_newsletter']  = 'Uutiskirje';
$_['text_edit']           = 'Muokkaa tili tietojasi';
$_['text_password']       = 'Vaihda Sala sanasi';
$_['text_address']        = 'Osoitteiston merkintöjen muokkaaminen';
$_['text_credit_card']    = 'Hallitse tallennettuja luotto kortteja';
$_['text_wishlist']       = 'Toive listan muokkaaminen';
$_['text_order']          = 'Tarkastele tilaus historiaasi';
$_['text_download']       = 'Lataukset';
$_['text_reward']         = 'Sinun palkita pistettä';
$_['text_return']         = 'Näytä palautus pyyntösi';
$_['text_transaction']    = 'Tapahtumiksi';
$_['text_newsletter']     = 'Tilaa/Peruuta uutis kirje';
$_['text_recurring']      = 'Toistuvat maksut';
$_['text_transactions']   = 'Tapahtumat';
$_['text_affiliate_add']  = 'Rekisteröidy affiliate-tilille';
$_['text_affiliate_edit'] = 'Muokkaa affiliate-tietoja';
$_['text_tracking']       = 'Custom affiliate seuranta koodi';