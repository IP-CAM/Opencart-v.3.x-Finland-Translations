<?php
// Heading
$_['heading_title']  = 'Vaihda Sala sanasi';

// Text
$_['text_account']   = 'Tili';
$_['text_password']  = 'Anna uusi sala sana, jota haluat käyttää.';
$_['text_success']   = 'Onnistui: Sala sanasi on päivitetty onnistuneesti.';

// Entry
$_['entry_password'] = 'Salasana';
$_['entry_confirm']  = 'Vahvista';

// Error
$_['error_password'] = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']  = 'Sala sana ja sala sana vahvistus eivät täsmää!';
$_['error_code']     = 'Sala sanan palautus koodi on virheellinen tai sitä käytettiin aiemmin!';