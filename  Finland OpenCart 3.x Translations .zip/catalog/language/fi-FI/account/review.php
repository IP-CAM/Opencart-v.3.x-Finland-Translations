<?php



$_['heading_title'] = 'Tarkista ostamasi tuotteet';
$_['history_heading_title'] = 'Arvostelesi historia';

// Text

$_['text_review_history'] = 'Arvostelesi historia';

$_['text_reviews']             = 'Arvion perusteella';

$_['text_account']              = 'Oma tilini';

$_['text_write']               = 'Kirjoita arvostelu';

$_['text_login']               = 'Ole hyvä <a href="%s">Kirjaudu</a> Tai <a href="%s">Rekisteröidy</a> tarkistamaan';

$_['text_empty']          = 'Ei tuotteita odottaa uudelleen.';

$_['text_empty_history'] = 'Et ole lähettänyt arvosteluja.';

$_['text_note']                = '<span class="text-danger">Huomautus:</span> HTML ei ole käännetty!';

$_['text_success']             = 'Kiitos uudelleen. Se on jätetty.';

$_['text_rate'] = 'Miten arvioi tämä tuote?';

$_['button_rate'] = 'Lähetä arvostelu';

$_['text_placeholder'] = 'Kirjoita arvostelu tästä (vaaditaan)

Miksi valitset tämän luokituksen?

Mitä pidät tai Etkö?

Haluatko suositella tätä tuotetta?';



// Entry

$_['entry_name']               = 'Nimesi';

$_['entry_review']             = 'Sinun arvostella';

$_['entry_rating']             = 'Arvostelun';

$_['entry_good']               = 'Hyvä';

$_['entry_bad']                = 'Paha';



// Error

$_['error_name']               = 'Varoitus: nimesi on oltava välillä 3 ja 25 merkkiä!';

$_['error_text']               = 'Varoitus: Tarkista teksti on oltava välillä 25 ja 1000 merkkiä!';

$_['error_rating']             = 'Varoitus: ole hyvä ja valitse tähti Luokitus!';

$_['error_captcha']            = 'Varoitus: vahvistus koodi ei vastaa kuvaa!';