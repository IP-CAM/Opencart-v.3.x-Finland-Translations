<?php
// Heading
$_['heading_title']   = 'Unohditko salasanasi?';

// Text
$_['text_account']    = 'Tili';
$_['text_forgotten']  = 'Unohtunut sala sana';
$_['text_your_email'] = 'Sähkö posti osoitteesi';
$_['text_email']      = 'Kirjoita tiliisi liittyvä Sähkö posti osoite. Click alistaa jotta hankkia tunnus sana palauttaa kytkeä e-kirjain-panssaroitu jotta te.';
$_['text_success']    = 'Sähkö posti osoite, jossa on vahvistus linkki, on lähetetty sähköpostiisi.';

// Entry
$_['entry_email']     = 'Sähköpostiosoite';
$_['entry_password']  = 'Uusi sala sana';
$_['entry_confirm']   = 'Vahvista';

// Error
$_['error_email']     = 'Varoitus: Sähkö posti osoitetta ei löytynyt meidän kirjaa, yritä uudelleen!';
$_['error_approved']  = 'Varoitus: tilisi edellyttää hyväksyntää, ennen kuin voit kirja utua.';
$_['error_password']  = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']   = 'Sala sana ja sala sana vahvistus eivät täsmää!';