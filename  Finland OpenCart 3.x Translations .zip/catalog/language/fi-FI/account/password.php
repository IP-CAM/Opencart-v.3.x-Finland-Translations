<?php
// Heading
$_['heading_title']  = 'Vaihda sala sana';

// Text
$_['text_account']   = 'Tili';
$_['text_password']  = 'Sala sanasi';
$_['text_success']   = 'Onnistui: Sala sanasi on päivitetty onnistuneesti.';

// Entry
$_['entry_password'] = 'Salasana';
$_['entry_confirm']  = 'Sala sana Vahvista';

// Error
$_['error_password'] = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']  = 'Sala sanan vahvistus ei vastaa Sala sanaa!';