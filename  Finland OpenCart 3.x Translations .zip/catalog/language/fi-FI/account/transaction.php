<?php
// Heading
$_['heading_title']      = 'Tapahtumiksi';

// Column
$_['column_date_added']  = 'Päivä määrä lisätty';
$_['column_description'] = 'Kuvaus';
$_['column_amount']      = 'Määrä%s)';

// Text
$_['text_account']       = 'Tili';
$_['text_transaction']   = 'Tapahtumiksi';
$_['text_total']         = 'Nykyinen saldosi on:';
$_['text_empty']         = 'Sinulla ei ole mitään tapahtumia!';