<?php
// Heading
$_['heading_title'] = 'Tilisi on luotu!';

// Text
$_['text_message']  = '<p>Onnittelen! Uusi tilisi on luotu onnistuneesti!</p> <p>Voit nyt hyödyntää jäsen edut parantaa online-ostoksia kokemus kanssamme.</p> <p>Jos sinulla on kysyttävää tämän verkko kaupan toiminnasta, ole hyvä ja lähetä sähkö postia kaupan omistajalle.</p> <p>Annettuun Sähkö posti osoitteeseen on lähetetty vahvistus. Jos et ole saanut sitä tunnin kuluessa, ota <a href="%s">Ota yhteyttä meihin</a>.</p>';
$_['text_approval'] = '<p>Kiitos rekisteröitymisestä %s!</p><p>Saat ilmoituksen sähköpostitse, kun tilisi on aktivoitu kaupan omistaja.</p><p>Jos sinulla on kysyttävää tämän verkko kaupan toiminnasta, ota <a href="%s">Ota yhteyttä kaupan omistajaan</a>.</p>';
$_['text_account']  = 'Tili';
$_['text_success']  = 'Menestys';