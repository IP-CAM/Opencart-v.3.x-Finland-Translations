<?php
// Heading
$_['heading_title']         = 'Tilaus historia';

// Text
$_['text_account']          = 'Tili';
$_['text_order']            = 'Tila uksen tiedot';
$_['text_order_detail']     = 'Tilaus tiedot';
$_['text_invoice_no']       = 'Laskun nro:';
$_['text_order_id']         = 'Tila uksen tunnus:';
$_['text_date_added']       = 'Lisäys päivä:';
$_['text_shipping_address'] = 'Toimitus osoite';
$_['text_shipping_method']  = 'Toimitus tapa:';
$_['text_payment_address']  = 'Maksu osoite';
$_['text_payment_method']   = 'Maksutapa:';
$_['text_comment']          = 'Tilaa kommentit';
$_['text_history']          = 'Tilaus historia';
$_['text_success']          = 'Onnistui: olet lisännyt <a href="%s">%s</a> tieto <a href="%s">Ostoskori</a>!';
$_['text_empty']            = 'Et ole tehnyt mitään aiempia tila uksia!';
$_['text_error']            = 'Tilaus pyytämäsi ei löytynyt!';

// Column
$_['column_order_id']       = 'Tilauksen tunnus';
$_['column_customer']       = 'Asiakas';
$_['column_product']        = 'Ei. sellaisten tuotteiden';
$_['column_name']           = 'Tuotteen nimi';
$_['column_model']          = 'Malli';
$_['column_quantity']       = 'Määrä';
$_['column_price']          = 'Hinta';
$_['column_total']          = 'Yhteensä';
$_['column_action']         = 'Toiminta';
$_['column_date_added']     = 'Päivä määrä lisätty';
$_['column_status']         = 'Tila';
$_['column_comment']        = 'Kommentti';

// Error
$_['error_reorder']         = '%s ei ole tällä hetkellä käytettävissä tilattavissa uudelleen.';