<?php
// Heading
$_['heading_title']      = 'Osoite kirja';

// Text
$_['text_account']       = 'Tili';
$_['text_address_book']  = 'Osoitteiston merkinnät';
$_['text_address_add']   = 'Lisää osoite';
$_['text_address_edit']  = 'Muokkaa osoitetta';
$_['text_add']           = 'Osoitteesi on lisätty onnistuneesti';
$_['text_edit']          = 'Osoitteesi on päivitetty onnistuneesti';
$_['text_delete']        = 'Osoitteesi on poistettu onnistuneesti';
$_['text_empty']         = 'Tililläsi ei ole osoitteita.';

// Entry
$_['entry_firstname']    = 'Etunimi';
$_['entry_lastname']     = 'Suku nimi';
$_['entry_company']      = 'Yritys';
$_['entry_address_1']    = 'Osoite 1';
$_['entry_address_2']    = 'Osoite 2';
$_['entry_postcode']     = 'Posti numero';
$_['entry_city']         = 'City';
$_['entry_country']      = 'Maa';
$_['entry_zone']         = 'Alue/osavaltio';
$_['entry_default']      = 'Oletus osoite';

// Error
$_['error_delete']       = 'Varoitus: sinulla on oltava vähintään yksi osoite!';
$_['error_default']      = 'Varoitus: et voi poistaa oletuksena osoite!';
$_['error_firstname']    = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']     = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_address_1']    = 'Osoitteen on oltava välillä 3 ja 128 merkkiä!';
$_['error_postcode']     = 'Posti numeron on oltava 2-10 merkkiä pitkä!';
$_['error_city']         = 'Kaupungin on oltava välillä 2 ja 128 merkkiä!';
$_['error_country']      = 'Ole hyvä ja valitse maa!';
$_['error_zone']         = 'Valitse alue/osavaltio!';
$_['error_custom_field'] = '%s Tarvitaan!';