<?php
// Heading
$_['heading_title']        = 'Rekisteröi tili';

// Text
$_['text_account']         = 'Tili';
$_['text_register']        = 'Rekisteröidy';
$_['text_account_already'] = 'Jos sinulla on jo tili meille, kirjaudu sisään <a href="%s">kirjautumissivulle</a>.';
$_['text_your_details']    = 'Henkilökohtaiset tietosi';
$_['text_newsletter']      = 'Uutiskirje';
$_['text_your_password']   = 'Sala sanasi';
$_['text_agree']           = 'Olen lukenut ja hyväksyn <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_customer_group'] = 'Asiakas ryhmä';
$_['entry_firstname']      = 'Etunimi';
$_['entry_lastname']       = 'Suku nimi';
$_['entry_email']          = 'Sähköposti';
$_['entry_telephone']      = 'Puhelin';
$_['entry_newsletter']     = 'Tilaa';
$_['entry_password']       = 'Salasana';
$_['entry_confirm']        = 'Sala sana Vahvista';

// Error
$_['error_exists']         = 'Varoitus: Sähkö posti osoite on jo rekisteröity!';
$_['error_firstname']      = 'Etunimi on oltava välillä 1 ja 32 merkkiä!';
$_['error_lastname']       = 'Suku nimen on oltava väliltä 1-32 merkkiä!';
$_['error_email']          = 'Sähkö posti osoite ei vaikuta olevan voimassa!';
$_['error_telephone']      = 'Puhelin on välillä 3 ja 32 merkkiä!';
$_['error_custom_field']   = '%s Tarvitaan!';
$_['error_password']       = 'Sala sanan on oltava 4-20 merkkiä pitkä!';
$_['error_confirm']        = 'Sala sanan vahvistus ei vastaa Sala sanaa!';
$_['error_agree']          = 'Varoitus: sinun on hyväksyttävä %s!';