<?php







$_['account_review'] = 'Tuotteen tarkistus';



$_['module_review'] = 'Kaikki arvostelut';



$_['account_review_account'] = 'Tuotteiden tarkasteleminen';



$_['account_review_history'] = 'Arvostelesi historia';