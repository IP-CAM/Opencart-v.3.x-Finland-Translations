<?php
// Heading
$_['heading_title']     = 'Tilin lataaminen';

// Text
$_['text_account']      = 'Tili';
$_['text_downloads']    = 'Lataukset';
$_['text_empty']        = 'Et ole tehnyt mitään aikaisempia ladattavia tila uksia!';

// Column
$_['column_order_id']   = 'Tilauksen tunnus';
$_['column_name']       = 'Nimi';
$_['column_size']       = 'Koko';
$_['column_date_added'] = 'Päivä määrä lisätty';