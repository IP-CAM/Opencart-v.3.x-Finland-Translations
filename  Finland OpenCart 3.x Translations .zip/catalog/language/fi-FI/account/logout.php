<?php
// Heading
$_['heading_title'] = 'Tilin uloskirjautuminen';

// Text
$_['text_message']  = '<p>Sinut on kirjattu ulos tilistäsi. Nyt on turvallista poistua tieto koneesta.</p><p>Ostos Korisi on tallennettu, sen sisällä olevat kohteet palautetaan aina, kun kirja udut takaisin tilillesi.</p>';
$_['text_account']  = 'Tili';
$_['text_logout']   = 'Logout';