<?php
// Heading
$_['heading_title']             = 'Sinun affiliate Information';

// Text
$_['text_account']              = 'Tili';
$_['text_affiliate']            = 'Affiliate';
$_['text_my_affiliate']         = 'Oma affiliate-tili';
$_['text_payment']              = 'Maksu tiedot';
$_['text_cheque']               = 'Sekin';
$_['text_paypal']               = 'Paypal';
$_['text_bank']                 = 'Pankkisiirto';
$_['text_success']              = 'Onnistui: tilisi on päivitetty onnistuneesti.';
$_['text_agree']                = 'Olen lukenut ja hyväksyn <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_company']             = 'Yritys';
$_['entry_website']             = 'Web-sivusto';
$_['entry_tax']                 = 'Vero tunnus';
$_['entry_payment']             = 'Maksutapa';
$_['entry_cheque']              = 'Sekin maksun saajan nimi';
$_['entry_paypal']              = 'PayPal Sähkö posti tili';
$_['entry_bank_name']           = 'Pankin nimi';
$_['entry_bank_branch_number']  = 'ABA/BSB-numero (konttorin numero)';
$_['entry_bank_swift_code']     = 'SWIFT-koodi';
$_['entry_bank_account_name']   = 'Tilin nimi';
$_['entry_bank_account_number'] = 'Tili numero';

// Error
$_['error_agree']               = 'Varoitus: sinun on hyväksyttävä %s!';
$_['error_cheque']              = 'Sekillä maksun saajan nimi vaaditaan!';
$_['error_paypal']              = 'PayPal Sähkö posti osoite ei näytä olevan voimassa!';
$_['error_bank_account_name']   = 'Tilin nimi vaaditaan!';
$_['error_bank_account_number'] = 'Tili numero vaaditaan!';
$_['error_custom_field']        = '%s Tarvitaan!';