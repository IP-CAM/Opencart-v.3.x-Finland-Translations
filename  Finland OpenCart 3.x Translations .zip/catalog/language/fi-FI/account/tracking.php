<?php
// Heading
$_['heading_title']    = 'Affiliate seuranta';

// Text
$_['text_account']     = 'Tili';
$_['text_description'] = 'Jotta ehtiä totta kai te panna palkallinen ajaksi viitta ukset te lennättää jotta objekti muoto me kaivata jotta jäljittää alistaa luona asettava jäljittää ilmaista koodi kielellä kotona URL \' kytkeä jotta objekti muoto. Alla olevien työkalujen avulla voit luoda linkkejä %s Web-sivustossa.';

// Entry
$_['entry_code']       = 'Seuranta koodisi';
$_['entry_generator']  = 'Seuranta linkki generaattori';
$_['entry_link']       = 'Seurannan linkki';

// Help
$_['help_generator']  = 'Kirjoita sen tuotteen nimi, jonka haluat linkittää';