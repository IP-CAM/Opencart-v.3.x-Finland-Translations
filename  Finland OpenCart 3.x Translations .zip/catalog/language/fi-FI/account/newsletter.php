<?php
// Heading
$_['heading_title']    = 'Uutis kirjeen tilaus';

// Text
$_['text_account']     = 'Tili';
$_['text_newsletter']  = 'Uutiskirje';
$_['text_success']     = 'Menestys: uutis kirjeen tilaus on päivitetty onnistuneesti!';

// Entry
$_['entry_newsletter'] = 'Tilaa';