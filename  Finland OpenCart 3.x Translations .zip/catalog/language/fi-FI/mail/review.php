<?php
// Text
$_['text_subject']  = '%s -Tuotteen tarkistus';
$_['text_waiting']  = 'Sinulla on uusi tuote uudelleen odottaa.';
$_['text_product']  = 'Tuotteen: %s';
$_['text_reviewer'] = 'Arvostelija: %s';
$_['text_rating']   = 'Arvostelun: %s';
$_['text_review']   = 'Tarkista teksti:';