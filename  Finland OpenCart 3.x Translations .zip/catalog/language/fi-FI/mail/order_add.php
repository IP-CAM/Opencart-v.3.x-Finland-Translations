<?php
// Text
$_['text_subject']          = '%s -Tilaa %s';
$_['text_greeting']         = 'Kiitos kiinnoste %s Tuotteet. Tilauksesi on vastaanotettu ja se käsitellään, kun maksu on vahvistettu.';
$_['text_link']             = 'Voit tarkastella tilauksesi napsauttamalla alla olevaa linkkiä:';
$_['text_order_detail']     = 'Tilaus tiedot';
$_['text_instruction']      = 'Ohjeet';
$_['text_order_id']         = 'Tila uksen tunnus:';
$_['text_date_added']       = 'Lisäys päivä:';
$_['text_order_status']     = 'Tila uksen tila:';
$_['text_payment_method']   = 'Maksutapa:';
$_['text_shipping_method']  = 'Toimitus tapa:';
$_['text_email']            = 'Sähköposti:';
$_['text_telephone']        = 'Puhelin:';
$_['text_ip']               = 'IP-osoite:';
$_['text_payment_address']  = 'Maksu osoite';
$_['text_shipping_address'] = 'Toimitus osoite';
$_['text_products']         = 'Tuotteet';
$_['text_product']          = 'Tuotteen';
$_['text_model']            = 'Malli';
$_['text_quantity']         = 'Määrä';
$_['text_price']            = 'Hinta';
$_['text_order_total']      = 'Tilausten yhteissummat';
$_['text_total']            = 'Yhteensä';
$_['text_download']         = 'Kun maksu on vahvistettu, voit napsauttaa alla olevaa linkkiä ja käyttää ladattavia tuotteita:';
$_['text_comment']          = 'Kommentit tilauksesi ovat:';
$_['text_footer']           = 'Ole hyvä ja vastaa tähän e-mail, jos sinulla on kysyttävää.';