<?php
// Text
$_['text_subject']  = '%s -Affiliate Commission';
$_['text_received'] = 'Onnittelen! Komissio on saanut maksun %s Kumppaniohjelmaan';
$_['text_amount']   = 'Olet saanut:';
$_['text_total']    = 'Sinun kokonaismäärä provisio on nyt:';