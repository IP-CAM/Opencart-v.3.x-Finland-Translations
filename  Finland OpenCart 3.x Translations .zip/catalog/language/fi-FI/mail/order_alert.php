<?php
// Text
$_['text_subject']      = '%s -Tilaa %s';
$_['text_received']     = 'Olet saanut tila uksen.';
$_['text_order_id']     = 'Tila uksen tunnus:';
$_['text_date_added']   = 'Lisäys päivä:';
$_['text_order_status'] = 'Tila uksen tila:';
$_['text_product']      = 'Tuotteet';
$_['text_total']        = 'Summat';
$_['text_comment']      = 'Kommentit tilauksesi ovat:';
