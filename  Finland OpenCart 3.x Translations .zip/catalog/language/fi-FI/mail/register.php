<?php
// Text
$_['text_subject']        = '%s -Kiitos rekisteröitymisestä';
$_['text_welcome']        = 'Tervetuloa ja Kiitos rekisteröitymisestä %s!';
$_['text_login']          = 'Tilisi on nyt luotu, ja voit kirja utua sisään käyttämällä Sähkö posti osoitettasi ja Sala sanaasi vierailemalla Web-sivuillamme tai seuraavassa osoitteessa:';
$_['text_approval']       = 'Tilisi on hyväksyttävä, ennen kuin voit kirja utua sisään. Kun olet hyväksynyt voit kirja utua sisään käyttämällä Sähkö posti osoitteesi ja Sala sanasi käymällä sivuillamme tai seuraavassa URL:';
$_['text_service']        = 'Sisäänkirjautumisen yhteydessä voit käyttää muita palveluita, kuten aiempien tilausten tarkistamista, laskujen tulostamista ja tili tietojen muokkaamista.';
$_['text_thanks']         = 'Kiitos';
$_['text_new_customer']   = 'Uusi asiakas';
$_['text_signup']         = 'Uusi asiakas on rekisteröitynyt:';
$_['text_customer_group'] = 'Asiakas ryhmä:';
$_['text_firstname']      = 'Etunimi:';
$_['text_lastname']       = 'Suku nimi:';
$_['text_email']          = 'Sähköposti:';
$_['text_telephone']      = 'Puhelin:';