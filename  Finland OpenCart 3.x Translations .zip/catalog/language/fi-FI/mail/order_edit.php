<?php
// Text
$_['text_subject']      = '%s -Tilaa päivitys %s';
$_['text_order_id']     = 'Tila uksen tunnus:';
$_['text_date_added']   = 'Lisäys päivä:';
$_['text_order_status'] = 'Tilauksesi on päivitetty seuraavaan tilaan:';
$_['text_comment']      = 'Kommentit tilauksesi ovat:';
$_['text_link']         = 'Voit tarkastella tilauksesi napsauttamalla alla olevaa linkkiä:';
$_['text_footer']       = 'Ole hyvä ja vastaa tähän viestiin, jos sinulla on kysyttävää.';