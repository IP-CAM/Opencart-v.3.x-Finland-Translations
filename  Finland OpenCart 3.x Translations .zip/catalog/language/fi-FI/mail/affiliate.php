<?php
// Text
$_['text_subject']        = '%s -Affiliate-ohjelma';
$_['text_welcome']        = 'Kiitos, että liityit %s Kumppaniohjelmaan!';
$_['text_login']          = 'Tilisi on nyt luotu, ja voit kirja utua sisään käyttämällä Sähkö posti osoitettasi ja Sala sanaasi vierailemalla Web-sivuillamme tai seuraavassa osoitteessa:';
$_['text_approval']       = 'Tilisi on hyväksyttävä, ennen kuin voit kirja utua sisään. Kun olet hyväksynyt voit kirja utua sisään käyttämällä Sähkö posti osoitteesi ja Sala sanasi käymällä sivuillamme tai seuraavassa URL:';
$_['text_service']        = 'Sisäänkirjautumisen yhteydessä voit luoda seuranta koodeja, seurata provisio maksuja ja muokata tili tietojasi.';
$_['text_thanks']         = 'Kiitos';
$_['text_new_affiliate']  = 'Uusi affiliate';
$_['text_signup']         = 'Uusi affiliate on allekirjoittanut:';
$_['text_website']        = 'Web-sivustossa:';
$_['text_customer_group'] = 'Asiakas ryhmä:';
$_['text_firstname']      = 'Etunimi:';
$_['text_lastname']       = 'Suku nimi:';
$_['text_company']        = 'Yritys:';
$_['text_email']          = 'Sähköposti:';
$_['text_telephone']      = 'Puhelin:';