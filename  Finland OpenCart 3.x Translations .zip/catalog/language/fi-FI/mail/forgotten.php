<?php
// Text
$_['text_subject']  = '%s -Sala sanan palautus pyyntö';
$_['text_greeting'] = 'Uusi sala sana pyydettiin %s asiakas tili.';
$_['text_change']   = 'Voit nollata Sala sanasi napsauttamalla alla olevaa linkkiä:';
$_['text_ip']       = 'Tämän pyynnön esittäjä käytti tätä tutkimus ajan jaksoa:';