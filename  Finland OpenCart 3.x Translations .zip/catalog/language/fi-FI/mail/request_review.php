<?php
// Heading
$_['heading_title']             = 'Pyydä arvioita';

// Button
$_['button_send']               = 'Lähetä sähkö postit';
$_['button_delete_from_list']   = 'Poista luettelosta';
$_['button_settings']           = 'Asetukset';
$_['button_save_settings']      = 'Tallenna yleiset asetukset';
$_['button_save_email_text']    = 'Tallenna Sähkö posti viestin teksti';
$_['button_send_test_emails']   = 'Lähetä testi sähkö postit';

// Column
$_['column_name']               = 'Asiakkaan nimi';
$_['column_email']              = 'Sähköposti';
$_['column_order_id']           = 'Tilauksen tunnus';
$_['column_order_total']        = 'Tilausten kokonaismäärä'; // Added v1.1
$_['column_order_status_date']  = 'Tila uksen tila päivitetty';
$_['column_language']           = 'Kieli';
$_['column_store_name']         = 'Myymälän nimi';

// Tab
$_['tab_general']               = 'Yleiset ehdot';
$_['tab_email_text']            = 'Sähkö posti viestin teksti';
$_['tab_test_center']           = 'Testi keskus';
$_['tab_log']					= 'Kirjaudu';

// Text
$_['text_success_mail']         = 'Menestys: %s lähetetyt viestit, jotka sisältävät %s tuote linkkejä.';
$_['text_success_remove']       = 'Menestys: %s asiakas (t) on poistettu luettelosta.';
$_['text_success_settings']     = 'Onnistui: asetukset kohteelle <b>Pyydä arvostelu</b> Päivitetty.';
$_['text_success_email_text']   = 'Onnistui: Sähkö posti teksti on päivitetty.';
$_['text_success_mail_test']    = 'Menestys: %s Testaa lähetetyt sähkö postit (%s kielellä). %s';
$_['text_failed_validation']    = '%s Jos sähkö postit epäonnistui validointi!';

$_['text_success_clear_log']  	= 'Menestys: olet onnistuneesti selvitetty loki!';

$_['text_install']              = 'Sinun täytyy syöttää asetukset ja valitse Tallenna. Tämä viesti näkyy vain kerran. Jälkeenpäin voi vaihtaa asetuksia klikkaamalla painiketta oikeassa yläkulmassa.';

$_['text_order_status']         = 'Tila uksen tila vaaditaan:<br /><span class="help">Näyttää vain tila ukset, joissa on tämä tila</span>'; 
$_['text_display']              = 'Päivää ennen pyynnön tarkistamista:<br /><span class="help">Päivien luku määrä ennen tila uksia, jotka on merkitty yllä olevalla tila uksen tilalla, näkyy.</span>';
$_['text_display_before_review']              = 'Päivää ennen Salli tarkistus:<br /><span class="help">Päivien määrä, ennen kuin tuotteet näkyvät asiakkaan profiilissa tarkistettavaksi.</span>';
$_['text_orders_per_page']      = 'Tila ukset per sivu:<br /><span class="help">Tilausten määrä sivua kohden. Nyt kuluva kin määritellä kuinka usea panssari jälki säädös panna lennättää aikaa ainoa aika.</span>';
$_['text_fallback_language']    = 'Varmistus kieli:<br /><span class="help">Käyttää tätä kieltä vara, estää lähettämällä tyhjiä viestejä.</span>';
$_['text_append_language_code'] = 'Liitä kieli koodi URL-osoitteisiin:<br /><span class="help">Liittää kieli koodin sähkö postin tuote-URL-osoitteisiin. Tämä valitsee automaattisesti oikean kielen asiakkaasi varten, kun napsautat linkkiä.';
$_['text_min_amount']           = 'Tilaa minimi summa<br /><span class="help">Näyttää vain tila ukset, joiden summa on suurempi kuin annettu arvo.<br />Esimerkki: 50 näyttää tila ukset vain, joiden tila uksen kokonaisarvo on $50, £50, €50 tai suurempi</span>'; // Added v1.1 

$_['text_subject']              = 'Aihe:';
$_['text_message']              = 'Viesti:';
$_['text_footer']               = 'Alatunniste:';
$_['text_plural_placeholders']  = 'Monikko paikka merkit:<span class="help">Sana muodot käytetään sähkö postit yli 1 tuote.</span>';
$_['text_singular_placeholders']= 'Yksikkö paikka merkit:<span class="help">Yhden tuotteen Sähkö posti viesteihin käytettävät sana muodot.</span>';
$_['text_available_placeholders'] = 'Muut käytettävissä olevat paikka merkit';

$_['text_test_emails']          = 'Testaa sähkö postit:<br /><span class="help">Kirjoita Sähkö posti osoitteet, joille haluat saada testi sähkö postin (pilkulla erotettuna)</span>';
$_['text_test_languages']       = 'Kielet:<br /><span class="help">Valitse kielet, joille testi Sähkö posti lähetetään.</span>';
$_['text_number_of_products']   = 'Tuotteiden määrä:<br /><span class="help">Kirjoita testi sähkö postissa näkyvät tuotteiden määrä. Jos jätetään tyhjäksi, 4 tuotteet sisällytetään.</span>';
$_['text_test_store']           = 'Store:';

$_['text_legend'] = '<span class="help">{order_id} = Tilaus tunnus<br/>{firstname} {lastname} = Etunimi suku nimi<br />{store_name} = Myymälän nimi<br />{store_url} = Myymälän URL<br />{each} {product} {link}</span>';

$_['text_test_warning'] = '<br/>Varoittava arvostella kytkeä kotona koekäyttää email jälki säädös ei aikaansaada korjata koska asiakas kaivata jotta hankkia hedelmä ajaksi se jotta esitellä kotona heidän selittää asian.<br/>';

$_['text_cron_enable']        = 'Lähetä sähkö postia automaattisesti päivittäin?';
$_['text_cron_key'] = 'Cron Job salaisuus avain';
$_['text_cron_weekly'] = 'Viikoittain';
$_['text_cron_daily'] = 'Päivittäin';
$_['text_cron_monthly'] = 'Kuukausittain';
$_['entry_cron_update'] = 'Päivitä aika';

// Error
$_['error_no_selected']         = 'Pyydä arvioita: ei valittuja asiakkaita.';
$_['error_no_test_mails']       = 'Test Center: ei sähkö postia säädetty. Kirjoita vähintään yksi.';
$_['error_no_language_selected']= 'Testi keskus: ei valittuja kieliä.';
$_['error_permission']          = 'Varoitus: sinulla ei ole oikeuksia muokata tai käyttää <b>Pyydä arvioita</b>!';
?>