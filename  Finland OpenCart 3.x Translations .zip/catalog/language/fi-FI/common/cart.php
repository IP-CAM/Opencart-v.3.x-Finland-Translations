<?php
// Text
$_['text_items']     = '%s tuote (t)- %s';
$_['text_empty']     = 'Ostos Korisi on tyhjä!';
$_['text_cart']      = 'Näytä ostos kori';
$_['text_checkout']  = 'Kassalle';
$_['text_recurring'] = 'Maksu profiilia';