<?php
// Text
$_['text_information']  = 'Huoneesta';
$_['text_service']      = 'Asiakaspalvelu';
$_['text_extra']        = 'Ekstrat';
$_['text_contact']      = 'Ota yhteyttä meihin';
$_['text_return']       = 'Palauttaa';
$_['text_sitemap']      = 'Sivu kartta';
$_['text_manufacturer'] = 'Tuotemerkit';
$_['text_voucher']      = 'Lahjakortit';
$_['text_affiliate']    = 'Affiliate';
$_['text_special']      = 'Tarjoukset';
$_['text_account']      = 'Oma tilini';
$_['text_order']        = 'Tilaus historia';
$_['text_wishlist']     = 'Toivelista';
$_['text_newsletter']   = 'Uutiskirje';
$_['text_powered']      = 'Tuen toimitti <a href="http://www.opencart.com">Openpart</a><br /> %s &copy; %s';