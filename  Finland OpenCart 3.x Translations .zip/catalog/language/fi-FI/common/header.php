<?php
// Text
$_['text_home']          = 'Kotisivu';
$_['text_wishlist']      = 'Toive lista (%s)';
$_['text_shopping_cart'] = 'Ostoskori';
$_['text_category']      = 'Luokat';
$_['text_account']       = 'Oma tilini';
$_['text_register']      = 'Rekisteröidy';
$_['text_login']         = 'Kirjaudu';
$_['text_order']         = 'Tilaus historia';
$_['text_transaction']   = 'Tapahtumat';
$_['text_download']      = 'Lataukset';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Kassalle';
$_['text_search']        = 'Etsi';
$_['text_all']           = 'Näytä kaikki';