<?php
// Heading
$_['heading_title']    = 'Huolto';

// Text
$_['text_maintenance'] = 'Huolto';
$_['text_message']     = '<h1 style="text-align:center;">Olemme tällä hetkellä suorittaa joitakin suunniteltu huolto. <br/>Tulemme takaisin niin pian kuin mahdollista. Haluta ruudullinen taaksepäin aika isin.</h1>';