<?php
// Text
$_['text_all'] = 'Näytä kaikki';