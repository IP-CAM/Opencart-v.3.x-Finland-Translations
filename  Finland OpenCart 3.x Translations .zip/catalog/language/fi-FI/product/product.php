<?php
// Text
$_['text_search']              = 'Etsi';
$_['text_brand']               = 'Tuotemerkin';
$_['text_manufacturer']        = 'Tuotemerkin:';
$_['text_model']               = 'Tuote koodi:';
$_['text_reward']              = 'Palkintopisteitä:';
$_['text_points']              = 'Hinta palkinto pistein:';
$_['text_stock']               = 'Saatavuus:';
$_['text_instock']             = 'Varastossa';
$_['text_tax']                 = 'Ex Tax:';
$_['text_discount']            = ' tai useamman ';
$_['text_option']              = 'Käytettävissä olevat vaihto ehdot';
$_['text_minimum']             = 'Tämän tuotteen minimi määrä on %s';
$_['text_reviews']             = '%s Arvion perusteella';
$_['text_write']               = 'Kirjoita arvostelu';
$_['text_login']               = 'Ole hyvä <a href="%s">Kirjaudu</a> Tai <a href="%s">Rekisteröidy</a> tarkistamaan';
$_['text_no_reviews']          = 'Tälle tuotteelle ei ole arvosteluja.';
$_['text_note']                = '<span class="text-danger">Huomautus:</span> HTML ei ole käännetty!';
$_['text_success']             = 'Kiitos uudelleen. Se on lähetetty Webmaster hyväksyttäväksi.';
$_['text_related']             = 'Aiheeseen liittyvät tuotteet';
$_['text_tags']                = 'Tunnisteet:';
$_['text_error']               = 'Tuotetta ei löydy!';
$_['text_payment_recurring']   = 'Maksu profiilia';
$_['text_trial_description']   = '%s Joka %d %s(t) %d Maksu (t) sitten';
$_['text_payment_description'] = '%s Joka %d %s(t) %d Maksu (t)';
$_['text_payment_cancel']      = '%s Joka %d %s(s) kunnes peruutettu';
$_['text_day']                 = 'Päivä';
$_['text_week']                = 'Viikolla';
$_['text_semi_month']          = 'puolen kuukauden';
$_['text_month']               = 'Kuukausi';
$_['text_year']                = 'Vuoden';

// Entry
$_['entry_qty']                = 'Määrä';
$_['entry_name']               = 'Nimesi';
$_['entry_review']             = 'Sinun arvostella';
$_['entry_rating']             = 'Arvostelun';
$_['entry_good']               = 'Hyvä';
$_['entry_bad']                = 'Paha';

// Tabs
$_['tab_description']          = 'Kuvaus';
$_['tab_attribute']            = 'Erittely';
$_['tab_review']               = 'Arvion perusteella%s)';

// Error
$_['error_name']               = 'Varoitus: tarkistus nimi on oltava välillä 3 ja 25 merkkiä!';
$_['error_text']               = 'Varoitus: Tarkista teksti on oltava välillä 25 ja 1000 merkkiä!';
$_['error_rating']             = 'Varoitus: ole hyvä ja valitse arvostelu Luokitus!';