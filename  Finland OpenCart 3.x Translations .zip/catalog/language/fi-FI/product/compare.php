<?php
// Heading
$_['heading_title']     = 'Tuotteiden vertailu';

// Text
$_['text_product']      = 'Tuotteen tiedot';
$_['text_name']         = 'Tuotteen';
$_['text_image']        = 'Kuva';
$_['text_price']        = 'Hinta';
$_['text_model']        = 'Malli';
$_['text_manufacturer'] = 'Tuotemerkin';
$_['text_availability'] = 'Saatavuus';
$_['text_instock']      = 'Varastossa';
$_['text_rating']       = 'Arvostelun';
$_['text_reviews']      = 'Perustuu %s Arvion perusteella.';
$_['text_summary']      = 'Yhteenveto';
$_['text_weight']       = 'Paino';
$_['text_dimension']    = 'Mitat (p x l x k)';
$_['text_compare']      = 'Tuotteiden vertailu (%s)';
$_['text_success']      = 'Onnistui: olet lisännyt <a href="%s">%s</a> tieto <a href="%s">tuotteiden vertailu</a>!';
$_['text_remove']       = 'Menestys: olet muokannut tuote vertailua!';
$_['text_empty']        = 'Et ole valinnut yhtään vertailtavia tuotteita.';