<?php
// Heading
$_['heading_title']     = 'Löydä suosikki brändisi';

// Text
$_['text_brand']        = 'Tuotemerkin';
$_['text_index']        = 'Tuote merkin hakemisto:';
$_['text_error']        = 'Brändi ei löytynyt!';
$_['text_empty']        = 'Luettelossa ei ole tuotteita.';
$_['text_quantity']     = 'Määrä:';
$_['text_manufacturer'] = 'Tuotemerkin:';
$_['text_model']        = 'Tuote koodi:';
$_['text_points']       = 'Palkintopisteitä:';
$_['text_price']        = 'Hinta:';
$_['text_tax']          = 'Ex Tax:';
$_['text_compare']      = 'Tuotteiden vertailu (%s)';
$_['text_sort']         = 'Lajittele:';
$_['text_default']      = 'Oletus';
$_['text_name_asc']     = 'Nimi (a – ö)';
$_['text_name_desc']    = 'Nimi (Z-a)';
$_['text_price_asc']    = 'Hinta (matala &gt; Korkea';
$_['text_price_desc']   = 'Hinta (korkea &gt; Alhainen';
$_['text_rating_asc']   = 'Luokitus (alin)';
$_['text_rating_desc']  = 'Luokitus (korkein)';
$_['text_model_asc']    = 'Malli (a-Z)';
$_['text_model_desc']   = 'Malli (Z-a)';
$_['text_limit']        = 'Näytä:';